"""Đối chiếu cấu hình PhishGuard bằng các thao tác AWS đọc dữ liệu."""
import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

import boto3
from botocore.exceptions import BotoCoreError, ClientError


def audit(session, region, stack_name, recipient, distribution_id, budget_name):
    rows = []

    def run(name, action):
        try:
            state, details = action()
        except (BotoCoreError, ClientError) as exc:
            code = exc.response["Error"]["Code"] if isinstance(exc, ClientError) else type(exc).__name__
            state, details = "UNVERIFIED", {"reason": code}
        rows.append({"check": name, "state": state, "details": details})

    def client(service, where=None):
        return session.client(service, region_name=where or region)

    def result(ok, data):
        return ("MATCH" if ok else "REVIEW", data)

    account = client("sts").get_caller_identity()["Account"]
    cfn = client("cloudformation")
    stack = cfn.describe_stacks(StackName=stack_name)["Stacks"][0]
    out = {x["OutputKey"]: x["OutputValue"] for x in stack.get("Outputs", [])}
    params = {x["ParameterKey"]: x["ParameterValue"] for x in stack.get("Parameters", [])}
    run("Stack", lambda: result(stack["StackStatus"] in ("UPDATE_COMPLETE", "CREATE_COMPLETE"), {
        "stack":stack_name, "status": stack["StackStatus"], "region": region, "account_suffix": account[-4:],
        "approval_timeout_seconds":params.get("ApprovalTimeoutSeconds"), "containment_mode":params.get("ContainmentMode"),
        "model":params.get("ModelId"), "waf_parameter_only":params.get("EnableWaf"),
    }))

    def inventory():
        types = {}
        for page in cfn.get_paginator("list_stack_resources").paginate(StackName=stack_name):
            for x in page["StackResourceSummaries"]:
                key = x["ResourceType"]
                types[key] = types.get(key, 0) + 1
        return "OBSERVED", types
    run("Stack resource counts", inventory)

    s3 = client("s3")
    web, intake, raw = (out.get(k) for k in ("WebBucketName","IntakeBucketName","EvidenceBucketName"))
    dist_id = distribution_id or params.get("CloudFrontDistributionId")
    domain, api_host = params.get("CloudFrontOrigin",""), urlparse(out.get("HttpApiEndpoint","")).hostname
    cf = client("cloudfront", "us-east-1")
    edge = {}

    def routes():
        if not dist_id:
            return "UNVERIFIED", {"reason":"Supply --distribution-id from the CloudFront console"}
        d = cf.get_distribution(Id=dist_id)["Distribution"]
        cfg = d["DistributionConfig"]
        origins = {i["Id"]: i for i in cfg["Origins"]["Items"]}
        home = origins.get(cfg["DefaultCacheBehavior"]["TargetOriginId"], {})
        bs = cfg.get("CacheBehaviors",{}).get("Items",[])
        b = next((t for t in bs if t["PathPattern"].lstrip("/")=="api/*"),{})
        api = origins.get(b.get("TargetOriginId"),{})
        edge["acl"] = cfg.get("WebACLId","")
        edge["oac"] = home.get("OriginAccessControlId","")
        edge["cache_policy"] = b.get("CachePolicyId")
        edge["request_policy"] = b.get("OriginRequestPolicyId")
        site = "https://"+d["DomainName"]
        detail = {"enabled":cfg.get("Enabled"),"deployed":d.get("Status"),
                  "default_origin_matches_bucket":bool(web and (home.get("DomainName","").startswith(web+".s3.") or home.get("DomainName","").startswith(web+".s3-"))),
                  "web_oac_attached":bool(edge["oac"]),"api_behavior_present":bool(b),
                  "api_host_matches_stack":bool(api_host and api.get("DomainName")==api_host),
                  "api_origin_path":api.get("OriginPath",""),"origin_matches_stack":site==domain,
                  "dashboard_matches_site":params.get("DashboardUrl","").rstrip("/")==site,
                  "api_protocol":api.get("CustomOriginConfig",{}).get("OriginProtocolPolicy"),
                  "api_methods":b.get("AllowedMethods",{}).get("Items",[])}
        return result(d.get("Status")=="Deployed" and cfg.get("Enabled") and all(detail[k] for k in ("default_origin_matches_bucket","web_oac_attached","api_behavior_present","api_host_matches_stack","origin_matches_stack","dashboard_matches_site"))
                      and not detail["api_origin_path"] and detail["api_protocol"]=="https-only" and {"GET","POST"}.issubset(detail["api_methods"]), detail)
    run("CloudFront routes", routes)
    def policies():
        if not all(edge.get(k) for k in ("cache_policy","request_policy","oac")):
            return "UNVERIFIED", {"reason":"Check API behavior and web OAC"}
        cache = cf.get_cache_policy(Id=edge["cache_policy"])["CachePolicy"]["CachePolicyConfig"]
        origin = cf.get_origin_request_policy(Id=edge["request_policy"])["OriginRequestPolicy"]["OriginRequestPolicyConfig"]
        oac = cf.get_origin_access_control(Id=edge["oac"])["OriginAccessControl"]["OriginAccessControlConfig"]
        details={"cache":cache["Name"],"origin_request":origin["Name"],"s3_signing":oac["SigningBehavior"]}
        return result(cache.get("MaxTTL")==0 and origin["Name"] in ("Managed-AllViewerExceptHostHeader","AllViewerExceptHostHeader") and oac["SigningBehavior"]=="always", details)
    run("CloudFront policies", policies)

    def acl():
        if "acl" not in edge:
            return "UNVERIFIED",{"reason":"Read distribution first"}
        arn=edge["acl"]
        if not arn:
            return "REVIEW",{"web_acl_association_visible":False,"next":"Check distribution Security and pricing plan"}
        if not arn.startswith("arn:") or len(arn.split("/"))<3:
            return "UNVERIFIED",{"web_acl_id_present":True,"next":"Inspect WAF version in console"}
        name, identifier=arn.split("/")[-2:]
        rules=client("wafv2","us-east-1").get_web_acl(Name=name,Id=identifier,Scope="CLOUDFRONT")["WebACL"].get("Rules",[])
        kinds=[next(iter(r.get("Statement",{})),"unknown") for r in rules]
        return result("ManagedRuleGroupStatement" in kinds and "RateBasedStatement" in kinds, {"attached":True,"top_level_rule_count":len(rules),"rule_statement_types":kinds})
    run("WAF on this distribution",acl)
    rows.append({"check":"CloudFront pricing plan","state":"MANUAL","details":{"where":"Distribution > pricing plan / Billing subscription"}})

    def web_private():
        if not web:return "UNVERIFIED",{"missing":"WebBucketName"}
        flags=s3.get_public_access_block(Bucket=web)["PublicAccessBlockConfiguration"]
        return result(all(flags.get(k) for k in ("BlockPublicAcls","IgnorePublicAcls","BlockPublicPolicy","RestrictPublicBuckets")), flags)
    run("Web bucket public access block",web_private)

    def cors():
        if not intake:return "UNVERIFIED",{"missing":"IntakeBucketName"}
        rules=s3.get_bucket_cors(Bucket=intake)["CORSRules"]
        post=[x for x in rules if "POST" in x.get("AllowedMethods",[])]
        origins=sorted({o for x in post for o in x.get("AllowedOrigins",[])})
        return result(bool(domain) and origins==[domain] and all(x.get("AllowedMethods")==["POST"] for x in rules),
                      {"allows_stack_origin_only_for_post":bool(domain) and origins==[domain],"rule_count":len(rules)})
    run("Intake CORS",cors)
    def protection():
        if not raw:return "UNVERIFIED",{"missing":"EvidenceBucketName"}
        c=s3.get_object_lock_configuration(Bucket=raw)["ObjectLockConfiguration"]
        v=s3.get_bucket_versioning(Bucket=raw).get("Status")
        enc=s3.get_bucket_encryption(Bucket=raw)["ServerSideEncryptionConfiguration"]["Rules"][0]["ApplyServerSideEncryptionByDefault"]["SSEAlgorithm"]
        retention=c.get("Rule",{}).get("DefaultRetention",{})
        return result(c.get("ObjectLockEnabled")=="Enabled" and retention.get("Mode")=="GOVERNANCE" and retention.get("Days")==7 and v=="Enabled" and enc=="aws:kms", {"default_retention":retention,"versioning":v,"encryption":enc})
    run("Raw evidence default",protection)
    def layer():
        f=client("lambda").get_function_configuration(FunctionName="PhishGuard-ExtractRedact")
        return result(any("ocr" in l["Arn"].lower() for l in f.get("Layers",[])) and f.get("Runtime")=="python3.12",{"has_ocr_layer":any("ocr" in l["Arn"].lower() for l in f.get("Layers",[])),"memory_mib":f.get("MemorySize"),"architecture":f.get("Architectures")})
    run("OCR Lambda",layer)

    def ses():
        if "@" not in recipient:return "UNVERIFIED",{"reason":"Supply a lab recipient"}
        config=client("ses").describe_active_receipt_rule_set()
        # Examine eligible rules in delivery order; account for a preceding StopAction.
        matches=[]
        for rule in config.get("Rules",[]):
            addresses=[s.lower() for s in rule.get("Recipients",[])]
            local,dom=recipient.lower().rsplit("@",1)
            if not rule.get("Enabled") or (addresses and recipient.lower() not in addresses and dom not in addresses and not any(s.startswith(".") and dom.endswith(s) for s in addresses)):
                continue
            for action in rule.get("Actions",[]):
                if "S3Action" in action:
                    a=action["S3Action"]
                    if intake and a.get("BucketName")==intake and a.get("ObjectKeyPrefix","")=="inbound/":matches.append("store inbound/")
                if "LambdaAction" in action:
                    a=action["LambdaAction"]
                    if a.get("FunctionArn","").split(":function:")[-1].split(":")[0]=="PhishGuard-Ingest":
                        matches.append("invoke Ingest")
                if "StopAction" in action:break
            else:continue
            break
        ok=any(entry=="invoke Ingest" and "store inbound/" in matches[:idx] for idx,entry in enumerate(matches))
        return result(ok, {"active_set":bool(config.get("Metadata")),"matched_project_actions":matches})
    run("SES receipt route",ses)
    sns_arn=out.get("SecOpsTopicArn")
    def subscriptions():
        if not sns_arn:return "UNVERIFIED",{"missing":"SecOpsTopicArn"}
        records=[s for page in client("sns").get_paginator("list_subscriptions_by_topic").paginate(TopicArn=sns_arn) for s in page["Subscriptions"] if s.get("Protocol") in ("email","email-json")]
        confirmed=sum(s.get("SubscriptionArn","").startswith("arn:") for s in records)
        return result(confirmed>0,{"confirmed_email":confirmed,"pending_or_other":len(records)-confirmed})
    run("SNS email",subscriptions)
    def alarms():
        wanted=["PhishGuard-Ingest-DLQ-NotEmpty","PhishGuard-Workflow-Failed"]
        info=client("cloudwatch").describe_alarms(AlarmNames=wanted).get("MetricAlarms",[])
        data={a["AlarmName"]:{"state":a["StateValue"],"actions_enabled":a["ActionsEnabled"],"secops_target":bool(sns_arn and sns_arn in a.get("AlarmActions",[]))} for a in info}
        return result(len(data)==2 and all(a["actions_enabled"] and a["secops_target"] for a in data.values()),data)
    run("CloudWatch alarm wiring",alarms)
    def ai():
        kb_id,gr=params.get("KnowledgeBaseId"),params.get("GuardrailId")
        if not kb_id or not gr:return "REVIEW",{"kb_configured":bool(kb_id),"guardrail_configured":bool(gr)}
        agent=client("bedrock-agent");kb=agent.get_knowledge_base(knowledgeBaseId=kb_id)["knowledgeBase"]
        statuses=[]
        for page in agent.get_paginator("list_data_sources").paginate(knowledgeBaseId=kb_id):
            for ds in page["dataSourceSummaries"]:
                jobs=agent.list_ingestion_jobs(knowledgeBaseId=kb_id,dataSourceId=ds["dataSourceId"],sortBy={"attribute":"STARTED_AT","order":"DESCENDING"},maxResults=1)["ingestionJobSummaries"]
                statuses.append(jobs[0]["status"] if jobs else "NO_JOB")
        guard=client("bedrock").get_guardrail(guardrailIdentifier=gr,guardrailVersion=params.get("GuardrailVersion") or "DRAFT")
        st=kb.get("storageConfiguration",{}).get("type")
        has_filter=any(f.get("type")=="PROMPT_ATTACK" and f.get("inputStrength") not in (None,"NONE") and f.get("inputAction","BLOCK")=="BLOCK" and f.get("inputEnabled",True) for f in guard.get("contentPolicy",{}).get("filters",[]))
        return result(kb["status"]=="ACTIVE" and st=="S3_VECTORS" and "COMPLETE" in statuses and guard.get("status")=="READY" and has_filter,{"kb":kb["status"],"storage":st,"last_ingestions":statuses,"guardrail_status":guard.get("status"),"prompt_attack_input":has_filter})
    run("Bedrock resources",ai)
    def budget():
        svc=client("budgets","us-east-1")
        if budget_name: records=[svc.describe_budget(AccountId=account,BudgetName=budget_name)["Budget"]]
        else:
            records=[b for page in svc.get_paginator("describe_budgets").paginate(AccountId=account) for b in page["Budgets"] if "phishguard" in b["BudgetName"].lower()]
        return ("OBSERVED" if records else "MANUAL"), {"matching_budget_count":len(records),"budgets":[{"name":b["BudgetName"],"period":b["TimeUnit"],"limit":b.get("BudgetLimit")} for b in records],"next":"Check recipients, thresholds and coverage in Budgets"}
    run("Budgets",budget)
    return {"observed_at_utc":datetime.now(timezone.utc).isoformat(),"rows":rows}


def main():
    p=argparse.ArgumentParser(description="Đọc cấu hình PhishGuard và lưu bản đối chiếu cục bộ; không đọc nội dung email, secrets hoặc hóa đơn.")
    p.add_argument("--profile",default="phishguard");p.add_argument("--region",default="us-east-1")
    p.add_argument("--stack",default="phishguard-ai");p.add_argument("--recipient",default="soc@ourprj.site")
    p.add_argument("--distribution-id");p.add_argument("--budget-name")
    p.add_argument("--output",type=Path,default=Path("phishguard-account.json"))
    args=p.parse_args()
    try:
        s=boto3.Session(profile_name=args.profile,region_name=args.region)
        report=audit(s,args.region,args.stack,args.recipient,args.distribution_id,args.budget_name)
    except (BotoCoreError, ClientError) as exc:
        raise SystemExit(f"Không đọc được danh tính hoặc stack: {exc}") from None
    args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    for row in report["rows"]:print(f'{row["state"]:11} {row["check"]}')
    print(args.output.resolve())


if __name__=="__main__":main()
