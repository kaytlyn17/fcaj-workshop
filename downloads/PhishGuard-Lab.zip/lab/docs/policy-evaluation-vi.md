# Kết luận của Triage và đánh giá cục bộ

## Đọc một incident

API danh sách và chi tiết đều trả `policy_evaluation`. `risk_score` là tổng điểm của các luật kích hoạt, tối đa 100. Dải điểm LOW, MEDIUM, HIGH, CRITICAL lần lượt bắt đầu từ 0, 25, 50, 75. `assessment` thể hiện policy đã đủ căn cứ gắn cờ hay chưa. Điểm không phải xác suất.

| Điều kiện | Kết luận và lý do | Trạng thái sau phân tích |
| --- | --- | --- |
| Đầu vào dưới ngưỡng chất lượng, không có URL đọc được từ QR | Chưa chấm điểm | `NEEDS_MORE_INFO`, yêu cầu bổ sung bằng chứng |
| Dưới 50 điểm, có URL | `UNKNOWN / UNVERIFIED_URL` | `NO_ACTION` |
| Dưới 50 điểm, không có URL | `UNKNOWN / INSUFFICIENT_SIGNALS` | `NO_ACTION` |
| Từ 50 điểm, không có đề xuất hợp lệ | `SUSPICIOUS / RULE_THRESHOLD` | `NEEDS_REVIEW`, thông báo SecOps |
| Từ 50 điểm, có đề xuất | `SUSPICIOUS / RULE_THRESHOLD` | `PENDING_APPROVAL`, đợi Step Functions callback |

Ảnh mặc định cần độ tin cậy trung bình từ 85% và ít nhất 20 ký tự chuẩn hóa. Nếu ảnh có QR đọc được nhưng OCR không đạt, chỉ URL từ QR được đưa vào Triage. Với TEXT/EML, ExtractRedact cũng áp dụng ngưỡng ký tự cho luồng tiếp nhận.

Giao diện có hai bộ lọc độc lập cho kết luận và dải điểm luật trên các incident đã tải. Bảng và trang chi tiết hiện “Chưa xác định” bằng nhãn trung tính và ghi riêng điểm luật. `NO_ACTION` mô tả kết quả xử lý. Với incident cũ có điểm nhưng thiếu kết luận, API và Zod dùng `UNKNOWN / LEGACY` khi đọc. Điểm, luật, lịch sử phê duyệt và trạng thái đã lưu vẫn đọc được. Hồ sơ chưa có điểm hiển thị “Chưa chấm điểm”, riêng `NO_ACTION` thiếu toàn bộ policy hiện “Chưa xác định”. Không cần backfill DynamoDB.

## Lời mời nhận trợ cấp

Policy nhận URL có scheme, tiền tố `www.`, dấu chấm defang `[.]`, scheme `hxxp(s)` và `[:]`. Chuẩn hóa IOC dùng IDNA và Public Suffix List đóng gói cùng thư viện. Với URL thiếu scheme, `http` là giá trị quy ước cho khóa đối chiếu. Quá trình này không truy cập URL. URL gốc trong văn bản đã che PII được giữ để đối chiếu.

Một bản sao phục vụ so khớp tách URL khỏi lời văn, bỏ dấu tiếng Việt và xử lý một số dấu chèn giữa hai chữ cái. `LINKED_BENEFIT_CLAIM` cộng 40 khi lời mời nhận tiền/trợ cấp ở gần chỉ dẫn truy cập một URL ngoài allowlist. `URGENCY_PRESSURE` cộng 10 khi có áp lực thời gian. Các ví dụ trong dấu ngoặc kép ngay sau lời cảnh báo được lưu làm bằng chứng, còn chỉ dẫn bên ngoài trích dẫn vẫn được đánh giá. Đây là các mẫu ngôn ngữ hữu hạn.

Với `fixtures/regression/sms.png`, cả ảnh và bản chép thuộc nhóm development `bhtn-sms`. Trên blocklist đánh giá cố định, hai luật cộng thành 50, chưa có căn cứ đề xuất chặn miền. `BLOCK_DOMAIN` cần miền đăng ký hợp lệ xuất hiện trong bằng chứng, nằm ngoài allowlist, có dấu hiệu giả mạo thương hiệu hoặc khớp IOC đang có hiệu lực (`SEED`, `APPROVED_CONFIRMED`). Containment kiểm lại đích và quyết định callback. `DRY_RUN` ghi nhận mô phỏng. `INTERNAL_LIST` chỉ cập nhật danh sách nội bộ sau khi được duyệt.

Synthesize nhận kết luận, luật và playbook để giải thích. Bộ tính điểm, định tuyến và phê duyệt hoạt động độc lập với nội dung trả về từ Bedrock.

## Chạy lại

Từ gốc repo trong PowerShell, dùng Python 3.12 của project với các phụ thuộc trong `requirements-dev.txt`. Script Phase H còn dùng `moto` đã cài trong môi trường workshop.

```powershell
$env:PYTHONPATH = 'src'
.\.venv\Scripts\python -m unittest discover -s tests -v
.\.venv\Scripts\python scripts/check_phase_h_local.py
.\.venv\Scripts\python scripts/day1_checks.py --offline
.\.venv\Scripts\python scripts/evaluate_policy.py --split development --mode text
.\.venv\Scripts\python scripts/evaluate_policy.py --split holdout --mode text
Push-Location frontend
npm.cmd test
npm.cmd run build
Pop-Location
```

`--mode text` đo policy trên văn bản đã che PII, không áp dụng cổng chất lượng ảnh. `--mode ocr` đọc byte ảnh, chạy cùng `extract_document`, Tesseract vie+eng, ZXing, kiểm tra chất lượng/QR, che PII và `score_document` như Lambda. Evaluator tính nhánh tiếp theo, không gọi dịch vụ AWS hoặc thực hiện hành động. Nếu thiếu runtime hoặc tệp ảnh, báo cáo ghi ID lỗi, đánh dấu `INCOMPLETE` và trả mã thoát 1. Chỉ các ca xử lý được tham gia mẫu số. Khi không có dữ liệu, kết quả là `NO_DATA`, metrics bằng null.

Với runtime OCR native có đủ Pillow, tesserocr, zxing-cpp và `OCR_TESSDATA_PATH`, chạy cùng lệnh với `--mode ocr`. Trên Windows có thể dùng hai layer Linux của repo. Các lệnh dưới đây dùng Docker Desktop Linux x86_64, image Python 3.12 và thư mục phụ thuộc Python có sẵn từ SAM build. Mã đang sửa trong `src` có ưu tiên import cao hơn bản build.

```powershell
$pgRoot = (Get-Location).Path
.\.venv\Scripts\python -c "from pathlib import Path; from zipfile import ZipFile; [ZipFile(z).extractall('reports/ocr-linux-layer') for z in Path('layers').glob('*.zip')]"
docker run --rm --network none --read-only --tmpfs /tmp --cap-drop ALL --security-opt no-new-privileges `
  --mount "type=bind,source=$pgRoot/src,target=/work/src,readonly" `
  --mount "type=bind,source=$pgRoot/scripts,target=/work/scripts,readonly" `
  --mount "type=bind,source=$pgRoot/fixtures,target=/work/fixtures,readonly" `
  --mount "type=bind,source=$pgRoot/reports/ocr-linux-layer,target=/opt,readonly" `
  --mount "type=bind,source=$pgRoot/.aws-sam/build/ExtractRedactFunction,target=/deps,readonly" `
  -w /work -e PYTHONDONTWRITEBYTECODE=1 -e OCR_TESSDATA_PATH=/opt/tessdata `
  -e PYTHONPATH=/work/src:/opt/python:/deps python:3.12-slim `
  python scripts/evaluate_policy.py --mode ocr
```

## Dữ liệu và cách tính

- `fixtures/evaluation/config.json` cố định blocklist, chế độ và ngưỡng OCR. `--dataset` chọn thư mục dữ liệu khác cùng cấu trúc.
- `development.jsonl` và `holdout.jsonl` là hai tệp riêng. Mỗi dòng có `id`, `group`, `mode` (text/ocr), một trong `text` hoặc `file` (đường dẫn tương đối với tệp JSONL), `label` (phishing/benign), `source` và `rationale`. OCR bắt buộc dùng file. Có thể dùng một group riêng cho ca độc lập.
- `partitions.json` gán cả nhóm vào một phần. Ảnh, bản chép, bản viết lại và cảnh báo trích mẫu cùng ở một nhóm. Evaluator từ chối nhóm lặp giữa hai phần, ca thuộc sai phần và ID trùng trong cùng tệp. Người lập bộ dữ liệu phải nhận diện các biến thể trước khi chia.
- Chỉ đọc nội dung của phần được chọn. Khi bổ sung holdout, ghi nguồn độc lập và lý do nhãn, khóa nhóm, nhãn, luật và cấu hình trước lần đo. Nếu dùng kết quả để chỉnh luật, chuyển nhóm đó sang development và lấy nhóm độc lập mới cho lần đo sau.
- Dự đoán dương khi policy trả `SUSPICIOUS`. Với nhãn phishing, đây là TP. Với nhãn benign, đây là FP. Mọi ca phishing đã xử lý còn lại đều là FN, gồm `UNKNOWN` và ảnh `NEEDS_MORE_INFO`. Báo riêng số `UNKNOWN` sau chấm điểm và số ảnh thiếu đầu vào. Một ca benign có kết luận `UNKNOWN` không tạo phát hiện đúng. Báo cáo không suy ra độ chính xác tổng thể.
- `manual_review_rate` = số `NEEDS_REVIEW` / số ca đã xử lý. `human_routing_rate` cộng cả `PENDING_APPROVAL` vào tử số. Tệp JSON xuất ra có từng ID, điểm, luật, URL defang, nhánh dự kiến và SHA-256 của đầu vào, tập trường hợp, cấu hình, mã policy.

Kết quả development dùng làm mốc hồi quy trên máy này.

| Đường đo | Số ca | TP | FP | FN | UNKNOWN | NEEDS_REVIEW | PENDING_APPROVAL |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Văn bản | 9 | 3 | 0 | 1 | 6 | 2 | 1 |
| Ảnh qua OCR | 1 | 1 | 0 | 0 | 0 | 1 | 0 |

Ca FN là `unverified-lure`, kịch bản tổng hợp có URL ngoài danh sách và lời mời chung. Năm đối chứng lành tính cũng trả `UNKNOWN`. Ảnh SMS nội bộ đạt độ tin cậy OCR 91,29%. Bản ZIP công khai chỉ giữ vùng tin nhắn ở kích thước gốc để loại số người gửi. Bản cắt đạt 91,17%, cùng hai luật và cùng nhánh xem xét. Cả hai thuộc cùng nhóm development. Một bản thử che toàn bộ tiêu đề đạt 84,74% và dừng ở `NEEDS_MORE_INFO`. Số liệu ảnh và văn bản có chung nguồn SMS, nên đọc riêng hai dòng. Hiện chưa có holdout thực độc lập để đo khả năng khái quát.

## Nội dung cần đồng bộ sang website workshop EN và VI

Hai bản ngôn ngữ của website nằm trong repo Hugo `fcaj-workshop`, dưới `content/5-workshop/`. Bảng dưới đây liên kết nội dung của bản sửa với các phần của workshop. Mục 5.5.5 trên website ghi riêng kết quả cục bộ và lần kiểm chứng AWS.

| Mục website | Nội dung cần đưa lên |
| --- | --- |
| Architecture & Data Flow | Thêm hai trường assessment/reason bên cạnh risk_score/severity, bảng điều kiện định tuyến và cổng OCR/QR ở trên. Mô tả vai trò giải thích bằng playbook của Synthesize. |
| Step-by-step Lab Guide | Gửi văn bản và ảnh SMS bằng hai báo cáo mới. Giữ blocklist ban đầu, ghi lại ID, URL defang, hai luật, 50/100 HIGH, NEEDS_REVIEW và danh sách đề xuất rỗng. |
| Demo | Chụp hàng đợi và chi tiết cho SMS, URL đơn lẻ UNKNOWN/NO_ACTION, ảnh thiếu chất lượng NEEDS_MORE_INFO và IOC đã biết PENDING_APPROVAL. Minh họa hai bộ lọc, điểm luật, nhãn trung tính và bước callback. |
| Testing & Validation | Thêm lệnh evaluator text/OCR, dataset theo nhóm, blocklist cố định, bảng TP/FP/FN/UNKNOWN, mẫu số hai tỷ lệ, nguồn tổng hợp và tình trạng holdout. Ghi ngày, môi trường và phân biệt kiểm tra cục bộ với smoke test AWS. |
| Deployment | Đưa playbook 06 vào prefix S3 `playbooks/` và đồng bộ KB. Build/deploy SAM với tham số stack đã duyệt, phát hành frontend và làm mới index CloudFront. Giải thích cách đọc incident cũ. |
