# PhishGuard AI · Frontend MVP v2.2

React **18.3** + Vite + TypeScript strict + Tailwind CSS + Lucide. Cổng báo cáo và SecOps Dashboard bằng tiếng Việt, có mock độc lập và HTTP API AWS cùng origin.

## Chạy ngay

Cần Node.js **20.19+** (khuyến nghị Node 22 LTS hoặc 24 LTS) và npm.

```bash
cd frontend
npm install
npm run dev
```

Mở **http://127.0.0.1:5173/**. Không cần `.env` để chạy mock; mặc định `VITE_USE_MOCK=true`. Font được đóng gói cùng app, không gọi Google Fonts/CDN. Cần mạng cho lần cài npm đầu tiên; sau đó mock không gọi dịch vụ phân tích ngoài trình duyệt.

```bash
npm test          # Kiểm thử tích hợp, phân quyền, XSS, idempotency, HTTP, Cognito
npm run build    # TypeScript strict + production bundle tại dist/
npm run preview  # Xem bản production vừa build
```

Cổng dev được cố định để callback Cognito ổn định. Nếu 5173 đang được sử dụng, dừng tiến trình cũ hoặc đổi đồng thời cấu hình Vite và callback đã đăng ký. Khi cần truy cập dev từ máy khác, dùng `npm run dev -- --host 0.0.0.0` trong mạng phát triển được kiểm soát.

## Những luồng đã có

| Vai trò      | Gửi báo cáo | Phạm vi sự cố                            | Blocklist / Audit   | Bằng chứng gốc                   | Approve / Reject                       |
| ------------ | ----------- | ---------------------------------------- | ------------------- | -------------------------------- | -------------------------------------- |
| REPORTER     | Có          | Chỉ `reporter_id == jwt.sub`, bản đã che | Không               | Không                            | Không                                  |
| SECOPS_ADMIN | Có          | Toàn bộ                                  | Có, chỉ đọc trên UI | URL 60s, ghi audit trước khi cấp | Khi `PENDING_APPROVAL`                 |
| AUDITOR      | Không       | Toàn bộ, bản đã che                      | Có, chỉ đọc         | Disabled, có giải thích quyền    | Disabled, không có form ghi quyết định |

Mock có bộ chuyển vai trò trên thanh trên cùng. Live không có bộ chuyển vai trò; nhóm lấy từ access token đã kiểm chữ ký. Nếu một người thuộc nhiều nhóm, thứ tự hiển thị là `SECOPS_ADMIN`, `AUDITOR`, `REPORTER`; nên cấp đúng một nhóm cho mỗi tài khoản demo. Backend vẫn phải quyết định quyền trên từng route.

Ba kịch bản:

| Mẫu                                 | Điểm | Mức      | Đề xuất                                  |
| ----------------------------------- | ---: | -------- | ---------------------------------------- |
| DEMO_1 · Ảnh Zalo giả Giám đốc      |   65 | HIGH     | FINANCE_VERIFICATION_ALERT               |
| DEMO_2 · Email giả mạo ngân hàng    |   80 | CRITICAL | BLOCK_DOMAIN · DRY_RUN                   |
| DEMO_3 · Email bẫy Prompt Injection |   80 | CRITICAL | BLOCK_DOMAIN · DRY_RUN, kèm cờ injection |

Điểm không đổi do cờ injection. Mẫu email hiển thị `INDETERMINATE`, không kết luận DMARC từ header khai báo.

Queue có tìm kiếm, lọc trạng thái và severity, sắp xếp và phân trang. Danh sách và chi tiết tự đọc lại khi sự cố đang xử lý trên tab hiển thị. Nút Làm mới dùng để kiểm tra trạng thái bất cứ lúc nào, kể cả khi chờ phê duyệt. Back và Forward của trình duyệt chuyển giữa các màn hình và chi tiết đã mở trong phiên hiện tại. Đường dẫn `/?incident=INC-...#queue` mở thẳng sự cố khi đã đăng nhập. Reporter chỉ mở được sự cố thuộc về mình.

Hộp chi tiết có thang điểm 0–100, luật, cờ injection, cảnh báo header, FALLBACK, văn bản đã che, bảng bằng chứng, IOC, chất lượng OCR, khuyến nghị, RAG và lịch sử quyết định. Mỗi đề xuất hiện đúng `display_target`, `mode`, phiên bản và tác động trước khi duyệt.

Bộ lọc kết luận hoạt động cùng bộ lọc điểm luật và trạng thái xử lý. Nhãn trung tính **Chưa xác định** hiển thị cả với incident cũ thiếu trường kết luận. Chi tiết giải thích khi URL chưa được xác minh hoặc tín hiệu còn thiếu. Xem [hợp đồng API, cách chuyển trạng thái và bộ đánh giá cục bộ](../docs/policy-evaluation-vi.md).

## Cấu hình AWS / Cognito

Sao chép `.env.example` thành `.env.production.local`, đặt `VITE_USE_MOCK=false` và điền các giá trị trước khi build.

```dotenv
VITE_USE_MOCK=false
VITE_COGNITO_REGION=us-east-1
VITE_COGNITO_USER_POOL_ID=us-east-1_YOUR_POOL
VITE_COGNITO_CLIENT_ID=YOUR_PUBLIC_CLIENT_ID
VITE_COGNITO_DOMAIN=https://YOUR_DOMAIN.auth.us-east-1.amazoncognito.com
VITE_COGNITO_REDIRECT_URI=https://YOUR_CLOUDFRONT_DOMAIN/
VITE_COGNITO_LOGOUT_URI=https://YOUR_CLOUDFRONT_DOMAIN/
VITE_COGNITO_SCOPES=openid email profile
VITE_EVIDENCE_ALLOWED_HOSTS=YOUR_EVIDENCE_BUCKET.s3.us-east-1.amazonaws.com,YOUR_EVIDENCE_BUCKET.s3.amazonaws.com
```

Đây là giá trị cấu hình public đi vào bundle. **Không đặt AWS key, mật khẩu hay app-client secret trong biến `VITE_*`.**

Template hiện tại đã tích hợp cấu hình portal. Dùng domain của pool đang triển khai và tham số `CloudFrontOrigin` để bật Authorization Code, đăng ký callback/logout có dấu `/` ở cuối trên app client `PhishGuard-Web`. `CloudFrontDistributionId` cấp quyền đọc web bucket cho distribution có OAC. `DashboardUrl` là URL dashboard trong thông báo SNS.

Với dev live, đăng ký callback đúng `http://127.0.0.1:5173/`, đặt hai URI dev về giá trị đó và chuyển tiếp `/api` qua Vite proxy. Upload trực tiếp sử dụng origin đã được SAM cho phép. Các nhóm của user demo là `REPORTER`, `SECOPS_ADMIN`, `AUDITOR`.

Code kiểm `state`, thời gian phiên PKCE, `nonce` và xác minh access/ID token bằng JWKS Cognito qua `jose`: RS256, issuer, client ID/audience, `token_use`, thời hạn và cùng `sub`. Bearer gửi tới API là **access token**. Refresh token chỉ nằm trong bộ nhớ và được dùng để làm mới access token; không ghi token vào localStorage/sessionStorage hoặc log. sessionStorage chỉ chứa verifier/state/nonce tạm thời và bị xóa khi xử lý callback. Reload trang live yêu cầu đăng nhập lại (phiên managed login có thể hỗ trợ đăng nhập nhanh).

## Hợp đồng HTTP

| Tác vụ                 | Endpoint                                    | Chi tiết                                                                            |
| ---------------------- | ------------------------------------------- | ----------------------------------------------------------------------------------- |
| Tạo phiên upload       | POST `/api/uploads/presign`                 | `{filename, content_type, size}`                                                    |
| Upload trực tiếp S3    | POST URL được ký                            | FormData: toàn bộ `fields` trước, `file` cuối; không JWT, không tự đặt Content-Type |
| Văn bản / mẫu          | POST `/api/reports`                         | `{text, idempotency_key}` hoặc `{sample_id, idempotency_key}`, với mã `sample-1` đến `sample-3` |
| Danh sách / chi tiết   | GET `/api/incidents`, `/api/incidents/{id}` | Parse schema, bỏ trường nội bộ không được khai báo                                  |
| Quyết định             | POST `/api/incidents/{id}/decision`         | Đúng `{decision_id, action_id, proposal_version, decision, note}`                   |
| Bằng chứng             | GET `/api/incidents/{id}/raw-evidence-url`  | Yêu cầu `audit_event_recorded=true`, thời hạn tối đa 60s                            |
| Danh sách chặn / audit | GET `/api/blocklist`, `/api/audit-logs`     | Chỉ Admin/Auditor                                                                   |

`decision_id` tạo một lần cho từng user/sự cố/action/version. Ngay lần gửi đầu, toàn bộ payload bị đóng băng; khi mất mạng, nút thử lại gửi nguyên mã, quyết định và ghi chú. Có khóa đồng bộ chống bấm đúp. Báo cáo TEXT cũng giữ payload và key khi lỗi; upload giữ phiên hiện tại để thử lại. HTTP 409 `IDEMPOTENCY_KEY_REUSED` có thông báo riêng và lựa chọn bắt đầu báo cáo mới.

Đặc tả đầu vào không chốt envelope danh sách và ACK của decision. Bộ chuyển đổi tại `src/lib/live-api.ts` hỗ trợ array thuần, `{items, next_token}`, hoặc `{incidents|blocklist|audit_logs, next_token}`. Nếu có cursor, gửi `?next_token=...`; số liệu/lọc chỉ áp dụng trên dữ liệu đã tải. Sửa bộ chuyển đổi này nếu backend dùng envelope/cursor khác. Decision chấp nhận ACK/204 rồi đọc lại IncidentDetail. Audit hỗ trợ `timestamp` hoặc khóa `timestamp_action` của đặc tả (lấy phần trước `#` làm thời gian hiển thị).

Sau khi cấp URL raw có audit, UI hiện liên kết **Mở / tải tệp gốc** tới tài nguyên được ký trong tối đa 60 giây. Liên kết mở riêng với `noopener noreferrer`; không nhúng HTML/EML vào ứng dụng và không fetch GET bằng JavaScript, nên không cần CORS GET bổ sung cho evidence bucket. Nên ký thêm `ResponseContentDisposition=attachment` ở backend để trình duyệt luôn tải tệp. Không thể thu hồi bản đã tải về khi URL hết hạn. `VITE_EVIDENCE_ALLOWED_HOSTS` đối chiếu hostname chính xác, hỗ trợ danh sách phân tách bằng dấu phẩy; URL live luôn phải HTTPS, không userinfo.

## Triển khai static lên S3 / CloudFront

1. Build với env live đã điền: `npm run build`. Upload **nội dung `dist/`**, không phải source hay node_modules, tới bucket web private có OAC.
2. CloudFront mặc định phục vụ S3 web; behavior `/api/*` đi tới HTTP API Gateway, **CachingDisabled**, chuyển tiếp `Authorization` (ví dụ AllViewerExceptHostHeader). Trình duyệt luôn gọi API cùng origin. Không dùng proxy dev trong bản production.
3. Intake bucket cho phép origin CloudFront POST theo CORS của backend. Chính sách presigned POST và kiểm tra magic bytes vẫn do backend thực thi.
4. Có thể dùng `deploy/cloudfront-spa-router.js` trên viewer-request của behavior web để hỗ trợ đường dẫn SPA. Không rewrite `/api/*` và không biến API 401/403/404 thành `index.html`.
5. Đặt `index.html` Cache-Control ngắn hoặc no-cache; assets có hash có thể cache dài. Invalidate index sau khi phát hành. Chưa thực hiện triển khai AWS trong gói này.

`index.html` có CSP cơ bản. Khi triển khai, thêm response headers `frame-ancestors 'none'` (CSP HTTP header), `X-Content-Type-Options: nosniff`, `Referrer-Policy: no-referrer`, HSTS trên HTTPS; thu hẹp `connect-src` theo origin app, Cognito token/JWKS và intake S3 thực tế. CSP meta không hỗ trợ `frame-ancestors`. Dev cần WebSocket và inline style; điều chỉnh CSP production sau khi kiểm tra origin thực tế.

## Phạm vi mock

- Dữ liệu mẫu, báo cáo đã che, trạng thái, Blocklist và Audit lưu trong localStorage dưới khóa `phishguard.mock.v2.2.1`. Chuyển vai trò giữ dữ liệu nhưng làm mới toàn bộ state UI để tránh lộ dữ liệu của vai trò trước.
- Các mẫu cố định có đúng kết quả đặc tả. Báo cáo văn bản/EML thuần dùng luật mô phỏng và tổng hợp FALLBACK; đây không phải bản tái hiện đầy đủ PSL, MIME parser, PII detector hoặc Policy Engine backend. Không có Bedrock, Textract, RAG hay dịch vụ gửi thông báo thật trong mock.
- Ảnh và EML multipart/base64/quoted-printable được tiếp nhận rồi chuyển NEEDS_MORE_INFO thay vì tạo kết quả OCR giả. File phải có 1–5.242.880 byte, đuôi `.eml`, `.png`, `.jpg`, `.jpeg`, `.txt`; MIME được suy ra từ đuôi để hỗ trợ EML không có MIME do trình duyệt cung cấp.
- Báo cáo mới đi NEW → TRIAGING → kết quả sau khoảng 1,6 giây. Đặt `VITE_MOCK_APPROVAL_TIMEOUT_SECONDS=60` rồi chạy lại dev để thử TIMEOUT trên báo cáo mới. Đây chỉ là tham số mock; timeout AWS do backend/deployment cấu hình, không do người dùng frontend điều khiển.
- APPROVE DRY_RUN → SIMULATED; chỉ ghi nguồn APPROVED_DRY_RUN, không làm IOC đó kích hoạt KNOWN_BLOCKED_IOC. INTERNAL_LIST → INTERNAL_LIST_UPDATED. REJECT không thêm IOC. Timeout → ESCALATED_TIMEOUT, quyết định muộn trả 409.
- Mock chống ghi đè quyết định trong một tab bằng hàng đợi và qua các tab bằng Web Locks khi trình duyệt hỗ trợ. Audit chỉ thêm qua mock service, không có UI sửa/xóa. localStorage vẫn có thể sửa qua DevTools; đây không phải cơ chế audit bất biến hay RBAC bảo mật thật.
- Bằng chứng nguyên bản do người dùng gửi chỉ nằm trong bộ nhớ của phiên trang, không ghi PII nguyên bản vào localStorage. Sau reload, kết quả đã che vẫn còn nhưng xin raw của báo cáo đó báo cần gửi lại. Fixture seed có bằng chứng minh họa. Mock URL dạng blob được thu hồi khi hết hạn/đóng chi tiết và buộc tải dạng octet-stream.
- Để khởi tạo lại demo, xóa riêng khóa localStorage trên trong DevTools rồi tải lại. Không có API hay nút xóa audit trong sản phẩm.

## Giới hạn bảo mật cần giữ khi tích hợp

Tất cả văn bản không tin cậy đi qua plain-text JSX, không dùng `dangerouslySetInnerHTML` hoặc iframe. IOC dùng `display_value`/`display_target` và defang bổ sung; không tạo link đến URL nghi ngờ. Blocklist canonical hiển thị dạng văn bản thuần theo yêu cầu. Link raw có chữ ký do API cấp là đường tải tài nguyên riêng, không phải IOC.

Frontend không thay thế kiểm soát server: Lambda/API Gateway vẫn phải xác minh JWT, nhóm, sở hữu, version/target, conditional write, idempotency và ghi audit trước cấp URL. Backend phải chỉ trả PII đã che và loại bỏ sfn_task_token, raw_s3_key, sfn_execution_arn theo vai trò. Parse schema trên frontend là lớp phòng vệ bổ sung. Bộ che PII có giới hạn, đặc biệt tên người/địa chỉ.

## Cấu trúc

```text
frontend/
  .env.example
  package.json / package-lock.json
  index.html / vite.config.ts / tsconfig.json
  tailwind.config.js / postcss.config.js
  public/favicon.svg
  deploy/cloudfront-spa-router.js
  src/
    App.tsx / main.tsx / styles.css / config.ts / types.ts
    components/   Queue, Submit, IncidentDetail, Registers, UI primitives
    lib/          Cognito PKCE, live HTTP adapter, hooks, security helpers
    mock/         Fixtures và mock API có kiểm quyền, workflow, idempotency
```

Các test nằm cạnh phần code được kiểm tra (`*.test.ts`, `*.test.tsx`). Chúng kiểm quyền/sở hữu, điểm mẫu, PII, IOC, timeout, quyết định đồng thời/gửi lại, append-only qua service, trường upload theo thứ tự, JWT không đi S3, schema audit, XSS trong DOM, chuyển role và callback Cognito với JWT ký thật bằng khóa test.

Tham chiếu triển khai Cognito: [Authorization endpoint](https://docs.aws.amazon.com/cognito/latest/developerguide/authorization-endpoint.html), [Token endpoint](https://docs.aws.amazon.com/cognito/latest/developerguide/token-endpoint.html), [Public app clients](https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-settings-client-apps.html). FormData: [MDN append](https://developer.mozilla.org/en-US/docs/Web/API/FormData/append).
