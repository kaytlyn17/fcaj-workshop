# Verification snapshot · 2026-11-13

- `npm test` passed all 31 tests. The added regression check covers regeneration of a new report key and reuse of the exact submitted request after an error.
- TypeScript and Vite built both the mock and live profiles. The included `dist/` contains the mock build.
- The API, auth, mocks, Spec v2.2 types, environment config, and npm manifests match the previous archive byte for byte.
- The state and request handling blocks for navigation, queue filters and pagination, reports, both registers, incident detail, and approval match the previous archive.
- The frontend renders seven incidents per queue page and formats timestamps in UTC to the second.

The browser preview could not connect to the local server, so the number of rows simultaneously visible in a browser viewport was not verified. Live mode was compiled without a live AWS integration test.

## Phase G integration

- `npm test` passed all 34 tests, including the contract used by Reporter API and the deployed workflow's incident fields.
- TypeScript and Vite built the live mode with test configuration.
- `git apply --check` passed against the referenced backend, and the updated AWS template passed `cfn-lint` for `us-east-1`.
- Live AWS login, browser upload, and SNS links are deployment checks.
