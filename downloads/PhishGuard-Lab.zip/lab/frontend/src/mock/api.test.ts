import { beforeEach, describe, expect, it, vi } from "vitest";
import { webcrypto } from "node:crypto";
import { mockApi, MOCK_DB_KEY } from "./api";
import { mockUsers } from "../lib/auth";
import type { DecisionRequest, ReportRequest } from "../types";
const admin = mockUsers.SECOPS_ADMIN,
  reporter = mockUsers.REPORTER,
  auditor = mockUsers.AUDITOR;
const sample = (
  sample_id: "DEMO_1" | "DEMO_2" | "DEMO_3",
  key = "sample_key_0001",
): ReportRequest => ({
  report_type: "SAMPLE",
  sample_id,
  text_content: null,
  idempotency_key: key,
});
const decision = (decision_id = "dec_test_1"): DecisionRequest => ({
  decision_id,
  action_id: "ACT-001",
  proposal_version: 1,
  decision: "APPROVE",
  note: "Đã xác minh bằng chứng.",
});
beforeEach(() => {
  localStorage.clear();
  vi.useRealTimers();
  vi.stubGlobal("crypto", webcrypto);
});
describe("RBAC and ownership in mock service", () => {
  it("restricts reporter list and detail to owned incidents", async () => {
    const own = await mockApi.incidents(reporter);
    expect(own.items.length).toBeGreaterThan(0);
    expect(own.items.every((i) => i.reporter_id === reporter.sub)).toBe(true);
    const all = await mockApi.incidents(admin);
    const other = all.items.find((i) => i.reporter_id !== reporter.sub)!;
    await expect(
      mockApi.incident(reporter, other.incident_id),
    ).rejects.toMatchObject({ status: 404 });
  });
  it("denies privileged reads to reporter and all writes to auditor", async () => {
    await expect(mockApi.blocklist(reporter)).rejects.toMatchObject({
      status: 403,
    });
    await expect(mockApi.auditLogs(reporter)).rejects.toMatchObject({
      status: 403,
    });
    await expect(
      mockApi.rawEvidence(auditor, "INC-903B7C2D11E4"),
    ).rejects.toMatchObject({ status: 403 });
    await expect(
      mockApi.decision(auditor, "INC-903B7C2D11E4", decision()),
    ).rejects.toMatchObject({ status: 403 });
    await expect(
      mockApi.report(auditor, sample("DEMO_1")),
    ).rejects.toMatchObject({ status: 403 });
    await expect(
      mockApi.presign(auditor, {
        filename: "a.txt",
        size: 4,
        content_type: "text/plain",
      }),
    ).rejects.toMatchObject({ status: 403 });
    expect((await mockApi.auditLogs(auditor)).items.length).toBeGreaterThan(0);
  });
});
describe("intake and workflow contracts", () => {
  it("requests input for short text without assigning a rule score", async () => {
    vi.useFakeTimers();
    const receipt = await mockApi.report(reporter, {
      report_type: "TEXT", sample_id: null, text_content: "Thiếu chữ", idempotency_key: "short_input_test",
    });
    vi.advanceTimersByTime(2000);
    expect(await mockApi.incident(reporter, receipt.incident_id)).toMatchObject({
      status: "NEEDS_MORE_INFO", policy_evaluation: null, requires_manual_review: false, proposed_actions: [],
    });
  });
  it.each([
    ["NHAN'TIEN ho tro. Bam'vao www.vnbomo[.]icu de lay. QUA_HAN se mat quyen.", "SUSPICIOUS", "NEEDS_REVIEW", 50],
    ["Truy cập www[.]benefits.example.org để lĩnh trợ cấp trước 17 giờ.", "SUSPICIOUS", "NEEDS_REVIEW", 50],
    ["Cảnh báo lừa đảo: “Bấm vào www.example.org để nhận tiền trước 17 giờ”.", "UNKNOWN", "NO_ACTION", 0],
    ["Xem thời gian biểu tại www.calendar.example.org.", "UNKNOWN", "NO_ACTION", 0],
  ])("separates the assessment from workflow for %s", async (text, assessment, status, score) => {
    vi.useFakeTimers();
    const receipt = await mockApi.report(reporter, {
      report_type: "TEXT", sample_id: null, text_content: String(text), idempotency_key: "test_sms_policy",
    });
    vi.advanceTimersByTime(2000);
    const item = await mockApi.incident(reporter, receipt.incident_id);
    expect(item.status).toBe(status);
    expect(item.policy_evaluation).toMatchObject({ assessment, risk_score: score });
    expect(item.proposed_actions).toEqual([]);
    expect(item.deterministic_findings?.extracted_urls).toHaveLength(1);
  });
  it("has exact sample scores and invariant injection score", async () => {
    const results = await Promise.all(
      ["DEMO_1", "DEMO_2", "DEMO_3"].map((id, index) =>
        mockApi.report(
          reporter,
          sample(id as "DEMO_1", `demo_test_000${index}`),
        ),
      ),
    );
    const items = await Promise.all(
      results.map((r) => mockApi.incident(reporter, r.incident_id)),
    );
    expect(items.map((i) => i.policy_evaluation?.risk_score)).toEqual([
      65, 80, 80,
    ]);
    expect(items[0].proposed_actions[0].type).toBe(
      "FINANCE_VERIFICATION_ALERT",
    );
    expect(items[1].email_auth?.result).toBe("INDETERMINATE");
    expect(items[2].security_flags).toContain("PROMPT_INJECTION_DETECTED");
  });
  it("returns same incident on retry and rejects key reuse with different content", async () => {
    const body = sample("DEMO_2");
    const first = await mockApi.report(reporter, body);
    const second = await mockApi.report(reporter, body);
    expect(first.incident_id).toBe(second.incident_id);
    await expect(
      mockApi.report(reporter, sample("DEMO_3")),
    ).rejects.toMatchObject({ status: 409, code: "IDEMPOTENCY_KEY_REUSED" });
    await expect(
      mockApi.report(reporter, sample("DEMO_1", "bad")),
    ).rejects.toMatchObject({ status: 400 });
  });
  it("moves NEW through workflow and expires approval exactly once", async () => {
    vi.useFakeTimers();
    const r = await mockApi.report(
      reporter,
      sample("DEMO_2", "timeout_sample_01"),
    );
    expect((await mockApi.incident(reporter, r.incident_id)).status).toBe(
      "TRIAGING",
    );
    vi.advanceTimersByTime(2000);
    const pending = await mockApi.incident(admin, r.incident_id);
    expect(pending.status).toBe("PENDING_APPROVAL");
    vi.setSystemTime(Date.parse(pending.approval_expires_at!) + 1);
    await expect(
      mockApi.decision(admin, r.incident_id, decision()),
    ).rejects.toMatchObject({ status: 409, code: "APPROVAL_EXPIRED" });
    expect((await mockApi.incident(admin, r.incident_id)).status).toBe(
      "ESCALATED_TIMEOUT",
    );
    await mockApi.incidents(admin);
    expect(
      (await mockApi.auditLogs(admin)).items.filter(
        (a) => a.incident_id === r.incident_id && a.action === "TIMEOUT",
      ),
    ).toHaveLength(1);
  });
  it("redacts target PII without persisting source report text", async () => {
    const raw =
      "Chuyển gấp vào tài khoản 123456789012. OTP 987654. CCCD 079123456789. Gọi 0901234567. Email alice@example.com";
    const r = await mockApi.report(reporter, {
      report_type: "TEXT",
      sample_id: null,
      text_content: raw,
      idempotency_key: "redaction_test_01",
    });
    const i = await mockApi.incident(reporter, r.incident_id);
    const serialized = JSON.stringify(i);
    for (const secret of [
      "123456789012",
      "987654",
      "079123456789",
      "0901234567",
      "alice@",
    ])
      expect(serialized).not.toContain(secret);
    expect(i.deterministic_findings?.redacted_counts).toMatchObject({
      BANK: 1,
      OTP: 1,
      CCCD: 1,
      PHONE: 1,
      EMAIL: 1,
    });
    expect(localStorage.getItem(MOCK_DB_KEY)).not.toContain(raw);
  });
  it("matches effective blocklist entries but excludes DRY_RUN", async () => {
    const known = await mockApi.report(reporter, {
      report_type: "TEXT",
      sample_id: null,
      text_content: "Xem https://secure-bank-update.example",
      idempotency_key: "known_ioc_test_01",
    });
    const dry = await mockApi.report(reporter, {
      report_type: "TEXT",
      sample_id: null,
      text_content: "Xem https://login.techc0mbank-vn.com",
      idempotency_key: "dryrun_ioc_test_01",
    });
    expect(
      (
        await mockApi.incident(reporter, known.incident_id)
      ).policy_evaluation?.triggered_rules.some(
        (r) => r.rule_id === "KNOWN_BLOCKED_IOC",
      ),
    ).toBe(true);
    expect(
      (
        await mockApi.incident(reporter, dry.incident_id)
      ).policy_evaluation?.triggered_rules.some(
        (r) => r.rule_id === "KNOWN_BLOCKED_IOC",
      ),
    ).toBe(false);
  });
  it("accepts image upload and requests more evidence without fake OCR", async () => {
    vi.useFakeTimers();
    const file = new File(["image-bytes"], "evidence.png", {
      type: "image/png",
    });
    const session = await mockApi.presign(reporter, {
      filename: file.name,
      size: file.size,
      content_type: file.type,
    });
    expect(session.status).toBe("UPLOAD_PENDING");
    await mockApi.upload(reporter, session, file);
    await mockApi.upload(reporter, session, file);
    vi.advanceTimersByTime(2000);
    const item = await mockApi.incident(reporter, session.incident_id);
    expect(item.status).toBe("NEEDS_MORE_INFO");
    expect(item.policy_evaluation).toBeNull();
    expect(item.ocr_quality?.engine).toBe("MOCK_UNAVAILABLE");
  });
});
describe("human decision and append-only records", () => {
  it("serializes simultaneous conflicting decisions without overwriting history", async () => {
    const id = "INC-903B7C2D11E4";
    const results = await Promise.allSettled([
      mockApi.decision(admin, id, decision("race_1")),
      mockApi.decision(admin, id, {
        ...decision("race_2"),
        decision: "REJECT",
      }),
    ]);
    expect(results.filter((r) => r.status === "fulfilled")).toHaveLength(1);
    expect(results.filter((r) => r.status === "rejected")).toHaveLength(1);
    const logs = (await mockApi.auditLogs(admin)).items.filter(
      (a) => a.incident_id === id && ["APPROVE", "REJECT"].includes(a.action),
    );
    expect(logs).toHaveLength(1);
  });
  it("applies approval once across retry and blocks contradictory decisions", async () => {
    const id = "INC-903B7C2D11E4";
    const body = decision();
    await mockApi.decision(admin, id, body);
    await mockApi.decision(admin, id, body);
    const item = await mockApi.incident(admin, id);
    expect(item.status).toBe("SIMULATED");
    expect(
      (await mockApi.auditLogs(admin)).items.filter(
        (a) => a.incident_id === id && a.decision_id === body.decision_id,
      ),
    ).toHaveLength(1);
    expect(
      (await mockApi.blocklist(admin)).items.find((b) => b.incident_id === id)
        ?.source,
    ).toBe("APPROVED_DRY_RUN");
    await expect(
      mockApi.decision(admin, id, { ...body, decision: "REJECT" }),
    ).rejects.toMatchObject({ status: 409 });
    await expect(
      mockApi.decision(admin, "INC-61A7F0B2C903", {
        ...decision("other"),
        proposal_version: 99,
      }),
    ).rejects.toMatchObject({ status: 409 });
  });
  it("rejects without adding a blocklist entry", async () => {
    const before = (await mockApi.blocklist(admin)).items.length;
    await mockApi.decision(admin, "INC-8F3A19C04B2E", {
      ...decision("reject-test"),
      decision: "REJECT",
    });
    expect((await mockApi.incident(admin, "INC-8F3A19C04B2E")).status).toBe(
      "REJECTED",
    );
    expect((await mockApi.blocklist(admin)).items).toHaveLength(before);
  });
  it("records every raw URL grant before returning it", async () => {
    vi.stubGlobal(
      "URL",
      class extends URL {
        static createObjectURL() {
          return "blob:test-evidence";
        }
      },
    );
    const original = (await mockApi.auditLogs(admin)).items;
    const r = await mockApi.rawEvidence(admin, "INC-903B7C2D11E4");
    expect(r).toMatchObject({
      expires_in_seconds: 60,
      audit_event_recorded: true,
    });
    const after = (await mockApi.auditLogs(admin)).items;
    expect(after.length).toBe(original.length + 1);
    expect(after[0].action).toBe("VIEW_RAW_EVIDENCE");
    expect(after.slice(1)).toEqual(original);
  });
});
