export const config = {
  useMock: import.meta.env.VITE_USE_MOCK !== "false",
  region: import.meta.env.VITE_COGNITO_REGION || "us-east-1",
  userPoolId: import.meta.env.VITE_COGNITO_USER_POOL_ID || "",
  clientId: import.meta.env.VITE_COGNITO_CLIENT_ID || "",
  domain: (import.meta.env.VITE_COGNITO_DOMAIN || "").replace(/\/$/, ""),
  redirectUri:
    import.meta.env.VITE_COGNITO_REDIRECT_URI || `${window.location.origin}/`,
  logoutUri:
    import.meta.env.VITE_COGNITO_LOGOUT_URI || `${window.location.origin}/`,
  scopes: import.meta.env.VITE_COGNITO_SCOPES || "openid email profile",
  evidenceHosts: (import.meta.env.VITE_EVIDENCE_ALLOWED_HOSTS || "")
    .split(",")
    .map((s: string) => s.trim())
    .filter(Boolean) as string[],
  mockTimeoutSeconds: Math.max(
    1,
    Number(import.meta.env.VITE_MOCK_APPROVAL_TIMEOUT_SECONDS) || 172800,
  ),
};
