import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { webcrypto } from "node:crypto";
import { SignJWT, exportJWK, generateKeyPair } from "jose";
const issuer = "https://cognito-idp.us-east-1.amazonaws.com/us-east-1_TestPool";
beforeEach(() => {
  vi.resetModules();
  vi.stubGlobal("crypto", webcrypto);
  localStorage.clear();
  sessionStorage.clear();
  vi.stubEnv("VITE_USE_MOCK", "false");
  vi.stubEnv("VITE_COGNITO_REGION", "us-east-1");
  vi.stubEnv("VITE_COGNITO_USER_POOL_ID", "us-east-1_TestPool");
  vi.stubEnv("VITE_COGNITO_CLIENT_ID", "test-public-client");
  vi.stubEnv(
    "VITE_COGNITO_DOMAIN",
    "https://test.auth.us-east-1.amazoncognito.com",
  );
  sessionStorage.setItem(
    "phishguard.oauth.pkce",
    JSON.stringify({
      state: "verified-state",
      verifier: "a".repeat(64),
      nonce: "expected-nonce",
      created: Date.now(),
    }),
  );
  history.replaceState(null, "", "/?code=one-time-code&state=verified-state");
});
afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  history.replaceState(null, "", "/");
});
async function tokens(nonce = "expected-nonce", tampered = false) {
  const pair = await generateKeyPair("RS256", { extractable: true });
  const other = await generateKeyPair("RS256");
  const jwk = await exportJWK(pair.publicKey);
  jwk.kid = "test-key";
  jwk.alg = "RS256";
  jwk.use = "sig";
  const access = await new SignJWT({
    token_use: "access",
    client_id: "test-public-client",
    "cognito:groups": ["AUDITOR"],
    username: "audit-user",
  })
    .setProtectedHeader({ alg: "RS256", kid: "test-key" })
    .setSubject("test-sub")
    .setIssuer(issuer)
    .setIssuedAt()
    .setExpirationTime("1h")
    .sign(tampered ? other.privateKey : pair.privateKey);
  const identity = await new SignJWT({
    token_use: "id",
    nonce,
    email: "audit@example.com",
    name: "Audit User",
  })
    .setProtectedHeader({ alg: "RS256", kid: "test-key" })
    .setSubject("test-sub")
    .setIssuer(issuer)
    .setAudience("test-public-client")
    .setIssuedAt()
    .setExpirationTime("1h")
    .sign(pair.privateKey);
  const fetcher = vi.fn(async (input: RequestInfo | URL) =>
    String(input).endsWith("/oauth2/token")
      ? new Response(
          JSON.stringify({
            access_token: access,
            id_token: identity,
            expires_in: 3600,
            refresh_token: "in-memory-refresh",
          }),
          { headers: { "Content-Type": "application/json" } },
        )
      : new Response(JSON.stringify({ keys: [jwk] }), {
          headers: { "Content-Type": "application/json" },
        }),
  );
  vi.stubGlobal("fetch", fetcher);
  return { access, fetcher };
}
describe("Cognito PKCE callback verification", () => {
  it("verifies JWT signatures/issuer/client/nonce, derives groups, and keeps tokens out of storage", async () => {
    const { access, fetcher } = await tokens();
    const auth = await import("./auth");
    expect(await auth.initializeAuth()).toEqual({
      sub: "test-sub",
      name: "Audit User",
      email: "audit@example.com",
      role: "AUDITOR",
    });
    expect(await auth.accessToken()).toBe(access);
    expect(localStorage.length).toBe(0);
    expect(sessionStorage.length).toBe(0);
    expect(location.search).toBe("");
    const tokenCall = fetcher.mock.calls.find((c) =>
      String(c[0]).endsWith("/oauth2/token"),
    );
    expect(tokenCall).toBeDefined();
  });
  it("rejects a forged access-token signature", async () => {
    await tokens("expected-nonce", true);
    const auth = await import("./auth");
    await expect(auth.initializeAuth()).rejects.toThrow();
  });
  it("rejects nonce mismatch and consumes PKCE state", async () => {
    await tokens("wrong-nonce");
    const auth = await import("./auth");
    await expect(auth.initializeAuth()).rejects.toThrow("nonce");
    expect(sessionStorage.getItem("phishguard.oauth.pkce")).toBeNull();
  });
  it("rejects OAuth state mismatch before exchanging credentials", async () => {
    history.replaceState(null, "", "/?code=one-time-code&state=attacker-state");
    const fetcher = vi.fn();
    vi.stubGlobal("fetch", fetcher);
    const auth = await import("./auth");
    await expect(auth.initializeAuth()).rejects.toThrow("không hợp lệ");
    expect(fetcher).not.toHaveBeenCalled();
  });
});
