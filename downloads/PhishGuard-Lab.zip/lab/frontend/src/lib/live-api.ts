import { z } from "zod";
import { config } from "../config";
import {
  auditSchema,
  blockSchema,
  statuses,
  type Api,
  type Page,
  type PresignResponse,
  type RawResponse,
} from "../types";
import { accessToken } from "./auth";
import { backendIncidentSchema, reportBody } from "./backend-contract";
import { ApiError, assertRole, safeHttpsUrl, validateFile } from "./security";

async function request(path: string, init: RequestInit = {}): Promise<unknown> {
  const token = await accessToken();
  let response: Response;
  try {
    response = await fetch(`/api${path}`, {
      ...init,
      headers: {
        Accept: "application/json",
        ...(init.body ? { "Content-Type": "application/json" } : {}),
        ...init.headers,
        Authorization: `Bearer ${token}`,
      },
      cache: "no-store",
      credentials: "omit",
      signal: AbortSignal.timeout(25000),
      redirect: "error",
    });
  } catch {
    throw new ApiError(
      0,
      "NETWORK_ERROR",
      "Kết nối bị gián đoạn. Bạn có thể thử lại; mã yêu cầu sẽ được giữ nguyên.",
    );
  }
  const text = await response.text();
  let data: unknown;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    throw new ApiError(
      response.status,
      "INVALID_RESPONSE",
      "API không trả JSON.",
    );
  }
  if (!response.ok) {
    const e =
      data && typeof data === "object" ? (data as Record<string, unknown>) : {};
    const nested =
      e.error && typeof e.error === "object"
        ? (e.error as Record<string, unknown>)
        : e;
    const code =
      typeof nested.code === "string"
        ? nested.code
        : typeof e.error === "string"
          ? e.error
          : response.status === 401
            ? "UNAUTHORIZED"
            : response.status === 403
              ? "FORBIDDEN"
              : response.status === 409
                ? "DECISION_CONFLICT"
                : "HTTP_ERROR";
    throw new ApiError(
      response.status,
      code,
      typeof nested.message === "string"
        ? nested.message
        : `API trả lỗi HTTP ${response.status}.`,
    );
  }
  return data;
}
function parse<S extends z.ZodTypeAny>(schema: S, value: unknown): z.output<S> {
  const r = schema.safeParse(value);
  if (!r.success)
    throw new ApiError(502, "INVALID_RESPONSE", "Phản hồi không khớp schema.");
  return r.data;
}
// {items,next_token}, hoặc {incidents|blocklist|audit_logs,next_token}.
function page<S extends z.ZodTypeAny>(
  value: unknown,
  schema: S,
  key: string,
): Page<z.output<S>> {
  if (Array.isArray(value)) return { items: parse(z.array(schema), value) };
  if (value && typeof value === "object") {
    const data = value as Record<string, unknown>;
    const items = data.items ?? data[key];
    const token = data.next_token;
    if (token !== undefined && token !== null && typeof token !== "string")
      throw new ApiError(502, "INVALID_RESPONSE", "Cursor không hợp lệ.");
    return {
      items: parse(z.array(schema), items),
      next_token: typeof token === "string" && token ? token : undefined,
    };
  }
  throw new ApiError(502, "INVALID_RESPONSE", "Danh sách không hợp lệ.");
}
const query = (token?: string) =>
  token ? `?next_token=${encodeURIComponent(token)}` : "";
const idPath = (id: string) => `/incidents/${encodeURIComponent(id)}`;
const presignSchema = z.object({
  upload_id: z.string(),
  incident_id: z.string(),
  status: z.literal("UPLOAD_PENDING").default("UPLOAD_PENDING"),
  presigned_post: z.object({
    url: z.string(),
    fields: z.record(z.string(), z.string()),
  }),
});
export const liveApi: Api = {
  incidents: async (user, token) => {
    const result = page(
      await request(`/incidents${query(token)}`),
      backendIncidentSchema,
      "incidents",
    );
    if (user.role === "REPORTER")
      result.items = result.items.filter((i) => i.reporter_id === user.sub);
    return result;
  },
  incident: async (user, id) => {
    const item = parse(backendIncidentSchema, await request(idPath(id)));
    if (user.role === "REPORTER" && item.reporter_id !== user.sub)
      throw new ApiError(403, "FORBIDDEN", "Sự cố nằm ngoài phạm vi quyền.");
    return item;
  },
  report: async (user, body) => {
    assertRole(user.role, ["SECOPS_ADMIN", "REPORTER"]);
    return parse(
      z.object({
        incident_id: z.string(),
        status: z.enum(statuses),
        source_intake_key: z.string().optional(),
      }),
      await request("/reports", { method: "POST", body: JSON.stringify(reportBody(body)) }),
    );
  },
  presign: async (user, body) => {
    assertRole(user.role, ["SECOPS_ADMIN", "REPORTER"]);
    return parse(
      presignSchema,
      await request("/uploads/presign", {
        method: "POST",
        body: JSON.stringify(body),
      }),
    ) as PresignResponse;
  },
  upload: async (user, session, file) => {
    assertRole(user.role, ["SECOPS_ADMIN", "REPORTER"]);
    validateFile(file);
    const url = safeHttpsUrl(session.presigned_post.url);
    const form = new FormData();
    Object.entries(session.presigned_post.fields).forEach(([k, v]) =>
      form.append(k, v),
    );
    form.append("file", file); // File là trường cuối. Không gắn JWT hay Content-Type vào S3 POST.
    const res = await fetch(url, {
      method: "POST",
      body: form,
      credentials: "omit",
      redirect: "error",
      signal: AbortSignal.timeout(60000),
    });
    if (!res.ok)
      throw new ApiError(
        res.status,
        "UPLOAD_FAILED",
        "Tải tệp lên S3 chưa thành công. Thử lại để dùng tiếp phiên upload hiện tại.",
      );
  },
  decision: async (user, id, body) => {
    assertRole(user.role, ["SECOPS_ADMIN"]);
    const result = await request(`${idPath(id)}/decision`, {
      method: "POST",
      body: JSON.stringify(body),
    });
    // Backend có thể trả ACK thay vì IncidentDetail; UI luôn đọc lại chi tiết.
    if (result && typeof result === "object" && "policy_evaluation" in result)
      return parse(backendIncidentSchema, result);
  },
  rawEvidence: async (user, id) => {
    assertRole(user.role, ["SECOPS_ADMIN"]);
    const data = parse(
      z.object({
        presigned_url: z.string(),
        expires_in_seconds: z.number().positive().max(60),
        audit_event_recorded: z.literal(true),
      }),
      await request(`${idPath(id)}/raw-evidence-url`),
    );
    safeHttpsUrl(data.presigned_url, config.evidenceHosts);
    return data as RawResponse;
  },
  blocklist: async (user, token) => {
    assertRole(user.role, ["SECOPS_ADMIN", "AUDITOR"]);
    return page(
      await request(`/blocklist${query(token)}`),
      blockSchema,
      "blocklist",
    );
  },
  auditLogs: async (user, token) => {
    assertRole(user.role, ["SECOPS_ADMIN", "AUDITOR"]);
    return page(
      await request(`/audit-logs${query(token)}`),
      auditSchema,
      "audit_logs",
    );
  },
};
