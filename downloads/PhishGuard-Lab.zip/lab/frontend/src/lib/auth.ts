import { createRemoteJWKSet, jwtVerify, type JWTPayload } from "jose";
import { config } from "../config";
import { roles, type Role, type User } from "../types";
import { ApiError, newId, safeHttpsUrl } from "./security";

interface Session {
  accessToken: string;
  refreshToken?: string;
  expiresAt: number;
  user: User;
}
interface Tokens {
  access_token: string;
  id_token?: string;
  refresh_token?: string;
  expires_in: number;
}
let session: Session | null = null;
let initialization: Promise<User | null> | undefined;
let refreshing: Promise<string> | undefined;
const issuer = `https://cognito-idp.${config.region}.amazonaws.com/${config.userPoolId}`;
let keys: ReturnType<typeof createRemoteJWKSet> | undefined;
const pkceKey = "phishguard.oauth.pkce";

export const mockUsers: Record<Role, User> = {
  SECOPS_ADMIN: {
    sub: "admin-demo",
    name: "Minh Anh",
    email: "secops@example.com",
    role: "SECOPS_ADMIN",
  },
  REPORTER: {
    sub: "reporter-demo",
    name: "Lan Nguyễn",
    email: "lan.nguyen@example.com",
    role: "REPORTER",
  },
  AUDITOR: {
    sub: "auditor-demo",
    name: "Hoàng Trần",
    email: "auditor@example.com",
    role: "AUDITOR",
  },
};
function requireConfig() {
  if (!config.clientId || !config.userPoolId || !config.domain)
    throw new Error(
      "Chưa cấu hình Cognito. Điền các biến VITE_COGNITO_* theo .env.example rồi build lại.",
    );
  safeHttpsUrl(config.domain);
}
function roleFromClaims(claims: JWTPayload): Role {
  const groups = claims["cognito:groups"];
  const values = Array.isArray(groups) ? groups : [];
  const role = (["SECOPS_ADMIN", "AUDITOR", "REPORTER"] as Role[]).find((r) =>
    values.includes(r),
  );
  if (!role || !roles.includes(role))
    throw new ApiError(
      403,
      "FORBIDDEN",
      "Tài khoản chưa thuộc nhóm PhishGuard hợp lệ.",
    );
  return role;
}
async function verifyTokens(tokens: Tokens, nonce?: string): Promise<Session> {
  keys ??= createRemoteJWKSet(new URL(`${issuer}/.well-known/jwks.json`));
  const { payload: access } = await jwtVerify(tokens.access_token, keys, {
    issuer,
    algorithms: ["RS256"],
  });
  if (
    access.token_use !== "access" ||
    access.client_id !== config.clientId ||
    !access.sub ||
    !access.exp
  )
    throw new Error("Access token Cognito không hợp lệ.");
  let identity = access;
  if (tokens.id_token) {
    const { payload } = await jwtVerify(tokens.id_token, keys, {
      issuer,
      audience: config.clientId,
      algorithms: ["RS256"],
    });
    if (
      payload.token_use !== "id" ||
      payload.sub !== access.sub ||
      (nonce && payload.nonce !== nonce)
    )
      throw new Error("ID token hoặc nonce không hợp lệ.");
    identity = payload;
  } else if (nonce)
    throw new Error("Cognito không trả ID token. Bật scope openid.");
  return {
    accessToken: tokens.access_token,
    refreshToken: tokens.refresh_token || session?.refreshToken,
    expiresAt: access.exp * 1000,
    user: {
      sub: access.sub,
      role: roleFromClaims(access),
      name: String(
        identity.name || identity.email || access.username || "PhishGuard user",
      ),
      email: String(
        identity.email || session?.user.email || access.username || access.sub,
      ),
    },
  };
}
async function exchange(body: URLSearchParams): Promise<Tokens> {
  requireConfig();
  const response = await fetch(`${config.domain}/oauth2/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
    signal: AbortSignal.timeout(20000),
  });
  if (!response.ok)
    throw new ApiError(
      401,
      "UNAUTHORIZED",
      "Không thể trao đổi token Cognito.",
    );
  const data: unknown = await response.json();
  if (
    !data ||
    typeof data !== "object" ||
    !("access_token" in data) ||
    typeof data.access_token !== "string"
  )
    throw new Error("Cognito trả phản hồi không hợp lệ.");
  return data as Tokens;
}
export function initializeAuth(): Promise<User | null> {
  if (config.useMock) return Promise.resolve(mockUsers.SECOPS_ADMIN);
  initialization ??= (async () => {
    const url = new URL(window.location.href);
    const code = url.searchParams.get("code");
    const oauthError = url.searchParams.get("error");
    if (!code && !oauthError) return session?.user || null;
    const state = url.searchParams.get("state");
    const stored = sessionStorage.getItem(pkceKey);
    sessionStorage.removeItem(pkceKey);
    // Xóa authorization code và lỗi OAuth khỏi lịch sử ngay khi nhận callback.
    ["code", "state", "error", "error_description"].forEach((k) =>
      url.searchParams.delete(k),
    );
    history.replaceState(null, "", url.pathname + url.search + url.hash);
    if (!stored)
      throw new Error("Không tìm thấy phiên đăng nhập. Vui lòng bắt đầu lại.");
    const pkce = JSON.parse(stored) as {
      state: string;
      verifier: string;
      nonce: string;
      created: number;
    };
    if (!state || state !== pkce.state || Date.now() - pkce.created > 600000)
      throw new Error("Phiên xác thực không hợp lệ hoặc đã hết hạn.");
    if (oauthError)
      throw new Error("Cognito chưa hoàn tất đăng nhập. Vui lòng thử lại.");
    const tokens = await exchange(
      new URLSearchParams({
        grant_type: "authorization_code",
        client_id: config.clientId,
        code: code!,
        redirect_uri: config.redirectUri,
        code_verifier: pkce.verifier,
      }),
    );
    session = await verifyTokens(tokens, pkce.nonce);
    return session.user;
  })();
  return initialization;
}
export async function signIn() {
  requireConfig();
  const verifier = newId() + newId();
  const digest = new Uint8Array(
    await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier)),
  );
  const challenge = btoa(String.fromCharCode(...digest))
    .replaceAll("+", "-")
    .replaceAll("/", "_")
    .replace(/=+$/, "");
  const state = newId();
  const nonce = newId();
  sessionStorage.setItem(
    pkceKey,
    JSON.stringify({ verifier, state, nonce, created: Date.now() }),
  );
  const url = new URL(`${config.domain}/oauth2/authorize`);
  url.search = new URLSearchParams({
    response_type: "code",
    client_id: config.clientId,
    redirect_uri: config.redirectUri,
    scope: config.scopes,
    state,
    nonce,
    code_challenge: challenge,
    code_challenge_method: "S256",
  }).toString();
  window.location.replace(url.href);
}
export async function accessToken(): Promise<string> {
  if (!session) throw new ApiError(401, "UNAUTHORIZED", "Vui lòng đăng nhập.");
  if (session.expiresAt > Date.now() + 30000) return session.accessToken;
  if (!session.refreshToken) {
    session = null;
    throw new ApiError(401, "UNAUTHORIZED", "Phiên đăng nhập đã hết hạn.");
  }
  refreshing ??= (async () => {
    try {
      const tokens = await exchange(
        new URLSearchParams({
          grant_type: "refresh_token",
          client_id: config.clientId,
          refresh_token: session!.refreshToken!,
        }),
      );
      session = await verifyTokens(tokens);
      return session.accessToken;
    } catch (e) {
      session = null;
      throw e;
    } finally {
      refreshing = undefined;
    }
  })();
  return refreshing;
}
export function signOut() {
  session = null;
  initialization = undefined;
  sessionStorage.removeItem(pkceKey);
  requireConfig();
  const url = new URL(`${config.domain}/logout`);
  url.search = new URLSearchParams({
    client_id: config.clientId,
    logout_uri: config.logoutUri,
  }).toString();
  window.location.assign(url.href);
}
