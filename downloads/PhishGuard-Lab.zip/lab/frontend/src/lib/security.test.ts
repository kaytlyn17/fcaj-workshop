import { describe, expect, it } from "vitest";
import { defang, safeHttpsUrl, validateFile } from "./security";
describe("safe rendering and intake boundaries", () => {
  it("defangs URLs idempotently without changing canonical data", () => {
    const canonical = "https://login.techc0mbank-vn.com/otp";
    const display = defang(canonical);
    expect(display).toBe("hxxps://login[.]techc0mbank-vn[.]com/otp");
    expect(defang(display)).toBe(display);
    expect(canonical).toContain("https://");
  });
  it("validates 0 and 5 MB edges, extensions, and MIME inference", () => {
    expect(() => validateFile({ name: "a.txt", size: 0, type: "" })).toThrow();
    expect(() =>
      validateFile({ name: "a.txt", size: 5242881, type: "" }),
    ).toThrow();
    expect(() =>
      validateFile({ name: "a.exe", size: 10, type: "text/plain" }),
    ).toThrow();
    expect(
      validateFile({ name: "mail.EML", size: 5242880, type: "" }).content_type,
    ).toBe("message/rfc822");
    for (const ext of ["png", "jpg", "jpeg", "txt"])
      expect(
        validateFile({ name: `evidence.${ext}`, size: 1, type: "" }).size,
      ).toBe(1);
  });
  it("rejects script/data/http evidence URLs and untrusted hosts", () => {
    for (const url of [
      "javascript:alert(1)",
      "data:text/html,hello",
      "http://example.com/a",
      "https://user:pass@example.com/a",
    ])
      expect(() => safeHttpsUrl(url)).toThrow();
    expect(() =>
      safeHttpsUrl("https://untrusted.example/a", ["bucket.s3.amazonaws.com"]),
    ).toThrow();
    expect(
      safeHttpsUrl("https://bucket.s3.amazonaws.com/a", [
        "bucket.s3.amazonaws.com",
      ]),
    ).toContain("/a");
  });
});
