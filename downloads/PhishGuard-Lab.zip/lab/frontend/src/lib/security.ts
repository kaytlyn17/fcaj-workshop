import type { Role, PresignRequest } from "../types";

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
  ) {
    super(message);
    this.name = "ApiError";
  }
}
export function explainError(error: unknown): string {
  if (error instanceof ApiError) {
    const messages: Record<string, string> = {
      IDEMPOTENCY_KEY_REUSED:
        "Mã gửi báo cáo đã được sử dụng cho nội dung khác. Giữ nguyên nội dung để thử lại hoặc bắt đầu báo cáo mới.",
      APPROVAL_EXPIRED:
        "Phiên phê duyệt đã hết hạn. Hãy làm mới sự cố để xem trạng thái mới nhất.",
      DECISION_CONFLICT:
        "Sự cố đã được xử lý hoặc đề xuất đã thay đổi. Hãy làm mới để xem quyết định hiện tại.",
      FORBIDDEN: "Vai trò hiện tại không có quyền thực hiện thao tác này.",
      UNAUTHORIZED: "Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.",
      INVALID_RESPONSE:
        "Phản hồi API không đúng định dạng mong đợi. Kiểm tra bộ chuyển đổi API và log backend.",
      STORAGE_FULL:
        "Trình duyệt không thể lưu dữ liệu demo. Hãy kiểm tra dung lượng hoặc quyền lưu trữ.",
    };
    return (
      messages[error.code] ||
      (error.status === 429
        ? "Quá nhiều yêu cầu. Vui lòng đợi một lát rồi thử lại."
        : error.message)
    );
  }
  return error instanceof Error
    ? error.message
    : "Không thể hoàn tất yêu cầu. Vui lòng thử lại.";
}
export function assertRole(role: Role, allowed: Role[]) {
  if (!allowed.includes(role))
    throw new ApiError(403, "FORBIDDEN", "Không đủ quyền.");
}
export function defang(value: string): string {
  return value
    .replace(/https?:\/\//gi, (s) =>
      s.toLowerCase() === "https://" ? "hxxps://" : "hxxp://",
    )
    .replace(/\b([a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,63}\b/gi, (s) =>
      s.replace(/\./g, "[.]"),
    );
}
export const newId = (prefix = "") =>
  prefix + crypto.randomUUID().replaceAll("-", "");
export const idempotencyPattern = /^[A-Za-z0-9_-]{8,64}$/;
const mime: Record<string, string> = {
  eml: "message/rfc822",
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  txt: "text/plain",
};
export function validateFile(
  file: Pick<File, "name" | "size" | "type">,
): PresignRequest {
  const ext = file.name.split(".").pop()?.toLowerCase() || "";
  if (!mime[ext])
    throw new ApiError(
      400,
      "INVALID_FILE",
      "Chỉ chấp nhận .eml, .png, .jpg, .jpeg và .txt.",
    );
  if (file.size <= 0 || file.size > 5242880)
    throw new ApiError(
      400,
      "INVALID_SIZE",
      "Tệp phải lớn hơn 0 byte và không quá 5 MB (5.242.880 byte).",
    );
  // Suy ra MIME theo phần mở rộng, vì trình duyệt thường không có MIME cho .eml.
  // Đây là kiểm tra UX. Ingest vẫn phải kiểm tra magic bytes phía server.
  return { filename: file.name, content_type: mime[ext], size: file.size };
}
export function safeHttpsUrl(
  value: string,
  allowedHosts: string[] = [],
): string {
  const u = new URL(value);
  if (
    u.protocol !== "https:" ||
    u.username ||
    u.password ||
    (allowedHosts.length > 0 && !allowedHosts.includes(u.hostname))
  ) {
    throw new ApiError(
      400,
      "INVALID_URL",
      "Địa chỉ tài nguyên trả về không hợp lệ.",
    );
  }
  return u.href;
}
