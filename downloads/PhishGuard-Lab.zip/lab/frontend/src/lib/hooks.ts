import { useCallback, useEffect, useRef, useState } from "react";
import type { Incident, Page, Status } from "../types";
import { explainError } from "./security";

const processingStatuses = new Set<Status>([
  "UPLOAD_PENDING", "NEW", "TRIAGING", "TRIAGED", "ACTION_REQUESTED",
]);

export function incidentPollingUntil(incident?: Incident): number {
  if (!incident) return 0;
  const lastUpdate = incident.status === "PENDING_APPROVAL"
    ? incident.approval_record?.decided_at
    : processingStatuses.has(incident.status)
      ? incident.updated_at ?? incident.created_at
      : undefined;
  const timestamp = lastUpdate ? Date.parse(lastUpdate) : NaN;
  return Number.isFinite(timestamp) ? timestamp + 5 * 60_000 : 0;
}

export function useVisiblePolling(refresh: () => void, until: number, interval: number) {
  useEffect(() => {
    if (until <= Date.now()) return;
    const timer = window.setInterval(() => {
      if (Date.now() >= until) {
        window.clearInterval(timer);
      } else if (document.visibilityState === "visible") {
        refresh();
      }
    }, interval);
    return () => window.clearInterval(timer);
  }, [refresh, until, interval]);
}

export function usePaged<T>(
  loader: (token?: string) => Promise<Page<T>>,
  enabled = true,
) {
  const [items, setItems] = useState<T[]>([]);
  const [nextToken, setNextToken] = useState<string>();
  const [loading, setLoading] = useState(enabled);
  const [error, setError] = useState("");
  const sequence = useRef(0);
  const mounted = useRef(true);
  const busy = useRef(false);
  const loadedPages = useRef(1);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      sequence.current++;
    };
  }, []);
  const refresh = useCallback(
    async (quiet = false) => {
      if (!enabled || (quiet && busy.current)) return;
      const seq = ++sequence.current;
      busy.current = true;
      if (!quiet) setLoading(true);
      try {
        let page = await loader();
        const combined = [...page.items];
        let pages = 1;
        while (page.next_token && pages < loadedPages.current) {
          page = await loader(page.next_token);
          combined.push(...page.items);
          pages++;
        }
        if (mounted.current && seq === sequence.current) {
          loadedPages.current = pages;
          setItems(combined);
          setNextToken(page.next_token);
          setError("");
        }
      } catch (e) {
        if (mounted.current && seq === sequence.current)
          setError(explainError(e));
      } finally {
        if (mounted.current && seq === sequence.current) {
          setLoading(false);
          busy.current = false;
        }
      }
    },
    [loader, enabled],
  );
  useEffect(() => {
    void refresh();
  }, [refresh]);
  const loadMore = async () => {
    if (!nextToken || loading) return;
    const seq = ++sequence.current;
    busy.current = true;
    setLoading(true);
    try {
      const page = await loader(nextToken);
      if (mounted.current && seq === sequence.current) {
        loadedPages.current++;
        setItems((old) => [...old, ...page.items]);
        setNextToken(page.next_token);
        setError("");
      }
    } catch (e) {
      if (mounted.current && seq === sequence.current)
        setError(explainError(e));
    } finally {
      if (mounted.current && seq === sequence.current) {
        busy.current = false;
        setLoading(false);
      }
    }
  };
  return { items, nextToken, loading, error, refresh, loadMore };
}
