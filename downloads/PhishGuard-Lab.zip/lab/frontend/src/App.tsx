import { useCallback, useEffect, useState } from "react";
import {
  ArrowRight,
  Bell,
  ChevronRight,
  CircleHelp,
  FileClock,
  FileUp,
  FlaskConical,
  LayoutDashboard,
  LockKeyhole,
  LogOut,
  Menu,
  Plus,
  RefreshCw,
  Shield,
  ShieldCheck,
  X,
} from "lucide-react";
import { config } from "./config";
import { api } from "./lib/api";
import { initializeAuth, mockUsers, signIn, signOut } from "./lib/auth";
import { explainError } from "./lib/security";
import { incidentPollingUntil, usePaged, useVisiblePolling } from "./lib/hooks";
import { roles, type Role, type User } from "./types";
import { Badge, ErrorNotice, Spinner, receivedTime } from "./components/ui";
import { Queue } from "./components/Queue";
import { Submit } from "./components/Submit";
import { Blocklist, AuditLogs } from "./components/Registers";
import { IncidentDetail } from "./components/IncidentDetail";

type View = "queue" | "submit" | "blocklist" | "audit";
const viewInfo: Record<
  View,
  { label: string; title: string; Icon: typeof Shield }
> = {
  queue: {
    label: "SecOps Queue",
    title: "SecOps Queue",
    Icon: LayoutDashboard,
  },
  submit: {
    label: "Submit / Demo",
    title: "Submit / Demo",
    Icon: FileUp,
  },
  blocklist: {
    label: "Blocklist",
    title: "Internal Blocklist",
    Icon: ShieldCheck,
  },
  audit: {
    label: "Audit Logs",
    title: "Audit Logs",
    Icon: FileClock,
  },
};
const roleNames: Record<Role, string> = {
  SECOPS_ADMIN: "SecOps Admin",
  REPORTER: "Reporter",
  AUDITOR: "Auditor · Chỉ đọc",
};
function currentView(role: Role): View {
  const hash = window.location.hash.slice(1).split("?")[0];
  return role === "REPORTER"
    ? "submit"
    : Object.hasOwn(viewInfo, hash)
      ? (hash as View)
      : "queue";
}
function Layout({
  user,
  onRole,
  onLogout,
}: {
  user: User;
  onRole: (role: Role) => void;
  onLogout: () => void;
}) {
  const [view, setView] = useState<View>(() => currentView(user.role));
  const [sidebar, setSidebar] = useState(false);
  const [notifications, setNotifications] = useState(false);
  const [help, setHelp] = useState(false);
  const [recentReport, setRecentReport] = useState<{ id: string; until: number }>();
  const [selected, setSelected] = useState<string | undefined>(
    () => new URLSearchParams(location.search).get("incident") || undefined,
  );
  const loadIncidents = useCallback(
    (token?: string) => api.incidents(user, token),
    [user],
  );
  const loadBlocklist = useCallback(
    (token?: string) => api.blocklist(user, token),
    [user],
  );
  const loadAudit = useCallback(
    (token?: string) => api.auditLogs(user, token),
    [user],
  );
  const incidents = usePaged(loadIncidents);
  const blocklist = usePaged(loadBlocklist, user.role !== "REPORTER");
  const audit = usePaged(loadAudit, user.role !== "REPORTER");
  const refreshIncidents = incidents.refresh;
  const pollIncidents = useCallback(() => {
    void refreshIncidents(true);
  }, [refreshIncidents]);
  const reportCreated = useCallback((id: string) => {
    setRecentReport({ id, until: Date.now() + 60_000 });
    pollIncidents();
  }, [pollIncidents]);
  const awaitingReport = recentReport && !incidents.items.some(
    (item) => item.incident_id === recentReport.id,
  );
  const pollingUntil = incidents.items.reduce(
    (until, item) => Math.max(until, incidentPollingUntil(item)),
    awaitingReport ? recentReport.until : 0,
  );
  const showingIncidents = !selected && (view === "queue" || view === "submit");
  useVisiblePolling(pollIncidents, showingIncidents ? pollingUntil : 0, 5000);
  useEffect(() => {
    if (showingIncidents) pollIncidents();
  }, [showingIncidents, view, pollIncidents]);

  const refreshAll = useCallback(() => {
    pollIncidents();
    if (user.role !== "REPORTER") {
      void blocklist.refresh(true);
      void audit.refresh(true);
    }
  }, [pollIncidents, blocklist.refresh, audit.refresh, user.role]);
  useEffect(() => {
    if (!config.useMock) return;
    window.addEventListener("storage", refreshAll);
    return () => window.removeEventListener("storage", refreshAll);
  }, [refreshAll]);
  const syncLocation = useCallback(() => {
    setView(currentView(user.role));
    setSelected(new URLSearchParams(location.search).get("incident") || undefined);
    setSidebar(false);
    setHelp(false);
    setNotifications(false);
  }, [user.role]);
  useEffect(() => {
    window.addEventListener("popstate", syncLocation);
    window.addEventListener("hashchange", syncLocation);
    return () => {
      window.removeEventListener("popstate", syncLocation);
      window.removeEventListener("hashchange", syncLocation);
    };
  }, [syncLocation]);
  const navigate = (next: View) => {
    const url = new URL(location.href);
    url.searchParams.delete("incident");
    url.hash = next;
    if (url.href !== location.href) history.pushState(null, "", url);
    syncLocation();
  };
  const openIncident = useCallback((id: string) => {
    const url = new URL(location.href);
    if (url.searchParams.get("incident") === id) return;
    url.searchParams.set("incident", id);
    history.pushState({ phishguardIncident: true }, "", url);
    syncLocation();
  }, [syncLocation]);
  const closeIncident = useCallback(() => {
    if (history.state?.phishguardIncident) {
      history.back();
      return;
    }
    const url = new URL(location.href);
    url.searchParams.delete("incident");
    history.replaceState(null, "", url);
    syncLocation();
  }, [syncLocation]);
  const pending = incidents.items.filter(
    (i) => i.status === "PENDING_APPROVAL",
  );
  const info = viewInfo[view];
  const resource =
    view === "blocklist" ? blocklist : view === "audit" ? audit : incidents;
  return (
    <>
      <div className="app-shell" aria-hidden={selected ? true : undefined}>
        {sidebar && (
          <div className="sidebar-backdrop" onClick={() => setSidebar(false)} />
        )}
        <aside className={`sidebar ${sidebar ? "sidebar-open" : ""}`}>
          <button
            className="brand"
            onClick={() =>
              navigate(user.role === "REPORTER" ? "submit" : "queue")
            }
            aria-label="Trang chủ PhishGuard"
          >
            <span className="brand-mark">
              <ShieldCheck size={25} />
            </span>
            <span>
              <strong>PhishGuard AI</strong>
              <small>SecOps Console</small>
            </span>
          </button>
          <nav aria-label="Điều hướng chính">
            {(user.role === "REPORTER"
              ? ["submit"]
              : ["queue", "submit", "blocklist", "audit"]
            ).map((key) => {
              const v = key as View;
              const Icon = viewInfo[v].Icon;
              return (
                <button
                  key={v}
                  className={view === v ? "nav-item active" : "nav-item"}
                  aria-current={view === v ? "page" : undefined}
                  onClick={() => navigate(v)}
                >
                  <Icon size={18} />
                  <span>
                    {user.role === "REPORTER"
                      ? "Báo cáo & Tra cứu"
                      : viewInfo[v].label}
                  </span>
                  {v === "queue" && pending.length > 0 && (
                    <b>{pending.length}</b>
                  )}
                </button>
              );
            })}
          </nav>
          <div className="sidebar-bottom">
            <div className="system-specs mono">
              <p>Region: {config.region}</p>
              <p>Policy Engine: Deterministic</p>
              <p>RAG Store: S3 Vectors + Nova Lite</p>
            </div>
            <button
              className={`sidebar-help ${help ? "active" : ""}`}
              onClick={() => setHelp(!help)}
            >
              <CircleHelp size={17} />
              Hướng dẫn sử dụng
              <ChevronRight size={14} />
            </button>
            <div className="sidebar-user">
              <span className="avatar">
                {user.name
                  .split(" ")
                  .map((s) => s[0])
                  .slice(0, 2)
                  .join("")}
              </span>
              <div>
                <strong>{user.name}</strong>
                <small>{roleNames[user.role]}</small>
              </div>
              {!config.useMock && (
                <button
                  className="icon-button"
                  title="Đăng xuất"
                  aria-label="Đăng xuất"
                  onClick={onLogout}
                >
                  <LogOut size={16} />
                </button>
              )}
            </div>
          </div>
        </aside>
        <div className="workspace-main">
          <header className="topbar">
            <div className="breadcrumbs">
              <button
                className="icon-button mobile-menu"
                aria-label="Mở menu"
                onClick={() => setSidebar(!sidebar)}
              >
                <Menu size={20} />
              </button>
              <span className="breadcrumb-workspace">
                <Shield size={14} />
                Workspace
              </span>
              <ChevronRight size={13} />
              <strong>
                {user.role === "REPORTER" ? "Báo cáo cá nhân" : info.label}
              </strong>
            </div>
            <div className="topbar-actions">
              <Badge tone={config.useMock ? "amber" : "green"} dot>
                {config.useMock ? "MOCK MODE" : "LIVE AWS API"}
              </Badge>
              {config.useMock && (
                <label className="role-switcher">
                  <FlaskConical size={14} />
                  <select
                    aria-label="Chuyển vai trò demo"
                    value={user.role}
                    onChange={(e) => {
                      closeIncident();
                      onRole(e.target.value as Role);
                    }}
                  >
                    {roles.map((r) => (
                      <option key={r} value={r}>
                        {r}
                      </option>
                    ))}
                  </select>
                </label>
              )}
              <div className="notification-wrap">
                <button
                  className="icon-button notification-button"
                  aria-label="Thông báo hàng đợi"
                  aria-expanded={notifications}
                  onClick={() => setNotifications(!notifications)}
                >
                  <Bell size={18} />
                  {pending.length > 0 && <i />}
                </button>
                {notifications && (
                  <div className="notification-menu">
                    <strong>{pending.length} sự cố chờ phê duyệt</strong>
                    <p>Từ danh sách sự cố đã tải</p>
                    {pending.slice(0, 4).map((i) => (
                      <button
                        key={i.incident_id}
                        onClick={() => openIncident(i.incident_id)}
                      >
                        <span className="notification-dot" />
                        <div>
                          <span className="mono">{i.incident_id}</span>
                          <small>{receivedTime(i.created_at)}</small>
                        </div>
                        <ChevronRight size={14} />
                      </button>
                    ))}
                    {!pending.length && <p>Chưa có mục nào cần phê duyệt.</p>}
                  </div>
                )}
              </div>
            </div>
          </header>
          <main className="page-content">
            <div className="page-heading">
              <h1>
                {user.role === "REPORTER"
                  ? "Gửi báo cáo & Tra cứu cá nhân"
                  : info.title}
              </h1>
              <div className="page-heading-actions">
                <button
                  className="btn btn-secondary"
                  disabled={resource.loading}
                  onClick={() => void resource.refresh()}
                >
                  <RefreshCw
                    size={14}
                    className={resource.loading ? "spin" : ""}
                  />
                  Làm mới
                </button>
                {view !== "submit" && user.role !== "AUDITOR" && (
                  <button
                    className="btn btn-primary"
                    onClick={() => navigate("submit")}
                  >
                    <Plus size={16} />
                    Gửi báo cáo
                  </button>
                )}
                {user.role === "AUDITOR" && (
                  <Badge tone="blue">
                    <LockKeyhole size={12} />
                    CHỈ ĐỌC
                  </Badge>
                )}
              </div>
            </div>
            {help && (
              <section className="help-panel">
                <div className="flex justify-between">
                  <h2>
                    <CircleHelp size={18} />
                    Hướng dẫn nhanh
                  </h2>
                  <button
                    className="icon-button"
                    aria-label="Đóng hướng dẫn"
                    onClick={() => setHelp(false)}
                  >
                    <X size={18} />
                  </button>
                </div>
                <p>
                  Gửi báo cáo hoặc chạy fixture từ Submit / Demo. Mở mã sự cố để
                  kiểm tra bằng chứng, luật chấm điểm và đề xuất. SECOPS_ADMIN
                  xử lý quyết định. Auditor có quyền đọc. Reporter xem báo cáo
                  của mình.
                </p>
                <p>
                  {config.useMock
                    ? "Chế độ mock lưu dữ liệu trong trình duyệt."
                    : "Quyền truy cập và dữ liệu do API AWS xác thực và kiểm soát."}
                </p>
              </section>
            )}
            {resource.error && (
              <ErrorNotice
                message={resource.error}
                onRetry={() => void resource.refresh()}
              />
            )}
            {resource.loading && !resource.items.length && view !== "submit" ? (
              <Spinner />
            ) : view === "queue" ? (
              <Queue incidents={incidents.items} onOpen={openIncident} />
            ) : view === "submit" ? (
              <Submit
                user={user}
                incidents={incidents.items}
                onCreated={reportCreated}
                onOpen={openIncident}
              />
            ) : view === "blocklist" ? (
              <Blocklist items={blocklist.items} onOpen={openIncident} />
            ) : (
              <AuditLogs items={audit.items} onOpen={openIncident} />
            )}
            {resource.nextToken && (
              <div className="load-more">
                <button
                  className="btn btn-secondary"
                  disabled={resource.loading}
                  onClick={() => void resource.loadMore()}
                >
                  Tải thêm dữ liệu
                  <ArrowRight size={15} />
                </button>
                <span className="muted text-xs">
                  Số liệu và bộ lọc áp dụng cho dữ liệu đã tải.
                </span>
              </div>
            )}
          </main>
        </div>
      </div>
      {selected && (
        <IncidentDetail
          key={`${user.sub}:${selected}`}
          id={selected}
          user={user}
          audit={audit.items}
          onClose={closeIncident}
          onChanged={refreshAll}
        />
      )}
    </>
  );
}
export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    let active = true;
    initializeAuth()
      .then((u) => {
        if (active) {
          setUser(u);
          setReady(true);
        }
      })
      .catch((e) => {
        if (active) {
          setError(explainError(e));
          setReady(true);
        }
      });
    return () => {
      active = false;
    };
  }, []);
  const login = async () => {
    setBusy(true);
    setError("");
    try {
      await signIn();
    } catch (e) {
      setError(explainError(e));
      setBusy(false);
    }
  };
  if (!ready)
    return (
      <div className="auth-screen">
        <Spinner label="Đang khởi tạo PhishGuard…" />
      </div>
    );
  if (!user)
    return (
      <div className="auth-screen">
        <div className="login-card">
          <span className="login-mark">
            <ShieldCheck size={36} />
          </span>
          <h1>PhishGuard AI</h1>
          <p>SecOps Console</p>
          {error && <ErrorNotice message={error} />}
          <button
            className="btn btn-primary"
            disabled={busy}
            onClick={() => void login()}
          >
            {busy ? <span className="spinner" /> : <LockKeyhole size={16} />}
            Đăng nhập bằng Cognito
            <ArrowRight size={16} />
          </button>
          <small>REPORTER · SECOPS_ADMIN · AUDITOR</small>
        </div>
      </div>
    );
  return (
    <Layout
      key={`${user.sub}:${user.role}`}
      user={user}
      onRole={(r) => {
        if (config.useMock) setUser(mockUsers[r]);
      }}
      onLogout={() => {
        try {
          signOut();
          setUser(null);
        } catch (e) {
          setError(explainError(e));
          setUser(null);
        }
      }}
    />
  );
}
