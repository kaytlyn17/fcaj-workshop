import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react";
import { webcrypto } from "node:crypto";
import { SafeText, receivedTime } from "./ui";
import { IncidentTable } from "./Queue";
import { ApprovalForm, IncidentDetail } from "./IncidentDetail";
import { Submit } from "./Submit";
import { api } from "../lib/api";
import { mockUsers } from "../lib/auth";
import { sampleIncident } from "../mock/fixtures";
import { ApiError } from "../lib/security";
import App from "../App";
const admin = mockUsers.SECOPS_ADMIN;
beforeEach(() => {
  localStorage.clear();
  vi.stubGlobal("crypto", webcrypto);
  history.replaceState(null, "", "/");
});
afterEach(() => {
  cleanup();
  vi.useRealTimers();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});
describe("plain text and role-based UI", () => {
  it("filters unknown assessments and displays rule points separately from workflow", () => {
    const unknown = sampleIncident("DEMO_2", admin, "INC-UNKNOWN");
    unknown.policy_evaluation = { assessment: "UNKNOWN", assessment_reason: "UNVERIFIED_URL",
      severity: "LOW", risk_score: 0, triggered_rules: [] };
    unknown.status = "NO_ACTION";
    const review = sampleIncident("DEMO_1", admin, "INC-REVIEW");
    review.status = "NEEDS_REVIEW";
    const { container } = render(<IncidentTable incidents={[unknown, review]} onOpen={() => {}} />);
    fireEvent.change(screen.getByLabelText("Lọc kết luận"), { target: { value: "UNKNOWN" } });
    expect(screen.queryByText("INC-REVIEW")).toBeNull();
    expect(screen.getByText("INC-UNKNOWN")).toBeTruthy();
    expect(container.querySelector(".risk-unknown")?.textContent).toContain("Luật 0/100Chưa xác định");
    expect(container.querySelector(".risk-low")).toBeNull();
    expect(screen.getByText("Không có đề xuất")).toBeTruthy();
  });
  it("explains an unverified URL on the incident detail page", async () => {
    const item = sampleIncident("DEMO_2", admin, "INC-URL");
    item.status = "NO_ACTION";
    item.proposed_actions = [];
    item.policy_evaluation = { risk_score: 0, severity: "LOW", assessment: "UNKNOWN",
      assessment_reason: "UNVERIFIED_URL", triggered_rules: [] };
    vi.spyOn(api, "incident").mockResolvedValue(item);
    render(<IncidentDetail id={item.incident_id} user={admin} audit={[]} onClose={() => {}} onChanged={() => {}} />);
    expect(await screen.findByText(/Có URL chưa xác minh/)).toBeTruthy();
  });
  it("renders hostile HTML and IOC strings as inert text", () => {
    const hostile =
      "<img src=x onerror=alert(1)><script>alert(2)</script> https://evil.example/otp";
    const { container } = render(<SafeText value={hostile} />);
    expect(container.textContent).toContain("<img src=x");
    expect(container.textContent).toContain("hxxps://evil[.]example/otp");
    expect(container.querySelector("img,script,iframe,a")).toBeNull();
  });
  it("hides raw evidence and decisions from reporter, disables them for auditor", async () => {
    const item = sampleIncident("DEMO_2", mockUsers.REPORTER, "INC-RBAC-TEST");
    vi.spyOn(api, "incident").mockResolvedValue(item);
    const view = render(
      <IncidentDetail
        id={item.incident_id}
        user={mockUsers.REPORTER}
        audit={[]}
        onClose={() => {}}
        onChanged={() => {}}
      />,
    );
    await screen.findByText("Điểm rủi ro tất định");
    expect(
      screen.queryByRole("button", { name: /Xem bằng chứng gốc/ }),
    ).toBeNull();
    expect(screen.queryByRole("button", { name: /APPROVE/ })).toBeNull();
    view.unmount();
    render(
      <IncidentDetail
        id={item.incident_id}
        user={mockUsers.AUDITOR}
        audit={[]}
        onClose={() => {}}
        onChanged={() => {}}
      />,
    );
    const raw = await screen.findByRole("button", {
      name: /Xem bằng chứng gốc/,
    });
    expect((raw as HTMLButtonElement).disabled).toBe(true);
    expect(
      (
        screen.getByRole("button", {
          name: "Approve / Reject",
        }) as HTMLButtonElement
      ).disabled,
    ).toBe(true);
    expect(screen.queryByLabelText(/Ghi chú quyết định/)).toBeNull();
  });
  it("renders malicious summary, header, excerpt and decision note safely", async () => {
    const item = sampleIncident("DEMO_3", admin, "INC-XSS-TEST");
    const payload = '<svg onload="alert(1)"> https://evil.example';
    item.agent_synthesis!.summary_vi = payload;
    item.deterministic_findings!.sanitized_excerpt = payload;
    item.email_auth!.claimed_headers.from_masked = payload;
    item.approval_record = {
      decision_id: "d1",
      action_id: "ACT-001",
      proposal_version: 1,
      decision: "REJECT",
      note: payload,
      actor_id: "admin",
      decided_at: new Date().toISOString(),
    };
    item.status = "REJECTED";
    vi.spyOn(api, "incident").mockResolvedValue(item);
    render(
      <IncidentDetail
        id={item.incident_id}
        user={admin}
        audit={[]}
        onClose={() => {}}
        onChanged={() => {}}
      />,
    );
    await screen.findByText("Tổng hợp từ AI");
    expect(document.querySelector("svg[onload],img,iframe,script")).toBeNull();
    expect(document.body.textContent).toContain(
      '<svg onload="alert(1)"> hxxps://evil[.]example',
    );
    fireEvent.click(screen.getByRole("tab", { name: "Bằng chứng đã che PII" }));
    expect(
      document.querySelector('svg[onload],iframe,a[href*="evil"]'),
    ).toBeNull();
    expect(document.body.textContent).toContain(
      payload.replace("https://evil.example", "hxxps://evil[.]example"),
    );
  });
  it("removes admin navigation and incident data immediately when switching to reporter", async () => {
    render(<App />);
    await screen.findByRole("button", { name: "Blocklist" });
    fireEvent.change(screen.getByLabelText("Chuyển vai trò demo"), {
      target: { value: "REPORTER" },
    });
    await screen.findByRole("heading", {
      name: "Gửi báo cáo & Tra cứu cá nhân",
    });
    expect(screen.queryByRole("button", { name: "Blocklist" })).toBeNull();
    expect(screen.queryByRole("button", { name: "Audit Logs" })).toBeNull();
    await screen.findByText("Báo cáo của bạn");
    await waitFor(() =>
      expect(
        screen.queryByRole("button", { name: "Mở INC-8F3A19C04B2E" }),
      ).toBeNull(),
    );
  });
  it("exposes only an audited raw-resource link and removes it after 60 seconds", async () => {
    const item = sampleIncident("DEMO_2", admin, "INC-RAW-TTL");
    const revoke = vi.fn();
    vi.stubGlobal(
      "URL",
      class extends URL {
        static revokeObjectURL = revoke;
      },
    );
    vi.spyOn(api, "incident").mockResolvedValue(item);
    vi.spyOn(api, "rawEvidence").mockResolvedValue({
      presigned_url: "blob:mock-raw-proof",
      expires_in_seconds: 60,
      audit_event_recorded: true,
    });
    const changed = vi.fn();
    render(
      <IncidentDetail
        id={item.incident_id}
        user={admin}
        audit={[]}
        onClose={() => {}}
        onChanged={changed}
      />,
    );
    fireEvent.click(
      await screen.findByRole("button", { name: /Xem bằng chứng gốc/ }),
    );
    const link = await screen.findByRole("link", { name: /Mở \/ tải tệp gốc/ });
    expect(link.getAttribute("rel")).toBe("noopener noreferrer");
    expect(link.getAttribute("href")).toBe("blob:mock-raw-proof");
    expect(changed).toHaveBeenCalledTimes(1);
    // The UI interval was installed with real timers; advance only the clock
    // and let that interval observe expiry instead of replacing its scheduler.
    vi.useFakeTimers({ toFake: ["Date"] });
    vi.setSystemTime(Date.now() + 61000);
    await waitFor(
      () => {
        expect(
          screen.queryByRole("link", { name: /Mở \/ tải tệp gốc/ }),
        ).toBeNull();
        expect(revoke).toHaveBeenCalledWith("blob:mock-raw-proof");
      },
      { timeout: 2200 },
    );
  });
});
it("regenerates the report key before submission and preserves it on retry", async () => {
  const report = vi
    .spyOn(api, "report")
    .mockRejectedValueOnce(new Error("Temporary error"))
    .mockResolvedValueOnce({
      incident_id: "INC-TEST-RETRY",
      status: "NEW",
      source_intake_key: "test",
    });
  render(
    <Submit
      user={admin}
      incidents={[]}
      onCreated={() => {}}
      onOpen={() => {}}
    />,
  );

  const key = screen.getByLabelText<HTMLInputElement>("idempotency_key");
  const initialKey = key.value;
  fireEvent.click(screen.getByRole("button", { name: "Tạo lại" }));
  const regeneratedKey = key.value;
  expect(regeneratedKey).not.toBe(initialKey);
  expect(regeneratedKey).toMatch(/^[A-Za-z0-9_-]{8,64}$/);

  fireEvent.change(screen.getByLabelText(/Nội dung cần kiểm tra/), {
    target: { value: "Synthetic report for retry verification" },
  });
  fireEvent.click(screen.getByRole("button", { name: "Gửi phân tích" }));
  await screen.findByRole("alert");
  expect(
    screen
      .getByRole<HTMLButtonElement>("button", { name: "Tạo lại" })
      .matches(":disabled"),
  ).toBe(true);
  fireEvent.click(screen.getByRole("button", { name: "Gửi lại yêu cầu" }));
  await screen.findByText("INC-TEST-RETRY");
  expect(report).toHaveBeenCalledTimes(2);
  expect(report.mock.calls[0][1].idempotency_key).toBe(regeneratedKey);
  expect(report.mock.calls[1][1]).toEqual(report.mock.calls[0][1]);
});

describe("approval retry integrity", () => {
  it("freezes the entire decision payload after a lost response and prevents double submit", async () => {
    const item = sampleIncident("DEMO_2", admin, "INC-RETRY-TEST");
    let rejectFirst: (e: Error) => void = () => {};
    const first = new Promise<never>((_resolve, reject) => {
      rejectFirst = reject;
    });
    const send = vi
      .spyOn(api, "decision")
      .mockReturnValueOnce(first)
      .mockResolvedValueOnce(undefined);
    const onDone = vi.fn(async () => {});
    render(
      <ApprovalForm
        user={admin}
        incident={item}
        action={item.proposed_actions[0]}
        onDone={onDone}
      />,
    );
    fireEvent.change(screen.getByLabelText(/Ghi chú quyết định/), {
      target: { value: "Căn cứ xác minh ban đầu" },
    });
    const approve = screen.getByRole("button", { name: /APPROVE/ });
    fireEvent.click(approve);
    fireEvent.click(approve);
    expect(send).toHaveBeenCalledTimes(1);
    rejectFirst(new ApiError(0, "NETWORK_ERROR", "Mất kết nối sau khi gửi."));
    const retry = await screen.findByRole("button", {
      name: "Gửi lại phê duyệt",
    });
    expect(
      (screen.getByLabelText(/Ghi chú quyết định/) as HTMLTextAreaElement)
        .disabled,
    ).toBe(true);
    fireEvent.click(retry);
    await waitFor(() => expect(onDone).toHaveBeenCalledTimes(1));
    expect(send).toHaveBeenCalledTimes(2);
    expect(send.mock.calls[0][2]).toEqual(send.mock.calls[1][2]);
    expect(send.mock.calls[0][2].note).toBe("Căn cứ xác minh ban đầu");
    expect(send.mock.calls[0][2].decision_id).toMatch(/^dec_/);
  });
});

describe("incident receipt time in Vietnam", () => {
  it("converts the instant including the next calendar day", () => {
    const value = receivedTime("2026-11-18T17:05:06.000Z");
    expect(value).toContain("00:05:06");
    expect(value).toContain("19/11/2026");
    expect(value).toContain("GMT+7");
    expect(receivedTime("2026-11-19T00:05:06+07:00")).toBe(value);
    expect(receivedTime("2026-11-18T11:06:20Z")).toContain("18:06:20");
    expect(receivedTime("invalid")).toBe("—");
  });
});
