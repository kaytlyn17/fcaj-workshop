import type { ReactNode } from "react";
import {
  AlertCircle,
  ChevronRight,
  FileText,
  Mail,
  MessageSquare,
  Search,
  ShieldAlert,
  X,
} from "lucide-react";
import type { Incident, Status } from "../types";
import { defang } from "../lib/security";

export const statusNames: Record<Status, string> = {
  UPLOAD_PENDING: "Chờ tải tệp",
  NEW: "Mới tiếp nhận",
  TRIAGING: "Đang phân tích",
  TRIAGED: "Đã phân tích",
  NO_ACTION: "Không có đề xuất",
  NEEDS_MORE_INFO: "Cần bổ sung",
  NEEDS_REVIEW: "Cần kiểm tra",
  PENDING_APPROVAL: "Chờ phê duyệt",
  REJECTED: "Đã từ chối",
  ESCALATED_TIMEOUT: "Quá hạn duyệt",
  ACTION_REQUESTED: "Đang xử lý",
  SIMULATED: "Đã mô phỏng",
  INTERNAL_LIST_UPDATED: "Đã cập nhật",
  CONTAINMENT_FAILED: "Xử lý thất bại",
  FAILED: "Phân tích lỗi",
};
export function SafeText({
  value,
  className = "",
}: {
  value: string;
  className?: string;
}) {
  return <span className={className}>{defang(value)}</span>;
}
export function Badge({
  children,
  tone = "neutral",
  dot = false,
}: {
  children: ReactNode;
  tone?: string;
  dot?: boolean;
}) {
  return (
    <span className={`badge badge-${tone}`}>
      {dot && <i />}
      {children}
    </span>
  );
}
export function StatusBadge({ status }: { status: Status }) {
  const tone =
    status === "PENDING_APPROVAL"
      ? "amber"
      : status === "SIMULATED" || status === "INTERNAL_LIST_UPDATED"
        ? "green"
        : status === "NEEDS_REVIEW"
          ? "blue"
          : status === "NEEDS_MORE_INFO"
            ? "violet"
            : status === "FAILED" ||
                status === "CONTAINMENT_FAILED" ||
                status === "ESCALATED_TIMEOUT"
              ? "red"
              : "neutral";
  return (
    <span title={status}>
      <Badge tone={tone} dot>
        {statusNames[status]}
      </Badge>
    </span>
  );
}
export function displayedRisk(incident: Incident) {
  const p = incident.policy_evaluation;
  if (!p) return incident.status === "NO_ACTION" ? "UNKNOWN" : undefined;
  return p.assessment === "SUSPICIOUS" ? p.severity : "UNKNOWN";
}

export function Severity({ incident }: { incident: Incident }) {
  const p = incident.policy_evaluation;
  const risk = displayedRisk(incident);
  return risk ? (
    <span className={`risk risk-${risk.toLowerCase()}`}>
      {p && <strong className="mono">Luật {p.risk_score}/100</strong>}
      <span>{risk === "UNKNOWN" ? "Chưa xác định" : risk}</span>
    </span>
  ) : (
    <span className="muted text-xs">Chưa chấm điểm</span>
  );
}
export function IncidentIcon({ incident }: { incident: Incident }) {
  const Icon =
    incident.evidence_type === "EML"
      ? Mail
      : incident.evidence_type === "IMAGE"
        ? MessageSquare
        : FileText;
  return (
    <span
      className={`evidence-icon evidence-${incident.evidence_type.toLowerCase()}`}
    >
      <Icon size={18} />
    </span>
  );
}
export function incidentLabel(i: Incident) {
  if (i.security_flags.includes("PROMPT_INJECTION_DETECTED"))
    return "Email chứa bẫy Prompt Injection";
  if (i.status === "NEEDS_MORE_INFO") return "Bằng chứng cần bổ sung thông tin";
  if (i.policy_evaluation?.triggered_rules.some((r) => r.rule_id === "LINKED_BENEFIT_CLAIM"))
    return "Lời mời nhận tiền qua liên kết";
  if (
    i.policy_evaluation?.triggered_rules.some(
      (r) => r.rule_id === "EXEC_IMPERSONATION",
    )
  )
    return "Tin nhắn giả danh Giám đốc";
  if (
    i.policy_evaluation?.triggered_rules.some(
      (r) => r.rule_id === "BRAND_LOOKALIKE_DOMAIN",
    )
  )
    return "Email giả mạo ngân hàng";
  if (i.status === "NO_ACTION") return "Nội dung chưa có đề xuất hành động";
  return `Báo cáo ${i.evidence_type === "EML" ? "email" : i.evidence_type === "IMAGE" ? "hình ảnh" : "văn bản"} nghi ngờ`;
}
const vietnamReceiptTime = new Intl.DateTimeFormat("vi-VN", {
  timeZone: "Asia/Ho_Chi_Minh",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
  hourCycle: "h23",
});

export function receivedTime(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : `${vietnamReceiptTime.format(date)} GMT+7`;
}

export function dateTime(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? "—"
    : `${date.toISOString().slice(0, 19).replace("T", " ")} UTC`;
}
export function Notice({
  children,
  tone = "amber",
}: {
  children: ReactNode;
  tone?: string;
}) {
  return (
    <div className={`notice notice-${tone}`}>
      <ShieldAlert size={18} />
      <div>{children}</div>
    </div>
  );
}
export function ErrorNotice({
  message,
  onRetry,
}: {
  message: string;
  onRetry?: () => void;
}) {
  return (
    <div className="error-notice" role="alert">
      <AlertCircle size={18} />
      <span>{message}</span>
      {onRetry && (
        <button className="text-button" onClick={onRetry}>
          Thử lại
        </button>
      )}
    </div>
  );
}
export function EmptyState({
  title = "Không có kết quả",
  text = "Thử thay đổi từ khóa hoặc bộ lọc.",
}: {
  title?: string;
  text?: string;
}) {
  return (
    <div className="empty-state">
      <Search size={27} />
      <h3>{title}</h3>
      <p>{text}</p>
    </div>
  );
}
export function Spinner({ label = "Đang tải dữ liệu…" }: { label?: string }) {
  return (
    <div className="loading-state" role="status">
      <span className="spinner" />
      {label}
    </div>
  );
}
export function Section({
  title,
  subtitle,
  children,
  aside,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  aside?: ReactNode;
}) {
  return (
    <section className="panel">
      <div className="panel-heading">
        <div>
          <h2>{title}</h2>
          {subtitle && <p>{subtitle}</p>}
        </div>
        {aside}
      </div>
      {children}
    </section>
  );
}
export function IconButton({
  label,
  children,
  onClick,
  disabled = false,
}: {
  label: string;
  children: ReactNode;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      className="icon-button"
      disabled={disabled}
      onClick={onClick}
    >
      {children}
    </button>
  );
}
export const RowArrow = () => <ChevronRight size={17} className="row-arrow" />;
export const CloseIcon = () => <X size={20} />;
