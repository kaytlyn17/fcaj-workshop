import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import {
  BookOpen,
  Check,
  ChevronRight,
  Clock3,
  Download,
  LockKeyhole,
  RefreshCw,
  X,
} from "lucide-react";
import { api } from "../lib/api";
import { config } from "../config";
import { incidentPollingUntil, useVisiblePolling } from "../lib/hooks";
import { explainError, newId } from "../lib/security";
import type {
  AuditEntry,
  DecisionRequest,
  Incident,
  ProposedAction,
  User,
} from "../types";
import {
  Badge,
  ErrorNotice,
  IncidentIcon,
  Notice,
  SafeText,
  Section,
  Severity,
  Spinner,
  StatusBadge,
  displayedRisk,
  dateTime,
  receivedTime,
  incidentLabel,
} from "./ui";

const drafts = new Map<string, { id: string; body?: DecisionRequest }>();
export function ApprovalForm({
  user,
  incident,
  action,
  onDone,
}: {
  user: User;
  incident: Incident;
  action: ProposedAction;
  onDone: () => Promise<void>;
}) {
  const key = `${user.sub}:${incident.incident_id}:${action.action_id}:${action.proposal_version}`;
  if (!drafts.has(key)) drafts.set(key, { id: newId("dec_") });
  const draft = drafts.get(key)!;
  const [note, setNote] = useState(draft.body?.note || "");
  const [busy, setBusy] = useState(false);
  const inFlight = useRef(false);
  const [error, setError] = useState("");
  const [frozen, setFrozen] = useState(!!draft.body);
  const submit = async (decision: "APPROVE" | "REJECT") => {
    if (inFlight.current) return;
    inFlight.current = true;
    setBusy(true);
    setError("");
    draft.body ??= {
      decision_id: draft.id,
      action_id: action.action_id,
      proposal_version: action.proposal_version,
      decision,
      note,
    };
    setFrozen(true);
    try {
      await api.decision(user, incident.incident_id, draft.body);
      drafts.delete(key);
      await onDone();
    } catch (e) {
      setError(explainError(e));
    } finally {
      setBusy(false);
      inFlight.current = false;
    }
  };
  return (
    <div className="approval-form">
      <dl className="technical-fields mono">
        <div>
          <dt>decision_id</dt>
          <dd>{draft.id}</dd>
        </div>
      </dl>
      <label className="field-label" htmlFor="decision-note">
        Ghi chú quyết định
        <span className="muted font-normal"> · tối đa 2.000 ký tự</span>
      </label>
      <textarea
        id="decision-note"
        rows={3}
        value={note}
        onChange={(e) => setNote(e.target.value)}
        disabled={busy || frozen}
        maxLength={2000}
        placeholder="Căn cứ quyết định"
      />
      {error && <ErrorNotice message={error} />}
      <div className="decision-buttons">
        {frozen && error ? (
          <button
            className="btn btn-primary"
            disabled={busy}
            onClick={() => void submit(draft.body!.decision)}
          >
            {busy ? <span className="spinner" /> : <RefreshCw size={15} />}Gửi
            lại {draft.body?.decision === "APPROVE" ? "phê duyệt" : "từ chối"}
          </button>
        ) : (
          <>
            <button
              className="btn btn-reject"
              disabled={busy || frozen}
              onClick={() => void submit("REJECT")}
            >
              <X size={15} />
              REJECT
            </button>
            <button
              className="btn btn-primary"
              disabled={busy || frozen}
              onClick={() => void submit("APPROVE")}
            >
              {busy ? <span className="spinner" /> : <Check size={16} />}
              APPROVE
            </button>
          </>
        )}
      </div>
      <p className="approval-footnote">
        <LockKeyhole size={12} />
        Audit ghi nhận quyết định. Gửi lại dùng cùng decision_id.
      </p>
    </div>
  );
}

export function IncidentDetail({
  id,
  user,
  audit,
  onClose,
  onChanged,
}: {
  id: string;
  user: User;
  audit: AuditEntry[];
  onClose: () => void;
  onChanged: () => void;
}) {
  const [item, setItem] = useState<Incident>();
  const [error, setError] = useState("");
  const [tab, setTab] = useState("overview");
  const [loading, setLoading] = useState(true);
  const [rawBusy, setRawBusy] = useState(false);
  const [rawError, setRawError] = useState("");
  const [rawGrant, setRawGrant] = useState<{ url: string; deadline: number }>();
  const [rawExpires, setRawExpires] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const [activeAction, setActiveAction] = useState("");
  const dialog = useRef<HTMLDivElement>(null);
  const current = useRef(true);
  const requestCount = useRef(0);
  const refreshing = useRef(false);
  const refresh = useCallback(async (quiet = false) => {
    if (quiet && refreshing.current) return;
    const seq = ++requestCount.current;
    refreshing.current = true;
    try {
      const data = await api.incident(user, id);
      if (current.current && seq === requestCount.current) {
        setItem(data);
        setError("");
      }
    } catch (e) {
      if (current.current && seq === requestCount.current)
        setError(explainError(e));
    } finally {
      if (current.current && seq === requestCount.current) {
        refreshing.current = false;
        setLoading(false);
      }
    }
  }, [id, user]);
  useEffect(() => {
    current.current = true;
    void refresh();
    return () => {
      current.current = false;
      requestCount.current++;
      refreshing.current = false;
    };
  }, [refresh]);
  const poll = useCallback(() => {
    void refresh(true);
  }, [refresh]);
  useVisiblePolling(poll, incidentPollingUntil(item), 2500);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    dialog.current?.querySelector<HTMLButtonElement>("[data-close]")?.focus();
    const keydown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
        return;
      }
      if (e.key === "Tab") {
        const nodes = dialog.current?.querySelectorAll<HTMLElement>(
          "button:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled]), summary, a[href]",
        );
        if (!nodes?.length) return;
        const first = nodes[0],
          last = nodes[nodes.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", keydown);
    return () => {
      document.body.style.overflow = overflow;
      document.removeEventListener("keydown", keydown);
      previous?.focus();
    };
  }, [onClose]);
  useEffect(() => {
    if (!rawExpires) return;
    const tick = () =>
      setSeconds(Math.max(0, Math.ceil((rawExpires - Date.now()) / 1000)));
    tick();
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, [rawExpires]);
  const done = async () => {
    await refresh();
    onChanged();
  };
  useEffect(() => {
    if (!rawGrant || !config.useMock) return;
    return () => URL.revokeObjectURL(rawGrant.url);
  }, [rawGrant]);
  useEffect(() => {
    if (rawGrant && seconds === 0 && Date.now() >= rawGrant.deadline)
      setRawGrant(undefined);
  }, [seconds, rawGrant]);
  const download = async () => {
    if (rawBusy || !item) return;
    setRawBusy(true);
    setRawError("");
    try {
      const grant = await api.rawEvidence(user, id);
      onChanged();
      if (!grant.audit_event_recorded)
        throw new Error("Backend chưa xác nhận ghi audit.");
      if (!current.current) {
        if (config.useMock) URL.revokeObjectURL(grant.presigned_url);
        return;
      }
      const deadline =
        Date.now() + Math.min(grant.expires_in_seconds, 60) * 1000;
      setRawExpires(deadline);
      setRawGrant({ url: grant.presigned_url, deadline });
      // Liên kết riêng biệt, noopener/noreferrer, không nhúng bằng chứng vào DOM.
      // Không fetch GET qua JavaScript nên không yêu cầu thêm CORS trên evidence bucket.
    } catch (e) {
      if (current.current) setRawError(explainError(e));
    } finally {
      if (current.current) setRawBusy(false);
    }
  };
  const action =
    item?.proposed_actions.find((a) => a.action_id === activeAction) ||
    item?.proposed_actions[0];
  const entries = audit.filter((a) => a.incident_id === id);
  const rawEvidence = item && (
    <>
      {user.role !== "REPORTER" && (
        <Section
          title="Bằng chứng gốc"
          aside={<LockKeyhole size={15} className="muted" />}
        >
          <div className="raw-evidence panel-body">
            <p className="muted">Ghi audit khi cấp URL.</p>
            <button
              className="btn btn-secondary"
              disabled={user.role !== "SECOPS_ADMIN" || rawBusy}
              title={
                user.role === "AUDITOR"
                  ? "Auditor không có quyền xem bằng chứng gốc"
                  : "Xin quyền tải bằng chứng gốc, có ghi audit"
              }
              onClick={() => void download()}
            >
              {rawBusy ? <span className="spinner" /> : <Download size={15} />}
              {rawGrant
                ? "Cấp URL mới"
                : "Xem bằng chứng gốc (60s Presigned GET)"}
            </button>
            {rawGrant && seconds > 0 && (
              <a
                className="btn btn-primary"
                href={rawGrant.url}
                target="_blank"
                rel="noopener noreferrer"
                download={`${id}-raw.${item.evidence_type === "EML" ? "eml" : item.evidence_type === "TEXT" ? "txt" : "bin"}`}
              >
                <Download size={14} />
                Mở / tải tệp gốc · {seconds}s
              </a>
            )}
            {rawError && <ErrorNotice message={rawError} />}
            {rawExpires > 0 && (
              <p className="raw-countdown">
                <Clock3 size={12} />
                {seconds > 0
                  ? `Đã ghi audit · Quyền tải vừa cấp còn ${seconds}s`
                  : "URL đã hết hạn."}
              </p>
            )}
          </div>
        </Section>
      )}
    </>
  );
  return createPortal(
    <div className="modal-overlay">
      <div className="modal-backdrop" onClick={onClose} />
      <div
        className="detail-drawer"
        ref={dialog}
        role="dialog"
        aria-modal="true"
        aria-labelledby="incident-dialog-title"
      >
        <header className="detail-header">
          <div>
            <h2 id="incident-dialog-title" className="mono">
              {id}
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              className="icon-button"
              onClick={() => void refresh()}
              disabled={loading}
              aria-label="Làm mới chi tiết sự cố"
              title="Làm mới"
            >
              <RefreshCw size={16} />
            </button>
            <button
              className="icon-button"
              data-close
              onClick={onClose}
              aria-label="Đóng chi tiết"
            >
              <X size={21} />
            </button>
          </div>
        </header>
        <div className="detail-scroll">
          {loading ? (
            <Spinner />
          ) : error ? (
            <ErrorNotice message={error} onRetry={() => void refresh()} />
          ) : (
            item && (
              <>
                <div className="detail-title">
                  <IncidentIcon incident={item} />
                  <div>
                    <h1>{incidentLabel(item)}</h1>
                    <p>
                      {receivedTime(item.created_at)} <span>·</span>{" "}
                      {item.source_channel} <span>·</span> {item.evidence_type}
                    </p>
                  </div>
                </div>
                <div className="detail-status-row">
                  <StatusBadge status={item.status} />
                  {item.policy_evaluation?.assessment === "SUSPICIOUS" && (
                    <Badge tone="amber">Có dấu hiệu đáng ngờ theo luật</Badge>
                  )}
                  <Badge tone="neutral">{item.reporter_identity_status}</Badge>
                  {user.role === "AUDITOR" && (
                    <Badge tone="blue">AUDITOR · CHỈ ĐỌC</Badge>
                  )}
                </div>
                {item.status === "NEEDS_MORE_INFO" && (
                  <Notice tone="amber">
                    Cần bổ sung bằng chứng để chấm điểm.
                  </Notice>
                )}
                {displayedRisk(item) === "UNKNOWN" && (
                  <Notice tone="blue">
                    Chưa xác định. {item.policy_evaluation?.assessment_reason === "UNVERIFIED_URL"
                      ? "Có URL chưa xác minh. Hãy đối chiếu qua kênh chính thức."
                      : item.policy_evaluation?.assessment_reason === "INSUFFICIENT_SIGNALS"
                        ? "Các dấu hiệu hiện có chưa đủ để kết luận."
                        : "Hồ sơ cũ chưa lưu kết luận của policy."}
                    {" "}Điểm theo luật không chứng nhận an toàn.
                  </Notice>
                )}
                <div
                  className="detail-tabs"
                  role="tablist"
                  aria-label="Nội dung sự cố"
                >
                  {[
                    ["overview", "Tổng quan"],
                    ["evidence", "Bằng chứng đã che PII"],
                    ["activity", "Lịch sử xử lý"],
                  ]
                    .filter(
                      ([value]) =>
                        value !== "activity" || user.role !== "REPORTER",
                    )
                    .map(([value, label]) => (
                      <button
                        role="tab"
                        aria-selected={tab === value}
                        className={tab === value ? "active" : ""}
                        key={value}
                        onClick={() => setTab(value)}
                      >
                        {label}
                      </button>
                    ))}
                </div>
                {(tab === "overview" || tab === "evidence") && (
                  <div className="detail-grid">
                    <div className="detail-column">
                      <Section
                        title="Bằng chứng đã che PII"
                        aside={<code className="muted">evidence_table</code>}
                      >
                        <div className="table-scroll">
                          <table className="data-table evidence-table">
                            <thead>
                              <tr>
                                <th>BẰNG CHỨNG</th>
                                <th>GIÁ TRỊ</th>
                                <th>ĐÁNH GIÁ</th>
                              </tr>
                            </thead>
                            <tbody>
                              {item.agent_synthesis?.evidence_table.map(
                                (e, i) => (
                                  <tr key={i}>
                                    <td>
                                      <SafeText value={e.artifact} />
                                    </td>
                                    <td className="mono">
                                      <SafeText value={e.value} />
                                    </td>
                                    <td>
                                      <SafeText value={e.assessment} />
                                    </td>
                                  </tr>
                                ),
                              )}
                            </tbody>
                          </table>
                        </div>
                        {!item.agent_synthesis?.evidence_table.length && (
                          <p className="p-5 text-sm muted">
                            Chưa có bảng bằng chứng tổng hợp.
                          </p>
                        )}
                      </Section>
                      <Section title="Văn bản đã che PII">
                        <div className="redaction-counts">
                          {Object.entries(
                            item.deterministic_findings?.redacted_counts || {},
                          ).map(([k, v]) => (
                            <Badge key={k} tone="neutral">
                              {k} · {v}
                            </Badge>
                          ))}
                        </div>
                        <pre className="sanitized-excerpt">
                          <SafeText
                            value={
                              item.sanitized_text ||
                              item.deterministic_findings?.sanitized_text ||
                              item.deterministic_findings?.sanitized_excerpt ||
                              "Chưa có văn bản trích xuất."
                            }
                          />
                        </pre>
                        <p className="helper-text panel-body">
                          {item.sanitized_text_truncated &&
                            "Đang hiển thị trích đoạn của nội dung dài. "}
                          Tên người và địa chỉ có thể còn trong văn bản đã che.
                        </p>
                      </Section>
                      {tab === "overview" ? (
                        <>
                          {item.policy_evaluation && (
                            <Section
                              title="Policy Engine · Luật kích hoạt"
                              aside={<Severity incident={item} />}
                            >
                              <div
                                className="rule-list"
                                aria-label="Điểm rủi ro tất định"
                              >
                                <span className="sr-only">
                                  Điểm rủi ro tất định
                                </span>
                                {item.policy_evaluation.triggered_rules
                                  .length ? (
                                  item.policy_evaluation.triggered_rules.map(
                                    (r) => (
                                      <div className="rule-row" key={r.rule_id}>
                                        {r.points !== undefined && (
                                          <span className="rule-points">+{r.points}</span>
                                        )}
                                        <div>
                                          <strong className="mono">
                                            {r.rule_id}
                                          </strong>
                                          {r.reason && (
                                            <p><SafeText value={r.reason} /></p>
                                          )}
                                        </div>
                                      </div>
                                    ),
                                  )
                                ) : (
                                  <p className="p-5 muted text-sm">
                                    Chưa có luật nào kích hoạt.
                                  </p>
                                )}
                              </div>
                            </Section>
                          )}
                          {!!item.agent_synthesis?.rag_citations.length && (
                            <Section
                              title="Nguồn tham chiếu RAG"
                              aside={<BookOpen size={17} className="muted" />}
                            >
                              <div className="citation-list">
                                {item.agent_synthesis.rag_citations.map(
                                  (c, i) => (
                                    <details key={`${c.doc_id}-${i}`}>
                                      <summary>
                                        <span>
                                          <strong>
                                            <SafeText value={c.title} />
                                          </strong>
                                          <small className="mono">
                                            {c.doc_id}
                                          </small>
                                        </span>
                                        <ChevronRight size={15} />
                                      </summary>
                                      <p>
                                        <SafeText value={c.excerpt} />
                                      </p>
                                    </details>
                                  ),
                                )}
                              </div>
                            </Section>
                          )}
                          {item.agent_synthesis && (
                            <Section
                              title={
                                item.agent_synthesis.status === "OK"
                                  ? "Tổng hợp từ AI"
                                  : "Tổng hợp tất định"
                              }
                              aside={
                                item.agent_synthesis.status === "FALLBACK" && (
                                  <Badge tone="neutral">FALLBACK</Badge>
                                )
                              }
                            >
                              <p className="synthesis-text">
                                <SafeText
                                  value={item.agent_synthesis.summary_vi}
                                />
                              </p>
                            </Section>
                          )}
                          {item.agent_synthesis && (
                            <Section title="Khuyến nghị cho người báo cáo">
                              <ol className="recommendations">
                                {item.agent_synthesis.employee_recommendations.map(
                                  (r, i) => (
                                    <li key={i}>
                                      <SafeText value={r} />
                                    </li>
                                  ),
                                )}
                              </ol>
                            </Section>
                          )}
                          {[
                            "NEW",
                            "TRIAGING",
                            "TRIAGED",
                            "UPLOAD_PENDING",
                            "ACTION_REQUESTED",
                          ].includes(item.status) && (
                            <Spinner label="Đang chờ pipeline cập nhật kết quả…" />
                          )}
                        </>
                      ) : (
                        <>
                          {!!item.deterministic_findings?.extracted_urls
                            .length && (
                            <Section title="IOC đã giải độc">
                              <div className="ioc-list">
                                {item.deterministic_findings.extracted_urls.map(
                                  (u, i) => (
                                    <div key={i}>
                                      <LockKeyhole size={15} />
                                      <code>
                                        <SafeText value={u.display_value} />
                                      </code>
                                      {u.is_lookalike && (
                                        <Badge tone="red">LOOKALIKE</Badge>
                                      )}
                                      {u.is_blocklisted && <Badge tone="red">Trùng danh sách chặn</Badge>}
                                      {!u.is_lookalike && !u.is_blocklisted && <Badge>URL chưa xác minh</Badge>}
                                    </div>
                                  ),
                                )}
                              </div>
                            </Section>
                          )}
                          {item.ocr_quality && (
                            <Section title="Chất lượng trích xuất OCR">
                              <div className="ocr-info">
                                <Badge tone="neutral">
                                  {item.ocr_quality.engine}
                                </Badge>
                                <span>
                                  {item.ocr_quality.avg_confidence === null
                                    ? "Chưa đo độ tin cậy"
                                    : `${item.ocr_quality.avg_confidence}% độ tin cậy`}
                                </span>
                                {item.ocr_quality.word_count !== undefined && (
                                  <span>{item.ocr_quality.word_count} từ</span>
                                )}
                                {item.ocr_quality.normalized_chars !== undefined && (
                                  <span>{item.ocr_quality.normalized_chars} ký tự chuẩn hóa</span>
                                )}
                                <Badge tone="blue">
                                  {item.ocr_quality.status}
                                </Badge>
                              </div>
                            </Section>
                          )}
                        </>
                      )}
                    </div>
                    <div className="detail-column">
                      {item.evidence_type === "EML" && (item.email_auth ? (
                        <Section title="Xác thực email">
                          <dl className="header-list technical-fields">
                            <div>
                              <dt>email_auth.result</dt>
                              <dd>
                                <Badge
                                  tone={
                                    item.email_auth.result === "INDETERMINATE"
                                      ? "amber"
                                      : "neutral"
                                  }
                                >
                                  {item.email_auth.result}
                                </Badge>
                              </dd>
                            </div>
                            <div>
                              <dt>source</dt>
                              <dd>
                                <SafeText value={item.email_auth.source} />
                              </dd>
                            </div>
                          </dl>
                          {!!Object.keys(item.email_auth.claimed_headers)
                            .length && (
                            <details className="claimed-headers">
                              <summary>Header khai báo</summary>
                              <dl className="header-list technical-fields">
                                {Object.entries(
                                  item.email_auth.claimed_headers,
                                ).map(([k, v]) => (
                                  <div key={k}>
                                    <dt>{k}</dt>
                                    <dd>
                                      <SafeText value={v} />
                                    </dd>
                                  </div>
                                ))}
                              </dl>
                            </details>
                          )}
                          {item.email_auth.result === "INDETERMINATE" && (
                            <p className="panel-body muted">
                              Header tải lên và thư chuyển tiếp là dữ liệu khai
                              báo. DMARC của thư gốc chưa được xác minh.
                            </p>
                          )}
                        </Section>
                      ) : (
                        <Section title="Xác thực email">
                          <p className="panel-body muted">
                            Chưa có kết quả xác thực.
                          </p>
                        </Section>
                      ))}
                      {item.security_flags.includes(
                        "PROMPT_INJECTION_DETECTED",
                      ) && (
                        <Notice tone="red">
                          <strong>PROMPT_INJECTION_DETECTED</strong>
                          <p>
                            Policy Engine giữ nguyên điểm khi phát hiện cờ này.
                          </p>
                        </Notice>
                      )}
                      {rawEvidence}
                      {tab === "overview" && (
                        <>
                          {user.role !== "REPORTER" && action && (
                            <section className="panel action-panel">
                              <div className="panel-heading">
                                <h2>Human-in-the-Loop Decision</h2>
                                <Badge
                                  tone={
                                    action.mode === "DRY_RUN" ? "blue" : "green"
                                  }
                                >
                                  {action.mode}
                                </Badge>
                              </div>
                              {item.proposed_actions.length > 1 && (
                                <select
                                  aria-label="Chọn đề xuất hành động"
                                  value={action.action_id}
                                  onChange={(e) =>
                                    setActiveAction(e.target.value)
                                  }
                                >
                                  {item.proposed_actions.map((a) => (
                                    <option
                                      key={a.action_id}
                                      value={a.action_id}
                                    >
                                      {a.action_id} · {a.type}
                                    </option>
                                  ))}
                                </select>
                              )}
                              <div className="action-content">
                                <span className="mono action-type">
                                  {action.type}
                                </span>
                                <div className="action-target">
                                  <span>Mục tiêu</span>
                                  <strong className="mono">
                                    <SafeText value={action.display_target} />
                                  </strong>
                                </div>
                                <p>
                                  <SafeText value={action.impact_description} />
                                </p>
                                <dl className="technical-fields mono">
                                  <div>
                                    <dt>action_id</dt>
                                    <dd>{action.action_id}</dd>
                                  </div>
                                  <div>
                                    <dt>proposal_version</dt>
                                    <dd>{action.proposal_version}</dd>
                                  </div>
                                </dl>
                              </div>
                              {item.status === "PENDING_APPROVAL" &&
                                user.role === "SECOPS_ADMIN" && (
                                  <ApprovalForm
                                    key={`${item.incident_id}:${action.action_id}:${action.proposal_version}`}
                                    user={user}
                                    incident={item}
                                    action={action}
                                    onDone={done}
                                  />
                                )}{" "}
                              {user.role === "AUDITOR" && (
                                <div className="auditor-lock">
                                  <LockKeyhole size={15} />
                                  <span>
                                    Auditor có quyền đọc. SECOPS_ADMIN có quyền
                                    quyết định.
                                  </span>
                                  <button
                                    disabled
                                    title="Auditor không có quyền phê duyệt"
                                    className="btn btn-secondary"
                                  >
                                    Approve / Reject
                                  </button>
                                </div>
                              )}
                            </section>
                          )}
                          {item.approval_record && (
                            <Section title="Quyết định đã ghi nhận">
                              <div className="record-content">
                                <Badge
                                  tone={
                                    item.approval_record.decision === "APPROVE"
                                      ? "green"
                                      : "neutral"
                                  }
                                >
                                  {item.approval_record.decision}
                                </Badge>
                                <p>
                                  <SafeText
                                    value={
                                      item.approval_record.note ||
                                      "Không có ghi chú."
                                    }
                                  />
                                </p>
                                <small>
                                  {item.approval_record.actor_id} ·{" "}
                                  {dateTime(item.approval_record.decided_at)}
                                </small>
                                <dl className="technical-fields mono">
                                  <div>
                                    <dt>decision_id</dt>
                                    <dd>{item.approval_record.decision_id}</dd>
                                  </div>
                                  <div>
                                    <dt>proposal_version</dt>
                                    <dd>
                                      {item.approval_record.proposal_version}
                                    </dd>
                                  </div>
                                </dl>
                              </div>
                            </Section>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                )}
                {tab === "activity" && user.role !== "REPORTER" && (
                  <Section
                    title="Lịch sử xử lý"
                    subtitle="Các sự kiện có trong dữ liệu audit đã tải."
                  >
                    <div className="detail-timeline">
                      {entries.length ? (
                        entries.map((e, i) => (
                          <div key={e.audit_id || i}>
                            <span className="timeline-dot" />
                            <div>
                              <strong>{e.action}</strong>
                              <p>
                                <SafeText
                                  value={
                                    e.decision_note ||
                                    `${e.previous_status || "—"} → ${e.new_status || "—"}`
                                  }
                                />
                              </p>
                              <small>
                                {e.actor_id} · {dateTime(e.timestamp)}
                              </small>
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="muted text-sm">
                          Chưa có sự kiện trong dữ liệu audit đã tải.
                        </p>
                      )}
                    </div>
                  </Section>
                )}
                {tab === "activity" && rawEvidence}
              </>
            )
          )}
        </div>
      </div>
    </div>,
    document.body,
  );
}
