import { useMemo, useState } from "react";
import {
  ChevronLeft,
  ChevronRight,
  CircleAlert,
  Clock3,
  Filter,
  Inbox,
  Search,
  ShieldCheck,
  X,
} from "lucide-react";
import type { Incident, Status } from "../types";
import {
  Badge,
  EmptyState,
  Severity,
  StatusBadge,
  displayedRisk,
  incidentLabel,
  receivedTime,
} from "./ui";

const quickFilters: { value: "ALL" | Status; label: string }[] = [
  { value: "ALL", label: "Tất cả" },
  { value: "PENDING_APPROVAL", label: "Chờ phê duyệt" },
  { value: "NEEDS_REVIEW", label: "Cần kiểm tra" },
  { value: "NEEDS_MORE_INFO", label: "Cần bổ sung" },
  { value: "SIMULATED", label: "Đã mô phỏng" },
  { value: "REJECTED", label: "Đã từ chối" },
];
export function IncidentTable({
  incidents,
  onOpen,
  personal = false,
}: {
  incidents: Incident[];
  onOpen: (id: string) => void;
  personal?: boolean;
}) {
  const [filter, setFilter] = useState<"ALL" | Status>("ALL");
  const [search, setSearch] = useState("");
  const [severity, setSeverity] = useState("ALL");
  const [assessment, setAssessment] = useState("ALL");
  const [sort, setSort] = useState("newest");
  const [page, setPage] = useState(0);
  const filtered = useMemo(
    () =>
      incidents
        .filter(
          (i) =>
            (filter === "ALL" || i.status === filter) &&
            (severity === "ALL" ||
              i.policy_evaluation?.severity === severity) &&
            (assessment === "ALL" || (displayedRisk(i) === "UNKNOWN" ? "UNKNOWN" : i.policy_evaluation?.assessment) === assessment) &&
            [
              i.incident_id,
              incidentLabel(i),
              i.reporter_id,
              ...(i.deterministic_findings?.extracted_urls.map(
                (u) => u.display_value,
              ) || []),
            ]
              .join(" ")
              .toLowerCase()
              .includes(search.toLowerCase()),
        )
        .sort(
          (a, b) =>
            (Date.parse(b.created_at) - Date.parse(a.created_at)) *
            (sort === "newest" ? 1 : -1),
        ),
    [incidents, filter, search, severity, assessment, sort],
  );
  const pageSize = 7;
  const maxPage = Math.max(0, Math.ceil(filtered.length / pageSize) - 1);
  const current = Math.min(page, maxPage);
  const visible = filtered.slice(current * pageSize, (current + 1) * pageSize);
  const changeFilter = (value: "ALL" | Status) => {
    setFilter(value);
    setPage(0);
  };
  return (
    <section className="panel queue-panel">
      <div className="panel-heading">
        <div className="flex items-center gap-2.5">
          <h2>{personal ? "Báo cáo của bạn" : "Hàng đợi sự cố"}</h2>
          <span className="count-chip">{incidents.length}</span>
        </div>
      </div>
      <div className="filter-tabs" role="group" aria-label="Lọc trạng thái">
        {quickFilters.map((f) => (
          <button
            key={f.value}
            onClick={() => changeFilter(f.value)}
            className={filter === f.value ? "active" : ""}
            title={f.value}
          >
            {f.label}
            {f.value === "PENDING_APPROVAL" && (
              <span>
                {incidents.filter((i) => i.status === f.value).length}
              </span>
            )}
          </button>
        ))}
        <select
          aria-label="Trạng thái khác"
          value={quickFilters.some((f) => f.value === filter) ? "" : filter}
          onChange={(e) =>
            e.target.value && changeFilter(e.target.value as Status)
          }
        >
          <option value="">Trạng thái khác</option>
          {(
            [
              "UPLOAD_PENDING",
              "NEW",
              "TRIAGING",
              "TRIAGED",
              "NO_ACTION",
              "ESCALATED_TIMEOUT",
              "ACTION_REQUESTED",
              "INTERNAL_LIST_UPDATED",
              "CONTAINMENT_FAILED",
              "FAILED",
            ] as Status[]
          ).map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>
      <div className="table-toolbar">
        <label className="search-box">
          <Search size={17} />
          <input
            aria-label="Tìm sự cố"
            placeholder="Tìm mã sự cố, nội dung hoặc IOC…"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(0);
            }}
          />
          {search && (
            <button aria-label="Xóa tìm kiếm" onClick={() => setSearch("")}>
              <X size={14} />
            </button>
          )}
        </label>
        <div className="flex flex-wrap gap-2">
          <select className="sort-select" aria-label="Lọc kết luận" value={assessment}
            onChange={(e) => { setAssessment(e.target.value); setPage(0); }}>
            <option value="ALL">Mọi kết luận</option>
            <option value="UNKNOWN">Chưa xác định</option>
            <option value="SUSPICIOUS">Có dấu hiệu đáng ngờ</option>
          </select>
          <label className="select-wrap">
            <Filter size={14} />
            <select
              aria-label="Lọc mức rủi ro"
              value={severity}
              onChange={(e) => {
                setSeverity(e.target.value);
                setPage(0);
              }}
            >
              <option value="ALL">Mọi mức điểm luật</option>
              {["CRITICAL", "HIGH", "MEDIUM", "LOW"].map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </label>
          <select
            className="sort-select"
            aria-label="Sắp xếp"
            value={sort}
            onChange={(e) => setSort(e.target.value)}
          >
            <option value="newest">Mới nhất trước</option>
            <option value="oldest">Cũ nhất trước</option>
          </select>
        </div>
      </div>
      <div className="table-scroll">
        <table className="incident-table">
          <thead>
            <tr>
              <th scope="col">Mã sự cố</th>
              <th scope="col">Phân loại</th>
              <th scope="col">Nguồn</th>
              <th scope="col">Rủi ro</th>
              <th scope="col">Trạng thái</th>
              <th scope="col">Tiếp nhận (giờ Việt Nam)</th>
            </tr>
          </thead>
          <tbody>
            {visible.map((i) => (
              <tr key={i.incident_id}>
                <td>
                  <button
                    className="table-link mono"
                    aria-label={`Mở ${i.incident_id}`}
                    onClick={() => onOpen(i.incident_id)}
                  >
                    {i.incident_id}
                  </button>
                </td>
                <td>
                  <span className="incident-label">{incidentLabel(i)}</span>
                  {i.security_flags.includes("PROMPT_INJECTION_DETECTED") && (
                    <span
                      className="injection-tag"
                      title="PROMPT_INJECTION_DETECTED"
                    >
                      <Badge tone="red">INJECTION</Badge>
                    </span>
                  )}
                </td>
                <td>
                  <span className="source-label mono">{i.evidence_type}</span>
                  <span className="cell-sub mono">{i.source_channel}</span>
                </td>
                <td>
                  <Severity incident={i} />
                </td>
                <td>
                  <StatusBadge status={i.status} />
                </td>
                <td>
                  <span className="log-time mono">
                    {receivedTime(i.created_at)}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!visible.length && <EmptyState />}
      <div className="table-footer">
        <span>
          {filtered.length
            ? `Hiển thị ${current * pageSize + 1}–${Math.min((current + 1) * pageSize, filtered.length)} trên ${filtered.length} sự cố`
            : "0 sự cố phù hợp"}
        </span>
        <div className="pagination">
          <button
            aria-label="Trang trước"
            disabled={current === 0}
            onClick={() => setPage(current - 1)}
          >
            <ChevronLeft size={15} />
          </button>
          <span>{current + 1}</span>
          <button
            aria-label="Trang sau"
            disabled={current >= maxPage}
            onClick={() => setPage(current + 1)}
          >
            <ChevronRight size={15} />
          </button>
        </div>
      </div>
    </section>
  );
}
export function Queue({
  incidents,
  onOpen,
}: {
  incidents: Incident[];
  onOpen: (id: string) => void;
}) {
  const pending = incidents.filter(
    (i) => i.status === "PENDING_APPROVAL",
  ).length;
  const critical = incidents.filter(
    (i) => i.policy_evaluation?.severity === "CRITICAL",
  ).length;
  const contained = incidents.filter((i) =>
    ["SIMULATED", "INTERNAL_LIST_UPDATED"].includes(i.status),
  ).length;
  const cards = [
    {
      label: "Total Ingested",
      value: incidents.length,
      Icon: Inbox,
      tone: "neutral",
    },
    {
      label: "Pending HITL Approval",
      value: pending,
      Icon: Clock3,
      tone: "amber",
    },
    {
      label: "Critical (Score >= 75)",
      value: critical,
      Icon: CircleAlert,
      tone: "red",
    },
    {
      label: "Executed / Simulated",
      value: contained,
      Icon: ShieldCheck,
      tone: "green",
    },
  ];
  return (
    <>
      <dl
        className="stats-grid"
        aria-label="Chỉ số hàng đợi"
        title="Tính trên các sự cố đã tải"
      >
        {cards.map(({ label, value, Icon, tone }) => (
          <div className={`stat-card stat-${tone}`} key={label}>
            <div>
              <dt>{label}</dt>
              <dd className="mono">{value}</dd>
            </div>
            <Icon size={17} aria-hidden="true" />
          </div>
        ))}
      </dl>
      <IncidentTable incidents={incidents} onOpen={onOpen} />
    </>
  );
}
