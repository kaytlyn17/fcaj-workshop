"""Targeted Phase H regressions using local AWS service doubles and the project's src/."""
from contextlib import redirect_stdout
from io import StringIO
import json
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock, patch

import boto3
from botocore.exceptions import ClientError
from moto import mock_aws

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
import admin_api
import common
import extract_redact
import ingest
import synthesize
from policy import evaluate, lookalike


def email_fixture(name):
    raw = (ROOT / "fixtures" / "phase-h" / name).read_bytes()
    text, auth, findings = extract_redact.email_text(raw)
    return auth, findings, evaluate(extract_redact.redact(text), header_anomaly=bool(findings))


class WorkshopCases(unittest.TestCase):
    def test_h05_different_return_path(self):
        auth, findings, result = email_fixture("H05-return-path.eml")
        self.assertNotEqual(auth["claimed_headers"]["from_domain"], auth["claimed_headers"]["return_path_domain"])
        self.assertEqual(auth["result"], "INDETERMINATE")
        self.assertIn("HEADER_ENVELOPE_FROM_MISMATCH", findings)
        self.assertNotIn("AUTH_DMARC_FAIL", result["security_flags"] + result["policy_evaluation"]["triggered_rules"])
        self.assertEqual(result["policy_evaluation"]["risk_score"], 0)

    def test_h06_sender_rejected_and_metric_logged(self):
        for verdict in ("PASS", "FAIL"):
            with self.subTest(verdict=verdict):
                capture = StringIO()
                record = {"ses": {"receipt": {"dmarcVerdict": {"status": verdict}},
                                   "mail": {"messageId": "workshop-h06"}}}
                raw = b"From: unseen@example.org\r\nSubject: Test\r\n\r\nTest."
                with patch.dict(os.environ, {"INTAKE_BUCKET": "test", "ALLOWED_SENDER_DOMAINS": "example.org"}), \
                        patch.object(ingest, "cognito_reporter", return_value=None), \
                        patch.object(ingest, "read_s3", return_value=(raw, {})), \
                        patch.object(ingest, "table") as table, redirect_stdout(capture):
                    ingest.ingest_one(record)
                table.assert_not_called()
                log = json.loads(capture.getvalue())
                self.assertEqual((log["event"], log["UnverifiedSender"]), ("UNVERIFIED_SENDER", 1))
                metric = log["_aws"]["CloudWatchMetrics"][0]
                self.assertEqual((metric["Namespace"], metric["Metrics"][0]["Name"]), ("PhishGuard", "UnverifiedSender"))

    def test_h07_safe_warning(self):
        result = evaluate("Ngân hàng không yêu cầu cung cấp OTP hoặc mật khẩu.")
        self.assertNotIn("FINANCIAL_OR_OTP_REQUEST", result["policy_evaluation"]["triggered_rules"])

    def test_h08_warning_accompanied_by_test_link(self):
        text = "Ngân hàng không yêu cầu cung cấp OTP. Tình huống mô phỏng: nhập OTP tại hxxps://example[.]org/test."
        result = evaluate(text)
        self.assertTrue(result["deterministic_findings"]["urls"])
        self.assertIn("FINANCIAL_OR_OTP_REQUEST", result["policy_evaluation"]["triggered_rules"])

    def test_h12_domain_cases(self):
        for host, expected in [
            ("pacbell.net", False), ("online.techcombank.com.vn", False),
            ("acb-online.xyz", True), ("techcombank.com.vn.evil.top", True), ("login.techc0mbank-vn.com", True),
        ]:
            with self.subTest(host=host):
                self.assertEqual(lookalike(host), expected)

    def test_h10_invalid_schema_and_guardrail_fallback(self):
        doc = {"text": "Tin nhắn kiểm thử.", "header_findings": [], "evidence_type": "EML", "email_auth": {}}
        policy = {"severity": "CRITICAL", "risk_score": 80, "triggered_rules": []}
        for response, expected in [
            ({"stopReason": "end_turn", "output": {"message": {"content": [{"text": "{}"}]}}}, "INVALID_MODEL_OUTPUT"),
            ({"stopReason": "guardrail_intervened"}, "GUARDRAIL_INTERVENED"),
        ]:
            with self.subTest(expected=expected), patch.dict(os.environ, {
                "MODEL_ID": "model-test", "KNOWLEDGE_BASE_ID": "kb-test", "GUARDRAIL_ID": "guard-test", "GUARDRAIL_VERSION": "1"
            }), patch.object(synthesize, "read_sanitized", return_value=doc), \
                    patch.object(synthesize, "retrieve_sources", return_value=[{"source_id": "unit", "text": "Tham chiếu."}]), \
                    patch.object(synthesize, "client") as client:
                client.return_value.converse.return_value = response
                output, _ = synthesize.guarded_synthesis({"policy_evaluation": policy})
                self.assertEqual((output["status"], output["fallback_reason"]), ("FALLBACK", expected))
                self.assertEqual(policy["risk_score"], 80)
                self.assertNotIn("toolConfig", client.return_value.converse.call_args.kwargs)

    def test_h11_high_without_target(self):
        _, _, result = email_fixture("H11-manual-review.eml")
        self.assertEqual((result["policy_evaluation"]["risk_score"], result["policy_evaluation"]["severity"]), (50, "HIGH"))
        self.assertTrue(result["requires_manual_review"])
        self.assertEqual(result["proposed_actions"], [])


class RetryCases(unittest.TestCase):
    def setUp(self):
        self.enterContext(patch.dict(os.environ, {
            "AWS_DEFAULT_REGION": "us-east-1", "AWS_ACCESS_KEY_ID": "testing", "AWS_SECRET_ACCESS_KEY": "testing",
            "INCIDENTS_TABLE": "WorkshopIncidents", "EVIDENCE_BUCKET": "workshop-evidence",
            "APPROVAL_TIMEOUT_SECONDS": "60", "WORKFLOW_ARN": "arn:aws:states:us-east-1:123456789012:stateMachine:workshop",
            "DATA_KEY_ARN": "arn:aws:kms:us-east-1:123456789012:key/00000000-0000-0000-0000-000000000001",
        }))
        self.enterContext(mock_aws())
        self.table = boto3.resource("dynamodb").create_table(TableName=os.environ["INCIDENTS_TABLE"],
            AttributeDefinitions=[{"AttributeName": "incident_id", "AttributeType": "S"}],
            KeySchema=[{"AttributeName": "incident_id", "KeyType": "HASH"}], BillingMode="PAY_PER_REQUEST")
        self.identifier = "INC-000000000001"

    def test_h04_ingest_retry_after_evidence_put(self):
        s3 = boto3.client("s3")
        bucket = os.environ["EVIDENCE_BUCKET"]
        s3.create_bucket(Bucket=bucket)
        s3.put_bucket_versioning(Bucket=bucket, VersioningConfiguration={"Status": "Enabled"})
        sfn = Mock()
        sfn.start_execution.return_value = {"executionArn": "execution-test"}
        row = {"incident_id": self.identifier, "source_channel": "WEB_PORTAL", "evidence_type": "TEXT", "status": "UPLOAD_PENDING"}
        self.table.put_item(Item=row)
        def write_row(**kwargs):
            if "raw_s3_key" in kwargs["UpdateExpression"]:
                raise RuntimeError("interrupt-after-S3")
            return self.table.update_item(**kwargs)
        failed_table = Mock()
        failed_table.update_item.side_effect = write_row
        with patch.object(ingest, "s3_item", return_value=(row, b"Workshop test")), \
                patch.object(ingest, "client", side_effect={"s3": s3, "stepfunctions": sfn}.__getitem__):
            with patch.object(ingest, "table", return_value=failed_table), self.assertRaisesRegex(RuntimeError, "interrupt-after-S3"):
                ingest.ingest_one({})
            sfn.start_execution.assert_not_called()
            ingest.ingest_one({})
            ingest.ingest_one({})
        versions = s3.list_object_versions(Bucket=bucket)["Versions"]
        self.assertEqual([v["Key"] for v in versions], [f"evidence/{self.identifier}/raw"])
        sfn.start_execution.assert_called_once()
        self.assertEqual(sfn.start_execution.call_args.kwargs["name"], self.identifier)
        self.assertEqual(common.get_incident(self.identifier)["sfn_execution_arn"], "execution-test")

    def test_h13_callback_done_then_marker_write_fails(self):
        action = {"action_id": "ACT-001", "proposal_version": 1, "type": "FINANCE_VERIFICATION_ALERT", "target": "FINANCE", "mode": "DRY_RUN"}
        self.table.put_item(Item={"incident_id": self.identifier, "status": "PENDING_APPROVAL", "proposed_actions": [action],
            "policy_evaluation": {"triggered_rules": ["EXEC_IMPERSONATION"]}, "sfn_task_token": "dummy"})
        payload = {"action_id": action["action_id"], "proposal_version": 1, "decision": "APPROVE", "decision_id": "workshop-h13"}
        def fail_marker(**kwargs):
            if "callback_sent=:true" in kwargs["UpdateExpression"]:
                raise ClientError({"Error": {"Code": "InternalServerError"}}, "UpdateItem")
            return self.table.update_item(**kwargs)
        faulty = Mock()
        faulty.update_item.side_effect = fail_marker
        with patch.object(admin_api, "client") as client:
            client.return_value.send_task_success.side_effect = lambda **kw: common.update_incident(self.identifier, status="SIMULATED")
            def call_decision(_):
                return admin_api.decision(self.identifier, "test-admin", payload)
            with patch.object(admin_api, "table", return_value=faulty), redirect_stdout(StringIO()):
                self.assertEqual(common.api_wrapper(call_decision, {})["statusCode"], 500)
            self.assertFalse(common.get_incident(self.identifier)["approval_record"]["callback_sent"])
            replay = common.api_wrapper(call_decision, {})
            self.assertEqual(replay["statusCode"], 200)
            self.assertTrue(json.loads(replay["body"])["retry"])
            self.assertTrue(common.get_incident(self.identifier)["approval_record"]["callback_sent"])
            client.return_value.send_task_success.assert_called_once()


if __name__ == "__main__":
    unittest.main(verbosity=2)
