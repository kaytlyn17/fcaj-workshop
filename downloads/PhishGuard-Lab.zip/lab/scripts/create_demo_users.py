"""Create three real-email Cognito users without printing or storing passwords."""
import argparse
from getpass import getpass
import json
import re
import sys

import boto3
from botocore.exceptions import BotoCoreError, ClientError

USERS = [("demo-reporter", "REPORTER", "reporter_email"),
         ("demo-secops-admin", "SECOPS_ADMIN", "admin_email"),
         ("demo-auditor", "AUDITOR", "auditor_email")]


def validate_email(value):
    value = value.strip().lower()
    if not re.fullmatch(r"[^\s@\"\\]+@[a-z0-9.-]+\.[a-z]{2,}", value):
        raise ValueError("Email không hợp lệ")
    domain = value.rsplit("@", 1)[1]
    if domain.endswith((".local", ".invalid", ".example", ".test")) or domain == "example.com":
        raise ValueError("Dùng email thật có thể nhận/gửi thư; không dùng miền giả lập")
    return value


def validate_password(value):
    if not 12 <= len(value) <= 256 or re.search(r"\s", value) or not all(re.search(pattern, value) for pattern in (r"[a-z]", r"[A-Z]", r"[0-9]", r"[^A-Za-z0-9\s]")):
        raise ValueError("Mật khẩu cần 12-256 ký tự, không có khoảng trắng, gồm chữ hoa, chữ thường, số và ký tự đặc biệt")
    return value


def ensure_user(client, pool, username, role, email, password_reader=getpass):
    try:
        existing = client.admin_get_user(UserPoolId=pool, Username=username)
    except ClientError as exc:
        if exc.response["Error"]["Code"] != "UserNotFoundException":
            raise
        existing = None
    if existing:
        attrs = {v["Name"]: v["Value"] for v in existing["UserAttributes"]}
        if attrs.get("email", "").lower() != email:
            raise ValueError(f"{username} đã tồn tại với email khác; không thay đổi tài khoản này")
        groups = client.admin_list_groups_for_user(UserPoolId=pool, Username=username).get("Groups", [])
        if any(g["GroupName"] != role for g in groups):
            raise ValueError(f"{username} đã có group khác; không tự đổi quyền")
        if existing.get("UserStatus") == "FORCE_CHANGE_PASSWORD":
            first = validate_password(password_reader(f"Hoàn tất mật khẩu cho {username}: "))
            if first != password_reader("Nhập lại mật khẩu: "):
                raise ValueError("Hai mật khẩu không khớp")
            client.admin_set_user_password(UserPoolId=pool, Username=username, Password=first, Permanent=True)
            del first
        elif existing.get("UserStatus") != "CONFIRMED":
            raise ValueError(f"{username} chưa CONFIRMED; cần xử lý tài khoản hiện có trước khi chạy lại")
    else:
        first = validate_password(password_reader(f"Mật khẩu cho {username} (không hiển thị): "))
        if first != password_reader("Nhập lại mật khẩu: "):
            raise ValueError("Hai mật khẩu không khớp")
        client.admin_create_user(UserPoolId=pool, Username=username, TemporaryPassword=first,
            MessageAction="SUPPRESS", UserAttributes=[{"Name": "email", "Value": email},
                                                     {"Name": "email_verified", "Value": "true"}])
        client.admin_set_user_password(UserPoolId=pool, Username=username, Password=first, Permanent=True)
        del first
    client.admin_add_user_to_group(UserPoolId=pool, Username=username, GroupName=role)
    current = client.admin_get_user(UserPoolId=pool, Username=username)
    memberships = client.admin_list_groups_for_user(UserPoolId=pool, Username=username).get("Groups", [])
    if current["UserStatus"] != "CONFIRMED" or {g["GroupName"] for g in memberships} != {role}:
        raise ValueError("Cognito account verification failed")
    return {"username": username, "group": role, "status": current["UserStatus"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", default="phishguard")
    parser.add_argument("--stack-name", default="phishguard-ai")
    parser.add_argument("--reporter-email")
    parser.add_argument("--admin-email")
    parser.add_argument("--auditor-email")
    args = parser.parse_args()
    emails = {key: validate_email(getattr(args, key) or input(f"Email thật cho {role}: ")) for _, role, key in USERS}
    if len(set(emails.values())) != 3:
        raise ValueError("Cần 3 địa chỉ email khác nhau để ánh xạ SES không bị trùng")
    print("Chỉ nhập email do bạn kiểm soát; script đánh dấu email_verified theo xác nhận của người quản trị.")
    session = boto3.Session(profile_name=args.profile, region_name="us-east-1")
    stack = session.client("cloudformation").describe_stacks(StackName=args.stack_name)["Stacks"][0]
    outputs = {v["OutputKey"]: v["OutputValue"] for v in stack.get("Outputs", [])}
    pool = outputs.get("UserPoolId")
    if not pool:
        raise ValueError("Chưa có UserPoolId trong stack Outputs; deploy 2B trước")
    client = session.client("cognito-idp")
    for username, role, key in USERS:
        print(json.dumps(ensure_user(client, pool, username, role, emails[key]), ensure_ascii=False))
    print("GATE: DEMO_USERS_CONFIRMED")
    return 0


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        raise SystemExit(main())
    except (ValueError, BotoCoreError, ClientError, EOFError) as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(1)
