"""Offline, split-aware evaluation of text policy or image extraction through triage."""
import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "fixtures" / "evaluation"
sys.path.insert(0, str(ROOT / "src"))
from extract_redact import extract_document
from policy import extract_urls
from triage import score_document


def load_cases(folder, split):
    groups = json.loads((folder / "partitions.json").read_text(encoding="utf-8"))
    assignments = {}
    for partition in ("development", "holdout"):
        for group in groups[partition]:
            if group in assignments:
                raise ValueError(f"Duplicate group assignment: {group}")
            assignments[group] = partition
    if not groups[split] and not (folder / f"{split}.jsonl").exists():
        return []
    rows, ids = [], set()
    for line in (folder / f"{split}.jsonl").read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        for key in ("id", "group", "source", "rationale"):
            if not isinstance(row.get(key), str) or not row[key].strip():
                raise ValueError(f"Missing {key} in {split}")
        identifier = row["id"]
        if identifier in ids or assignments.get(row["group"]) != split:
            raise ValueError(f"Duplicate ID or invalid split for {identifier}")
        if row.get("label") not in ("phishing", "benign") or row.get("mode") not in ("text", "ocr"):
            raise ValueError(f"Invalid label or mode for {identifier}")
        if ("text" in row) == ("file" in row) or (row["mode"] == "ocr" and "file" not in row):
            raise ValueError(f"Expected one input for {identifier} (file required for OCR)")
        ids.add(identifier)
        rows.append(row)
    return rows


def run_case(row, folder, config):
    raw = (folder / row["file"]).read_bytes() if "file" in row else row["text"].encode("utf-8")
    image = row["mode"] == "ocr"
    document = extract_document(raw, "IMAGE" if image else "TEXT",
                                confidence_min=config["ocr_confidence_min"], min_chars=config["ocr_min_chars"])
    case = {"id": row["id"], "label": row["label"], "input_sha256": sha256(raw).hexdigest()}
    quality = document["ocr_quality"]
    if image:
        case["ocr_quality"] = quality
        if not quality["acceptable"] and not quality["qr_url_count"]:
            return {**case, "prediction": "NO_INPUT_DECISION", "status": "NEEDS_MORE_INFO"}
    result = score_document(document, urls=extract_urls(document["text"]), blocklist=config["blocklist"],
                            mode=config["containment_mode"])
    policy = result["policy_evaluation"]
    status = "NO_ACTION"
    if result["proposed_actions"]:
        status = "PENDING_APPROVAL"
    elif result["requires_manual_review"]:
        status = "NEEDS_REVIEW"
    return {**case, "prediction": policy["assessment"], "status": status,
            "policy": policy, "urls": [u["display_value"] for u in result["deterministic_findings"]["urls"]],
            "action_types": [a["type"] for a in result["proposed_actions"]]}


def metrics(cases):
    counts = Counter((c["label"], c["prediction"]) for c in cases)
    statuses = Counter(c["status"] for c in cases)
    detected = counts["phishing", "SUSPICIOUS"]
    n = len(cases)
    return {
        "total": n, "true_positives": detected, "false_positives": counts["benign", "SUSPICIOUS"],
        "false_negatives": sum(c["label"] == "phishing" for c in cases) - detected,
        "unknown": sum(c["prediction"] == "UNKNOWN" for c in cases),
        "needs_more_info": statuses["NEEDS_MORE_INFO"], "needs_review": statuses["NEEDS_REVIEW"],
        "pending_approval": statuses["PENDING_APPROVAL"],
        "manual_review_rate": statuses["NEEDS_REVIEW"] / n if n else None,
        "human_routing_rate": (statuses["NEEDS_REVIEW"] + statuses["PENDING_APPROVAL"]) / n if n else None,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=DATA)
    parser.add_argument("--split", choices=("development", "holdout"), default="development")
    parser.add_argument("--mode", choices=("text", "ocr"), default="text")
    args = parser.parse_args()
    config_bytes = (args.dataset / "config.json").read_bytes()
    config = json.loads(config_bytes)
    rows = [r for r in load_cases(args.dataset, args.split) if r["mode"] == args.mode]
    cases, errors = [], []
    for row in rows:
        try:
            cases.append(run_case(row, args.dataset, config))
        except (ImportError, OSError, RuntimeError, ValueError) as error:
            errors.append({"id": row["id"], "error": str(error)})
    print(json.dumps({
        "split": args.split, "mode": args.mode, "state": "INCOMPLETE" if errors else "MEASURED" if rows else "NO_DATA",
        "config_sha256": sha256(config_bytes).hexdigest(),
        "policy_sha256": sha256((ROOT / "src" / "policy.py").read_bytes()).hexdigest(),
        "dataset_sha256": sha256(json.dumps(rows, ensure_ascii=False, sort_keys=True).encode()).hexdigest(),
        "metrics": metrics(cases) if cases else None, "cases": cases, "errors": errors,
    }, indent=2))
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
