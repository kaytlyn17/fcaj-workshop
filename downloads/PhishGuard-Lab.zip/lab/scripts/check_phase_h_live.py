"""Run scoped acceptance checks using Cognito demo users on the phishguard-ai workshop stack."""
import argparse
from time import sleep
from uuid import uuid4
import json
import re
import sys

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from phase2b_smoke import call, check
from verify_group2_samples import login, request, wait_incident


def check_reports(base, reporter, second, workflow, states):
    payload = {"idempotency_key": uuid4().hex, "text": "Workshop H01. Máy in đã sẵn sàng."}
    def submit(token):
        item = request(base, token, "POST", "/api/reports", expected=202, payload=payload)
        return item["incident_id"]

    first = submit(reporter)
    check(submit(reporter) == first, "H01_SAME_INCIDENT")
    print("H01 incident:", first, flush=True)
    wait_incident(base, reporter, first, "NO_ACTION", {"UPLOAD_PENDING", "NEW", "TRIAGING", "TRIAGED"}, 360)
    arn = workflow.replace(":stateMachine:", ":execution:", 1) + ":" + first
    for attempt in range(5):
        try:
            execution = states.describe_execution(executionArn=arn)
            break
        except ClientError as ex:
            if ex.response["Error"]["Code"] != "ExecutionDoesNotExist" or attempt == 4:
                raise
            sleep(1)
    check(execution["name"] == first and json.loads(execution["input"])["incident_id"] == first, "H01_NAMED_EXECUTION")
    if second is not None:
        other = submit(second)
        print("H02 incidents:", first, other, flush=True)
        check(first != other, "H02_DIFFERENT_INCIDENTS")
        for token, own, foreign in [(reporter, first, other), (second, other, first)]:
            check(request(base, token, "GET", f"/api/incidents/{own}")["incident_id"] == own, "H02_OWN_READ_200")
            status, _ = call(base, "GET", f"/api/incidents/{foreign}", token)
            check(status in (403, 404), "H02_FOREIGN_READ_DENIED")
    else:
        print("H02 SKIPPED (requires --other-reporter)")
    status, result = call(base, "POST", "/api/reports", reporter, dict(payload, text="Workshop H03. Nội dung thứ hai."))
    check(status == 409 and result.get("error") == "IDEMPOTENCY_KEY_REUSED", "H03_REUSED_409")
    status, result = call(base, "POST", "/api/reports", reporter, dict(payload, idempotency_key="x"))
    check(status == 400 and result.get("error") == "INVALID_IDEMPOTENCY_KEY", "H03_INVALID_400")


def check_expired(base, admin, identifier):
    incident = request(base, admin, "GET", f"/api/incidents/{identifier}")
    if incident.get("status") != "ESCALATED_TIMEOUT":
        raise ValueError("Chờ đúng incident H14 chuyển sang ESCALATED_TIMEOUT rồi chạy lại.")
    action = incident["proposed_actions"][0]
    status, body = call(base, "POST", f"/api/incidents/{identifier}/decision", admin, {
        "decision_id": uuid4().hex, "action_id": action["action_id"],
        "proposal_version": action["proposal_version"], "decision": "REJECT",
    })
    check(status == 409 and body.get("error") == "APPROVAL_EXPIRED", "H14_LATE_DECISION_409")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", default="phishguard")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--other-reporter", help="Second workshop user, belonging only to REPORTER.")
    group.add_argument("--expired", metavar="INC-ID", help="Check only a previously expired demo incident.")
    args = parser.parse_args()
    if args.expired and not re.fullmatch(r"INC-[0-9a-f]{12}", args.expired):
        parser.error("Use the incident ID shown in the dashboard.")
    session = boto3.Session(profile_name=args.profile, region_name="us-east-1")
    stack = session.client("cloudformation").describe_stacks(StackName="phishguard-ai")["Stacks"][0]
    outputs = {row["OutputKey"]: row["OutputValue"] for row in stack["Outputs"]}
    base = outputs["HttpApiEndpoint"]
    def token(username):
        return login(session.client("cognito-idp"), outputs["UserPoolClientId"], username)
    if args.expired:
        check_expired(base, token("demo-secops-admin"), args.expired)
    else:
        reporter = token("demo-reporter")
        second = token(args.other_reporter) if args.other_reporter else None
        check_reports(base, reporter, second, outputs["WorkflowArn"], session.client("stepfunctions"))


if __name__ == "__main__":
    try:
        main()
    except ClientError as exc:
        print(f"{exc.operation_name}: {exc.response['Error']['Code']}", file=sys.stderr)
        raise SystemExit(1)
    except (ValueError, BotoCoreError, KeyError, OSError, IndexError) as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        raise SystemExit(1)
