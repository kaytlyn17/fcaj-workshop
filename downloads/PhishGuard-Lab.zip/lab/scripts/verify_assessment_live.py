"""Submit three lab reports through the live portal and verify their public results."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
from uuid import uuid4

import boto3

from verify_group1_upload import verify_presign
from verify_group2_samples import login, request, wait_incident

ROOT = Path(__file__).resolve().parents[1]
PROCESSING = {"UPLOAD_PENDING", "NEW", "TRIAGING", "TRIAGED"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", default="phishguard")
    parser.add_argument("--stack-name", default="phishguard-ai")
    parser.add_argument("--reporter", default="demo-reporter")
    args = parser.parse_args()
    if not sys.stdin.isatty():
        parser.error("Use an interactive terminal for the reporter's hidden password prompt.")
    aws = boto3.Session(profile_name=args.profile, region_name="us-east-1")
    stack = aws.client("cloudformation").describe_stacks(StackName=args.stack_name)["Stacks"][0]
    params = {row["ParameterKey"]: row["ParameterValue"] for row in stack["Parameters"]}
    outputs = {row["OutputKey"]: row["OutputValue"] for row in stack["Outputs"]}
    portal = params["CloudFrontOrigin"]
    if not portal or params["ContainmentMode"] != "DRY_RUN":
        raise ValueError("This workshop verification requires the live CloudFront origin and DRY_RUN.")
    token = login(aws.client("cognito-idp"), outputs["UserPoolClientId"], args.reporter)
    for name, status, assessment in [
        ("sms", "NEEDS_REVIEW", "SUSPICIOUS"), ("url", "NO_ACTION", "UNKNOWN"),
        ("sample-1", "PENDING_APPROVAL", "SUSPICIOUS"),
    ]:
        if name == "sms":
            png = ROOT / "fixtures/regression/sms.png"
            identifier = verify_presign(portal, token, png.name, png.read_bytes())
        else:
            payload = {"text": "Xem lịch sinh hoạt tại www.calendar.example.org."} if name == "url" else {"sample_id": name}
            receipt = request(portal, token, "POST", "/api/reports", expected=202,
                              payload={**payload, "idempotency_key": uuid4().hex})
            identifier = receipt["incident_id"]
        print(f"{name}: {identifier}", flush=True)
        item = wait_incident(portal, token, identifier, status, PROCESSING, 360)
        policy = item["policy_evaluation"]
        actions = item["proposed_actions"]
        if policy.get("assessment") != assessment:
            raise ValueError(f"{identifier}: unexpected assessment")
        if name == "sms" and (policy["risk_score"] != 50 or actions or not item["requires_manual_review"]
                              or set(policy["triggered_rules"]) != {"LINKED_BENEFIT_CLAIM", "URGENCY_PRESSURE"}
                              or not item["ocr_quality"]["acceptable"]):
            raise ValueError(f"{identifier}: unexpected OCR, rules, score or route")
        if name == "url" and (policy.get("assessment_reason") != "UNVERIFIED_URL" or policy["risk_score"] != 0
                              or actions or item["requires_manual_review"]):
            raise ValueError(f"{identifier}: unexpected URL assessment or route")
        if name == "sample-1" and not any(a["mode"] == "DRY_RUN" and a["type"] == "FINANCE_VERIFICATION_ALERT"
                                          for a in actions):
            raise ValueError(f"{identifier}: missing DRY_RUN proposal")
        print(json.dumps({"observed_utc": datetime.now(timezone.utc).isoformat(), "case": name,
                          "incident_id": identifier, "status": status, "policy": policy,
                          "actions": [a["type"] for a in actions],
                          "ocr_confidence": (item.get("ocr_quality") or {}).get("mean_confidence"),
                          "synthesis": (item.get("agent_synthesis") or {}).get("status")}), flush=True)
    print("GATE: ASSESSMENT_LIVE_PASS")


if __name__ == "__main__":
    main()
