"""Verify sample-1 and the admin audit, evidence and decision routes on AWS."""
import argparse
import hashlib
from pathlib import Path
import sys
from time import monotonic, sleep
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlencode, urlsplit
from urllib.request import urlopen
from uuid import uuid4

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from phase2b_smoke import check
from verify_group2_samples import find_row, login, request, wait_incident

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from samples_manifest import SAMPLES


def submit_sample_one(base, reporter):
    created = request(base, reporter, "POST", "/api/reports", expected=202, payload={
        "sample_id": "sample-1", "idempotency_key": uuid4().hex,
    })
    identifier = created["incident_id"]
    print(f"sample-1: {identifier}", flush=True)
    item = wait_incident(base, reporter, identifier, "PENDING_APPROVAL",
                         {"UPLOAD_PENDING", "NEW", "TRIAGING", "TRIAGED"}, 360)
    policy = item["policy_evaluation"]
    expected_rules = {"FINANCIAL_OR_OTP_REQUEST", "EXEC_IMPERSONATION", "URGENCY_PRESSURE"}
    if (policy["risk_score"] != 65 or policy["severity"] != "HIGH"
            or set(policy["triggered_rules"]) != expected_rules):
        raise ValueError(f"{identifier}: sample-1 phải đạt HIGH 65/100 với ba luật dự kiến, nhận {policy}.")
    action = next((entry for entry in item["proposed_actions"]
                   if entry["type"] == "FINANCE_VERIFICATION_ALERT" and entry["target"] == "FINANCE"), None)
    if action is None or action["mode"] != "DRY_RUN":
        raise ValueError(f"{identifier}: thiếu FINANCE_VERIFICATION_ALERT ở chế độ DRY_RUN.")
    print("sample-1: HIGH 65/100 FINANCE_VERIFICATION_ALERT", flush=True)
    return identifier, action


def audit_rows(base, token, identifier):
    cursor = None
    while True:
        suffix = "?" + urlencode({"next_token": cursor}) if cursor else ""
        page = request(base, token, "GET", "/api/audit-logs" + suffix)
        yield from (entry for entry in page["items"] if entry.get("incident_id") == identifier)
        cursor = page.get("next_token")
        if not cursor:
            return


def verify_raw_evidence(base, admin, identifier, bucket):
    path = f"/api/incidents/{identifier}/raw-evidence-url"
    ticket = request(base, admin, "GET", path)
    link = urlsplit(ticket["url"])
    fields = parse_qs(link.query)
    hosts = {f"{bucket}.s3.amazonaws.com", f"{bucket}.s3.us-east-1.amazonaws.com"}
    key_path = f"/evidence/{identifier}/raw"
    if (link.scheme != "https" or link.netloc not in hosts or link.path != key_path
            or ticket.get("expires_in") != 60 or fields.get("X-Amz-Expires") != ["60"]
            or not fields.get("versionId")):
        raise ValueError("Presigned GET phải trỏ tới version của đúng evidence và có thời hạn 60 giây.")
    try:
        with urlopen(ticket["url"], timeout=20) as result:
            raw = result.read(5 * 1024 * 1024 + 1)
    except (HTTPError, URLError, OSError) as exc:
        status = getattr(exc, "code", None)
        raise ValueError(f"Tải evidence qua Presigned GET thất bại ({status or type(exc).__name__}).") from None
    check(hashlib.sha256(raw).hexdigest() == SAMPLES["sample-1"]["sha256"], "ADMIN_RAW_VERSIONED_GET_60S")


def verify_decision(base, reporter, admin, auditor, identifier, action):
    path = f"/api/incidents/{identifier}/decision"
    decision_id = uuid4().hex
    payload = {"decision_id": decision_id, "action_id": action["action_id"],
               "proposal_version": action["proposal_version"], "decision": "APPROVE",
               "note": "PhishGuard sample-1 finance verification test"}
    request(base, auditor, "POST", path, expected=403, payload=payload)
    request(base, reporter, "POST", path, expected=403, payload=payload)
    print("AUDITOR_AND_REPORTER_DECISION_403: PASS", flush=True)
    request(base, admin, "POST", path, payload=payload)
    replay = request(base, admin, "POST", path, payload=payload)
    check(replay.get("retry") is True, "SAME_DECISION_RETRY_200")
    request(base, admin, "POST", path, expected=409, payload=dict(payload, decision_id=uuid4().hex, decision="REJECT"))
    print("DIFFERENT_DECISION_409: PASS", flush=True)
    wait_incident(base, reporter, identifier, "SIMULATED", {"PENDING_APPROVAL", "ACTION_REQUESTED"}, 120)

    deadline = monotonic() + 18
    while monotonic() < deadline:
        rows = list(audit_rows(base, auditor, identifier))
        approvals = [row for row in rows if row.get("action") == "APPROVE"]
        raw_reads = [row for row in rows if row.get("action") == "RAW_EVIDENCE_GET"]
        if approvals and raw_reads:
            check(len(raw_reads) == 1 and raw_reads[0].get("actor_role") == "SECOPS_ADMIN", "RAW_ACCESS_AUDITED")
            check(len(approvals) == 1 and approvals[0].get("decision_id") == decision_id
                  and approvals[0].get("new_status") == "SIMULATED"
                  and approvals[0].get("containment_mode") == "DRY_RUN", "ONE_APPROVAL_AUDIT_ROW")
            break
        sleep(2)
    else:
        raise ValueError(f"{identifier}: thiếu audit RAW_EVIDENCE_GET hoặc APPROVE.")
    entry = find_row(base, auditor, "/api/blocklist", lambda row: row.get("incident_id") == identifier)
    check(entry is None, "FINANCE_SIMULATED_WITHOUT_BLOCKLIST_ENTRY")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", default="phishguard")
    parser.add_argument("--stack-name", default="phishguard-ai")
    args = parser.parse_args()

    session = boto3.Session(profile_name=args.profile, region_name="us-east-1")
    stack = session.client("cloudformation").describe_stacks(StackName=args.stack_name)["Stacks"][0]
    outputs = {entry["OutputKey"]: entry["OutputValue"] for entry in stack["Outputs"]}
    if outputs.get("ConfiguredContainmentMode") != "DRY_RUN":
        raise ValueError("Ca duyệt mẫu sử dụng ConfiguredContainmentMode=DRY_RUN.")
    if not sys.stdin.isatty():
        raise ValueError("Mở PowerShell để script hỏi mật khẩu Cognito trực tiếp.")
    base, client_id = outputs["HttpApiEndpoint"], outputs["UserPoolClientId"]
    cognito = session.client("cognito-idp")
    reporter = login(cognito, client_id, "demo-reporter")
    admin = login(cognito, client_id, "demo-secops-admin")
    auditor = login(cognito, client_id, "demo-auditor")

    for name, token in (("SECOPS_ADMIN", admin), ("AUDITOR", auditor)):
        for path in ("/api/audit-logs", "/api/blocklist"):
            request(base, token, "GET", path)
        print(f"{name}_AUDIT_AND_BLOCKLIST_200: PASS", flush=True)
    for path in ("/api/audit-logs", "/api/blocklist"):
        request(base, reporter, "GET", path, expected=403)
    print("REPORTER_AUDIT_AND_BLOCKLIST_403: PASS", flush=True)

    identifier, action = submit_sample_one(base, reporter)
    raw_path = f"/api/incidents/{identifier}/raw-evidence-url"
    request(base, reporter, "GET", raw_path, expected=403)
    request(base, auditor, "GET", raw_path, expected=403)
    print("AUDITOR_AND_REPORTER_RAW_EVIDENCE_403: PASS", flush=True)
    verify_raw_evidence(base, admin, identifier, outputs["EvidenceBucketName"])
    verify_decision(base, reporter, admin, auditor, identifier, action)
    print("GATE: ADMIN_API_AND_SAMPLE_1_PASS", flush=True)
    return 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
    try:
        raise SystemExit(main())
    except ClientError as exc:
        print(f"ERROR: {exc.operation_name}: {exc.response['Error']['Code']}", file=sys.stderr)
        raise SystemExit(1) from None
    except (OSError, BotoCoreError, KeyError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from None
