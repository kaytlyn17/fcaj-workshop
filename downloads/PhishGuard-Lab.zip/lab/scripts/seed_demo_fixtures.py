"""Upload the three content-addressed fixtures to intake/fixtures/ only."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import boto3
from botocore.exceptions import BotoCoreError, ClientError

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from samples_manifest import SAMPLES


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", default="phishguard")
    parser.add_argument("--stack-name", default="phishguard-ai")
    args = parser.parse_args()
    session = boto3.Session(profile_name=args.profile, region_name="us-east-1")
    stack = session.client("cloudformation").describe_stacks(StackName=args.stack_name)["Stacks"][0]
    outputs = {v["OutputKey"]: v["OutputValue"] for v in stack["Outputs"]}
    for name, sample in SAMPLES.items():
        path = ROOT / "fixtures/intake" / sample["key"].rsplit("/", 1)[1]
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != sample["sha256"]:
            raise ValueError("Fixture hash mismatch; refusing to seed modified data")
        session.client("s3").put_object(Bucket=outputs["IntakeBucketName"], Key=sample["key"], Body=raw,
            ServerSideEncryption="AES256", ContentType="image/png" if sample["evidence_type"] == "IMAGE" else "message/rfc822")
        print(f"{name}: SEEDED")
    print("GATE: DEMO_FIXTURES_SEEDED")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, BotoCoreError, ClientError) as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(1)
