import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from common import public_item
from containment import valid_action
from evaluate_policy import DATA, load_cases, metrics, run_case
from extract_redact import PlainHTML, extract_document
from policy import evaluate, extract_urls
from synthesize import fallback
import triage

CONFIG = json.loads((DATA / "config.json").read_text(encoding="utf-8"))
ROWS = {r["id"]: r for r in load_cases(DATA, "development")}
SMS = ROWS["sms-original"]["text"]


class PolicyAssessmentTest(unittest.TestCase):
    def test_known_sms_and_variant_through_triage(self):
        for identifier in ("sms-original", "benefit-variant"):
            row = ROWS[identifier]
            doc = extract_document(row["text"].encode(), "TEXT")
            self.assertEqual(doc["text"], row["text"])
            event = dict(incident_id="INC-000000000001", sanitized_s3_key="test", source_channel="WEB_PORTAL",
                         approval_timeout_seconds=60, ocr_quality=doc["ocr_quality"])
            with self.subTest(identifier=identifier), patch.object(triage, "read_sanitized", return_value=doc), \
                    patch.object(triage, "active_blocklist", return_value={}) as lookup, \
                    patch.object(triage, "update_incident") as save, \
                    patch.dict("os.environ", {"CONTAINMENT_MODE": "INTERNAL_LIST"}):
                result = triage.handle(event)
                policy = result["policy_evaluation"]
                self.assertEqual(lookup.call_args.args[0], extract_urls(row["text"]))
                self.assertEqual(save.call_args.kwargs["policy_evaluation"], policy)
                self.assertEqual((policy["assessment"], policy["risk_score"], policy["severity"]),
                                 ("SUSPICIOUS", 50, "HIGH"))
                self.assertCountEqual(policy["triggered_rules"], ["LINKED_BENEFIT_CLAIM", "URGENCY_PRESSURE"])
                self.assertTrue(result["requires_manual_review"])
                self.assertEqual(result["proposed_actions"], [])

    def test_url_forms_preserve_path_query_and_deduplicate(self):
        for value in ("www.Example.org", "www[.]Example[.]org", r"www\.Example[.]org", "http://www.example.org"):
            with self.subTest(value=value):
                urls = extract_urls(value + "/Ho_So-A/(B)?h=X!Y&v=[.]a")
                self.assertEqual(urls[0]["canonical_value"], "http://www.example.org/Ho_So-A/(B)?h=X!Y&v=[.]a")
        urls = extract_urls("hxxps[:]//www.Example[.]org:443/a https://www.example.org/a.")
        self.assertEqual(len(urls), 1)
        self.assertEqual(urls[0]["canonical_value"], "https://www.example.org/a")
        self.assertEqual(extract_urls("example[.]org/help")[0]["host"], "example.org")
        self.assertEqual(extract_urls("bob@www.example.org a@www[.]example[.]org text.example.org https://bad_host:8000"), [])
        parser = PlainHTML()
        parser.feed('<a href="www[.]example.org/Ho_So">Bấm vào</a>')
        self.assertEqual(extract_urls(" ".join(parser.text))[0]["registrable_domain"], "example.org")

    def test_unknown_controls_and_scoped_warning(self):
        for identifier in ("paid-benefit", "official-reminder", "unknown-url", "quoted-sms", "quoted-otp"):
            with self.subTest(identifier=identifier):
                case = run_case(ROWS[identifier], DATA, CONFIG)
                self.assertEqual((case["prediction"], case["status"], case["policy"]["risk_score"]),
                                 ("UNKNOWN", "NO_ACTION", 0))
                self.assertEqual(case["action_types"], [])
        text = ROWS["quoted-otp"]["text"]
        self.assertTrue(evaluate(text)["deterministic_findings"]["urls"])
        result = evaluate(text + " " + SMS, blocklist=CONFIG["blocklist"])
        self.assertTrue(result["requires_manual_review"])
        self.assertEqual(result["deterministic_findings"]["blocked_domains"], [])
        self.assertEqual(evaluate(f"Cảnh báo tài khoản: “{SMS}”")["policy_evaluation"]["assessment"], "SUSPICIOUS")

    def test_allowlist_registrable_domain_and_approval_gates(self):
        for mode in ("DRY_RUN", "INTERNAL_LIST"):
            known = evaluate(SMS, mode=mode, blocklist={"vnbomo.icu": "SEED"})
            action, = known["proposed_actions"]
            self.assertEqual((action["type"], action["target"], action["mode"]), ("BLOCK_DOMAIN", "vnbomo.icu", mode))
            self.assertTrue(valid_action(known, action))
            self.assertFalse(valid_action(known, {**action, "target": "another.org"}))
        for host in ("acb.com.vn", "co.uk"):
            result = evaluate("Truy cập https://" + host, blocklist={host: "SEED"})
            self.assertEqual(result["proposed_actions"], [])
        self.assertEqual(evaluate(SMS, blocklist={"vnbomo.icu": "APPROVED_DRY_RUN"})["proposed_actions"], [])

    def test_completed_payment_and_negated_invitation(self):
        for text in ("Bạn đã nhận tiền. Bấm vào www.example.org xem sao kê trước 17 giờ.",
                     "Đừng bấm vào www.example.org để nhận trợ cấp trước 17 giờ."):
            with self.subTest(text=text):
                self.assertEqual(evaluate(text)["policy_evaluation"]["risk_score"], 0)

    def test_public_projection_and_legacy_summary(self):
        item = {"policy_evaluation": {"risk_score": 0, "severity": "LOW", "triggered_rules": []}}
        public = public_item(item)
        self.assertEqual(public["policy_evaluation"]["assessment_reason"], "LEGACY")
        self.assertEqual(public["policy_evaluation"]["assessment"], "UNKNOWN")
        self.assertNotIn("assessment", item["policy_evaluation"])
        self.assertNotIn("policy_evaluation", public_item({"status": "NEEDS_MORE_INFO"}))
        current = evaluate("Xem www.example.org")
        self.assertEqual(public_item(current)["policy_evaluation"]["assessment_reason"], "UNVERIFIED_URL")
        with patch.dict("os.environ", {"MODEL_ID": "test"}):
            self.assertIn("Chưa xác định", fallback(item, "TEST")["summary_vi"])


class EvaluationTest(unittest.TestCase):
    def test_unknowns_and_input_abstentions_are_not_hits(self):
        cases = [{"label": label, "prediction": pred, "status": status} for label, pred, status in (
            ("benign", "SUSPICIOUS", "NEEDS_REVIEW"), ("phishing", "SUSPICIOUS", "PENDING_APPROVAL"),
            ("phishing", "UNKNOWN", "NO_ACTION"), ("phishing", "NO_INPUT_DECISION", "NEEDS_MORE_INFO"),
            ("benign", "UNKNOWN", "NO_ACTION"))]
        self.assertEqual(metrics(cases), dict(total=5, true_positives=1, false_positives=1, false_negatives=2,
                         unknown=2, needs_more_info=1, needs_review=1, pending_approval=1,
                         manual_review_rate=.2, human_routing_rate=.4))

    def test_unreadable_image_and_qr_exception(self):
        row = ROWS["sms-image"]
        for links, status in [([], "NEEDS_MORE_INFO"), (["hxxps://example[.]net/"], "PENDING_APPROVAL")]:
            with patch("extract_redact.extract_image", return_value=(SMS, [], 12.0, links)):
                case = run_case(row, DATA, CONFIG)
                self.assertEqual(case["status"], status)
                if links:
                    self.assertEqual(case["policy"]["triggered_rules"], ["KNOWN_BLOCKED_IOC"])
                else:
                    self.assertNotIn("policy", case)

    def test_split_guard_rejects_reused_group_and_wrong_assignment(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            for development in (["bhtn-sms"], []):
                (folder / "partitions.json").write_text(json.dumps({"development": development, "holdout": ["bhtn-sms"]}))
                (folder / "development.jsonl").write_text(json.dumps(ROWS["sms-original"]))
                with self.assertRaises(ValueError):
                    load_cases(folder, "development")
