import json
import unittest
from unittest.mock import Mock, patch

from botocore.exceptions import ClientError
from common import ApiError
from reporter_api import SANITIZED_TEXT_LIMIT, read_incidents


class IncidentDetailTest(unittest.TestCase):
    def setUp(self):
        self.identifier = "INC-4d106209d30a"
        self.key = f"sanitized/{self.identifier}/analysis.json"
        self.item = {
            "incident_id": self.identifier,
            "reporter_id": "own-sub",
            "status": "NO_ACTION",
            "sanitized_s3_key": self.key,
            "raw_s3_key": "private/raw",
            "sfn_task_token": "private",
        }
        self.event = {"pathParameters": {"id": self.identifier}}
        self.table = Mock()
        self.table.get_item.return_value = {"Item": self.item}
        table_patch = patch("reporter_api.table", return_value=self.table)
        table_patch.start()
        self.addCleanup(table_patch.stop)

    def detail(self, actor="own-sub", groups=frozenset({"REPORTER"})):
        return read_incidents(self.event, "GET /api/incidents/{id}", actor, groups)

    def test_reads_redacted_text_for_authorized_roles(self):
        text = "Nội dung đã che [PHONE_1]."
        encoded = json.dumps({"incident_id": self.identifier, "text": text}).encode()
        with patch("common.read_s3", return_value=(encoded, {})) as read, patch.dict(
            "os.environ", {"SANITIZED_BUCKET": "sanitized-example"}
        ):
            for actor, groups in (
                ("own-sub", {"REPORTER"}),
                ("admin-sub", {"SECOPS_ADMIN"}),
                ("audit-sub", {"AUDITOR"}),
            ):
                with self.subTest(groups=groups):
                    response = self.detail(actor, groups)
                    body = json.loads(response["body"])
                    self.assertEqual(response["statusCode"], 200)
                    self.assertEqual(body["sanitized_text"], text)
                    self.assertFalse(body["sanitized_text_truncated"])
                    self.assertTrue({"sanitized_s3_key", "raw_s3_key", "sfn_task_token"}.isdisjoint(body))
            read.assert_called_with("sanitized-example", self.key)
        self.assertEqual(
            self.table.get_item.call_args.kwargs["ExpressionAttributeNames"]["#sanitized"],
            "sanitized_s3_key",
        )

    def test_foreign_reporter_is_denied_before_s3_access(self):
        with patch("reporter_api.read_sanitized") as read, self.assertRaises(ApiError) as error:
            self.detail("another-sub")
        self.assertEqual(error.exception.status, 404)
        read.assert_not_called()

    def test_returns_metadata_if_redacted_object_is_missing(self):
        missing = ClientError({"Error": {"Code": "NoSuchKey"}}, "GetObject")
        with patch("reporter_api.read_sanitized", side_effect=missing), patch("builtins.print"):
            response = self.detail()
        self.assertEqual(response["statusCode"], 200)
        self.assertNotIn("sanitized_text", json.loads(response["body"]))

    def test_bounds_the_text_and_marks_it_as_an_excerpt(self):
        with patch("reporter_api.read_sanitized", return_value={"text": "x" * (SANITIZED_TEXT_LIMIT + 1)}):
            body = json.loads(self.detail()["body"])
        self.assertEqual(len(body["sanitized_text"]), SANITIZED_TEXT_LIMIT)
        self.assertTrue(body["sanitized_text_truncated"])

    def test_list_never_loads_sanitized_objects(self):
        with patch("reporter_api.read_sanitized") as read, patch(
            "reporter_api.list_items", return_value={"items": []}
        ):
            response = read_incidents({}, "GET /api/incidents", "own-sub", {"REPORTER"})
        self.assertEqual(response["statusCode"], 200)
        read.assert_not_called()
