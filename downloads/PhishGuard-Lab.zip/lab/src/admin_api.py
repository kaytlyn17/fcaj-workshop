"""Audit reads, short-lived raw evidence access and retry-safe approval callbacks."""
import json
import os
import re
import uuid

from botocore.exceptions import ClientError
from common import (ApiError, api_wrapper, append_audit, body_json, client, dumps,
                    get_incident, identity, list_items, now, response, table)
from containment import DECISION_FIELDS, selected_action, valid_action
from extract_redact import redact

PAST_APPROVAL = {"ACTION_REQUESTED", "SIMULATED", "INTERNAL_LIST_UPDATED", "REJECTED"}
TOKEN_ERRORS = {"TaskTimedOut", "TaskDoesNotExist", "InvalidToken"}
RAW_EVIDENCE_TTL_SECONDS = 60


def validate_decision(data):
    required = set(DECISION_FIELDS) - {"actor_id"}
    if not required <= set(data) or set(data) - required - {"note"}:
        raise ApiError(400, "INVALID_DECISION_FIELDS")
    if not isinstance(data["decision_id"], str) or not re.fullmatch(r"[A-Za-z0-9_-]{8,64}", data["decision_id"]):
        raise ApiError(400, "INVALID_DECISION_ID")
    if (data["decision"] not in ("APPROVE", "REJECT") or type(data["proposal_version"]) is not int
            or data["proposal_version"] < 1 or not isinstance(data["action_id"], str) or not data["action_id"].strip()):
        raise ApiError(400, "INVALID_DECISION")
    note = data.get("note", "")
    if not isinstance(note, str) or len(note) > 500:
        raise ApiError(400, "INVALID_DECISION_NOTE")


def same_decision(stored, requested):
    return isinstance(stored, dict) and all(stored.get(field) == requested[field] for field in DECISION_FIELDS)


def callback_conflict(item):
    if item["status"] == "ESCALATED_TIMEOUT":
        raise ApiError(409, "APPROVAL_EXPIRED")
    print(json.dumps({"event": "approval_callback_conflict", "incident_id": item["incident_id"],
                      "status": item["status"]}))
    raise ApiError(409, "APPROVAL_CALLBACK_CONFLICT")


def accepted(item, record, *, retry):
    if record.get("callback_sent") is not True:
        values = {":true": True, ":id": record["decision_id"], ":actor": record["actor_id"],
                  ":expired": "ESCALATED_TIMEOUT"}
        condition = "approval_record.decision_id=:id AND approval_record.actor_id=:actor AND #s<>:expired"
        if item["status"] == "PENDING_APPROVAL":
            values.update({":pending": "PENDING_APPROVAL", ":token": item["sfn_task_token"]})
            condition += " AND (#s<>:pending OR sfn_task_token=:token)"
        try:
            table().update_item(
                Key={"incident_id": item["incident_id"]},
                UpdateExpression="SET approval_record.callback_sent=:true",
                ConditionExpression=condition,
                ExpressionAttributeNames={"#s": "status"},
                ExpressionAttributeValues=values,
            )
        except ClientError as exc:
            if exc.response["Error"]["Code"] != "ConditionalCheckFailedException":
                raise
            fresh = get_incident(item["incident_id"])
            saved = fresh.get("approval_record")
            if (fresh["status"] not in PAST_APPROVAL or not same_decision(saved, record)
                    or saved.get("callback_sent") is not True):
                callback_conflict(fresh)
            item = fresh

    result = {"incident_id": item["incident_id"], "decision_id": record["decision_id"], "accepted": True}
    if retry:
        result.update(status=item["status"], retry=True)
    return response(200, result)


def send_decision(item, record, *, retry):
    try:
        client("stepfunctions").send_task_success(
            taskToken=item["sfn_task_token"], output=dumps({field: record[field] for field in DECISION_FIELDS}),
        )
    except ClientError as exc:
        if exc.response["Error"]["Code"] not in TOKEN_ERRORS:
            raise
        fresh = get_incident(item["incident_id"])
        saved = fresh.get("approval_record")
        if fresh["status"] in PAST_APPROVAL and same_decision(saved, record):
            return accepted(fresh, saved, retry=True)
        callback_conflict(fresh)
    return accepted(item, record, retry=retry)


def decision(identifier, actor, data):
    validate_decision(data)
    requested = {field: data[field] for field in DECISION_FIELDS if field != "actor_id"}
    requested["actor_id"] = actor

    # A failed condition can mean a matching submission won the write or PrepareApproval replaced its token.
    for _ in range(3):
        item = get_incident(identifier)
        status = item["status"]
        record = item.get("approval_record")
        if status == "ESCALATED_TIMEOUT":
            raise ApiError(409, "APPROVAL_EXPIRED")
        if record is not None:
            if not same_decision(record, requested):
                raise ApiError(409, "APPROVAL_ALREADY_DECIDED")
            if status in PAST_APPROVAL or (status == "PENDING_APPROVAL" and record.get("callback_sent") is True):
                return accepted(item, record, retry=True)
        if status != "PENDING_APPROVAL":
            raise ApiError(409, "INCIDENT_NOT_PENDING_APPROVAL")

        version = requested["proposal_version"]
        action = selected_action(item, requested)
        if action is None or item.get("proposal_version", version) != version:
            raise ApiError(409, "PROPOSAL_VERSION_OR_ACTION_MISMATCH")
        if not valid_action(item, action):
            raise ApiError(409, "INVALID_PROPOSED_ACTION")
        token = item.get("sfn_task_token")
        if not isinstance(token, str) or not token:
            callback_conflict(item)
        if record is not None:
            return send_decision(item, record, retry=True)

        record = dict(requested, note=redact(data.get("note", "")), decided_at=now(), callback_sent=False)
        try:
            table().update_item(
                Key={"incident_id": identifier}, UpdateExpression="SET approval_record=:record",
                ConditionExpression=("#s=:pending AND attribute_not_exists(approval_record) AND sfn_task_token=:token "
                                     "AND (attribute_not_exists(proposal_version) OR proposal_version=:version)"),
                ExpressionAttributeNames={"#s": "status"},
                ExpressionAttributeValues={":record": record, ":pending": "PENDING_APPROVAL",
                                           ":token": token, ":version": version},
            )
        except ClientError as exc:
            if exc.response["Error"]["Code"] != "ConditionalCheckFailedException":
                raise
            continue
        return send_decision(item, record, retry=False)

    raise ApiError(409, "APPROVAL_CONFLICT_RETRY_SAME_DECISION")


def raw_evidence_url(identifier, actor):
    item = get_incident(identifier)
    key, version = item.get("raw_s3_key"), item.get("raw_s3_version_id")
    if not key or not version:
        raise ApiError(409, "EVIDENCE_NOT_READY")
    written = append_audit({
        "incident_id": identifier, "timestamp_action": now() + "#RAW_EVIDENCE_GET#" + uuid.uuid4().hex,
        "actor_id": actor, "actor_role": "SECOPS_ADMIN", "action": "RAW_EVIDENCE_GET",
        "previous_status": item["status"], "new_status": item["status"],
    })
    if not written:
        raise ApiError(503, "AUDIT_WRITE_FAILED")
    url = client("s3").generate_presigned_url(
        "get_object", Params={"Bucket": os.environ["EVIDENCE_BUCKET"], "Key": key, "VersionId": version},
        ExpiresIn=RAW_EVIDENCE_TTL_SECONDS,
    )
    return response(200, {
        "url": url,
        "expires_in": RAW_EVIDENCE_TTL_SECONDS,
        "presigned_url": url,
        "expires_in_seconds": RAW_EVIDENCE_TTL_SECONDS,
        "audit_event_recorded": True,
    })


def handle(event):
    actor, groups = identity(event)
    admin = "SECOPS_ADMIN" in groups
    privileged = admin or "AUDITOR" in groups
    route = event.get("routeKey", "")
    identifier = (event.get("pathParameters") or {}).get("id")
    if route in {"GET /api/audit-logs", "GET /api/blocklist"}:
        if not privileged:
            raise ApiError(403, "SECOPS_OR_AUDITOR_REQUIRED")
        return response(200, list_items(table("AUDIT_TABLE" if "audit-logs" in route else "BLOCKLIST_TABLE"),
                                        cursor=(event.get("queryStringParameters") or {}).get("next_token")))
    if not admin:
        raise ApiError(403, "SECOPS_ADMIN_REQUIRED")
    if route == "GET /api/incidents/{id}/raw-evidence-url":
        return raw_evidence_url(identifier, actor)
    if route == "POST /api/incidents/{id}/decision":
        return decision(identifier, actor, body_json(event))
    raise ApiError(404, "ROUTE_NOT_FOUND")


def lambda_handler(event, context):
    return api_wrapper(handle, event)
