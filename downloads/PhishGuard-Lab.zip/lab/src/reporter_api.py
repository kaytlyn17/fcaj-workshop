"""JWT-bound intake sessions, presigned POST and content-bound idempotency."""
import hashlib
import os
import re
import time
import uuid

from boto3.dynamodb.conditions import Key
from boto3.dynamodb.types import TypeSerializer
from botocore.exceptions import BotoCoreError, ClientError
from common import (ApiError, MAX_BYTES, PUBLIC_NAMES, PUBLIC_PROJECTION, api_wrapper,
                    body_json, client, dumps, identity, list_items, now, public_item, read_s3,
                    read_sanitized, response, table)
from policy import incident_id
from samples_manifest import SAMPLES

TYPES = {"image/png": "IMAGE", "image/jpeg": "IMAGE", "message/rfc822": "EML", "text/plain": "TEXT"}
SERIALIZER = TypeSerializer()
SANITIZED_TEXT_LIMIT = 32000


def reserve_report(item, alternative_id):
    table_name = os.environ["INCIDENTS_TABLE"]
    absent = "attribute_not_exists(incident_id)"
    # Neither report type may claim a key already used by the other type.
    writes = [
        {"ConditionCheck": {"TableName": table_name, "Key": {"incident_id": {"S": alternative_id}},
                            "ConditionExpression": absent}},
        {"Put": {"TableName": table_name, "Item": {
            name: SERIALIZER.serialize(value) for name, value in item.items()
        }, "ConditionExpression": absent}},
    ]
    for attempt in range(3):
        try:
            client("dynamodb").transact_write_items(TransactItems=writes)
            return item
        except ClientError as exc:
            if exc.response["Error"]["Code"] not in {"TransactionCanceledException", "TransactionConflictException"}:
                raise
            retryable_reasons = {"None", "ConditionalCheckFailed", "TransactionConflict",
                                 "ProvisionedThroughputExceeded", "ThrottlingError"}
            if any(reason.get("Code") not in retryable_reasons for reason in exc.response.get("CancellationReasons", [])):
                raise
            existing = table().get_item(Key={"incident_id": item["incident_id"]}, ConsistentRead=True).get("Item")
            other = table().get_item(Key={"incident_id": alternative_id}, ConsistentRead=True).get("Item")
            if existing and all(existing.get(key) == item[key] for key in (
                    "source_intake_key", "reporter_id", "content_sha256", "evidence_type")):
                return existing
            if existing or other:
                raise ApiError(409, "IDEMPOTENCY_KEY_REUSED") from None
            if attempt == 2:
                raise ApiError(503, "RETRY_SAME_IDEMPOTENCY_KEY") from None
            time.sleep(0.025 * (2 ** attempt))


def read_incidents(event, route, actor, groups):
    privileged = bool(groups & {"SECOPS_ADMIN", "AUDITOR"})
    if route == "GET /api/incidents":
        params = event.get("queryStringParameters") or {}
        query = None
        if not privileged:
            query = {"IndexName": "ReporterIndex", "KeyConditionExpression": Key("reporter_id").eq(actor),
                     "ScanIndexForward": False}
        elif params.get("status"):
            query = {"IndexName": "StatusIndex", "KeyConditionExpression": Key("status").eq(params["status"]),
                     "ScanIndexForward": False}
        return response(200, list_items(table(), query, public=True, cursor=params.get("next_token")))
    identifier = (event.get("pathParameters") or {}).get("id")
    if not isinstance(identifier, str) or not re.fullmatch(r"INC-[0-9a-f]{12}", identifier):
        raise ApiError(400, "INVALID_INCIDENT_ID")
    item = table().get_item(
        Key={"incident_id": identifier},
        ConsistentRead=True,
        ProjectionExpression=PUBLIC_PROJECTION + ", #sanitized",
        ExpressionAttributeNames={**PUBLIC_NAMES, "#sanitized": "sanitized_s3_key"},
    ).get("Item")
    if not item or (not privileged and item.get("reporter_id") != actor):
        raise ApiError(404, "INCIDENT_NOT_FOUND")
    result = public_item(item)
    if item.get("sanitized_s3_key"):
        try:
            text = read_sanitized(item)["text"]
        except (BotoCoreError, ClientError, ValueError) as exc:
            error_code = exc.response["Error"]["Code"] if isinstance(exc, ClientError) else type(exc).__name__
            print(dumps({"event": "SANITIZED_TEXT_UNAVAILABLE", "incident_id": identifier,
                         "error_code": error_code}))
        else:
            result["sanitized_text"] = text[:SANITIZED_TEXT_LIMIT]
            result["sanitized_text_truncated"] = len(text) > SANITIZED_TEXT_LIMIT
    return response(200, result)


def handle(event):
    actor, groups = identity(event)
    route = event.get("routeKey")
    if route in {"GET /api/incidents", "GET /api/incidents/{id}"}:
        return read_incidents(event, route, actor, groups)
    if not groups & {"REPORTER", "SECOPS_ADMIN"}:
        raise ApiError(403, "REPORTING_NOT_ALLOWED")
    data = body_json(event)
    if route == "POST /api/uploads/presign":
        content_type = data.get("content_type")
        size = data.get("size")
        filename = data.get("filename")
        if not isinstance(content_type, str) or content_type not in TYPES or type(size) is not int or not 1 <= size <= MAX_BYTES:
            raise ApiError(400, "INVALID_UPLOAD_SIZE_OR_TYPE")
        if not isinstance(filename, str) or not 1 <= len(filename) <= 200:
            raise ApiError(400, "INVALID_FILENAME")
        upload_id = str(uuid.uuid4())
        source = "WEB#" + upload_id
        identifier = incident_id(source)
        key = f"uploads/{upload_id}/raw"
        item = {"incident_id": identifier, "source_intake_key": source, "upload_id": upload_id,
                "reporter_id": actor, "reporter_identity_status": "VERIFIED_JWT", "status": "UPLOAD_PENDING",
                "reporter_auth": {"source": "JWT"},
                "source_channel": "WEB_PORTAL", "evidence_type": TYPES[content_type], "created_at": now(),
                "intake_s3_key": key, "expected_size": size, "expected_content_type": content_type,
                "content_sha256": "", "ttl": int(time.time()) + 86400}
        table().put_item(Item=item, ConditionExpression="attribute_not_exists(incident_id)")
        post = client("s3").generate_presigned_post(Bucket=os.environ["INTAKE_BUCKET"], Key=key,
            Fields={"Content-Type": content_type, "x-amz-meta-incident-id": identifier},
            Conditions=[["content-length-range", 1, MAX_BYTES], {"Content-Type": content_type},
                        {"x-amz-meta-incident-id": identifier}], ExpiresIn=300)
        return response(201, {"incident_id": identifier, "upload_id": upload_id, "presigned_post": post,
                              "expires_in": 300})
    if route != "POST /api/reports":
        raise ApiError(404, "ROUTE_NOT_FOUND")
    idem = data.get("idempotency_key", "")
    if not isinstance(idem, str) or not re.fullmatch(r"[A-Za-z0-9_-]{8,64}", idem):
        raise ApiError(400, "INVALID_IDEMPOTENCY_KEY")
    sample_id = data.get("sample_id")
    bucket = os.environ["INTAKE_BUCKET"]
    if sample_id is not None:
        if "text" in data or not isinstance(sample_id, str) or sample_id not in SAMPLES:
            raise ApiError(400, "INVALID_SAMPLE")
        sample = SAMPLES[sample_id]
        digest, evidence_type = sample["sha256"], sample["evidence_type"]
        content_type = "image/png" if evidence_type == "IMAGE" else "message/rfc822"
        source = f"SAMPLE#{actor}#{idem}"
        alternative = f"TEXT#{actor}#{idem}"
    else:
        text = data.get("text")
        if not isinstance(text, str) or not text.strip():
            raise ApiError(400, "TEXT_REQUIRED")
        raw = text.encode("utf-8")
        digest, evidence_type = hashlib.sha256(raw).hexdigest(), "TEXT"
        content_type = "text/plain; charset=utf-8"
        source = f"TEXT#{actor}#{idem}"
        alternative = f"SAMPLE#{actor}#{idem}"
        if len(raw) > MAX_BYTES:
            raise ApiError(413, "REPORT_TOO_LARGE")
    identifier = incident_id(source)
    key = f"uploads/{uuid.uuid4()}/raw"
    item = {"incident_id": identifier, "source_intake_key": source, "reporter_id": actor,
            "reporter_identity_status": "VERIFIED_JWT", "source_channel": "WEB_PORTAL",
            "reporter_auth": {"source": "JWT"},
            "evidence_type": evidence_type, "status": "UPLOAD_PENDING", "created_at": now(),
            "content_sha256": digest, "intake_s3_key": key, "ttl": int(time.time()) + 86400}
    if sample_id is not None:
        item["sample_id"] = sample_id
    existing = reserve_report(item, incident_id(alternative))
    if existing.get("status") != "UPLOAD_PENDING":
        return response(202, {"incident_id": identifier, "status": existing["status"]})
    if int(existing["ttl"]) <= int(time.time()):
        raise ApiError(409, "UPLOAD_SESSION_EXPIRED")
    if sample_id is not None:
        raw, _ = read_s3(bucket, sample["key"])
        if hashlib.sha256(raw).hexdigest() != digest:
            raise ApiError(503, "FIXTURE_HASH_MISMATCH")
    try:
        client("s3").put_object(Bucket=bucket, Key=existing["intake_s3_key"], Body=raw,
            ContentType=content_type, IfNoneMatch="*", Metadata={"incident-id": identifier})
    except ClientError as exc:
        if exc.response["Error"]["Code"] not in {"PreconditionFailed", "412"}:
            raise
    return response(202, {"incident_id": identifier, "status": "UPLOAD_PENDING"})


def lambda_handler(event, context):
    return api_wrapper(handle, event)
