"""Store the active Step Functions callback token before notifying SecOps."""
from datetime import datetime, timedelta, timezone
import json
import os

from common import client, get_incident, task_wrapper, update_incident


def handle(event):
    token = event["task_token"]
    timeout = event["approval_timeout_seconds"]
    if not isinstance(token, str) or not 1 <= len(token) <= 2048:
        raise ValueError("INVALID_APPROVAL_TOKEN")
    if type(timeout) is not int or not 1 <= timeout <= 31536000:
        raise ValueError("INVALID_APPROVAL_TIMEOUT")

    item = get_incident(event["incident_id"])
    actions = item.get("proposed_actions", [])
    if not actions:
        raise ValueError("NO_VALID_PROPOSED_ACTION")
    versions = {action["proposal_version"] for action in actions}
    if len(versions) != 1:
        raise ValueError("INCONSISTENT_PROPOSAL_VERSION")
    version = versions.pop()
    if int(version) != version or version < 1:
        raise ValueError("INVALID_PROPOSAL_VERSION")

    expires = (datetime.now(timezone.utc) + timedelta(seconds=timeout)).isoformat(timespec="milliseconds")
    if item.get("sfn_task_token") == token:
        expires = item.get("approval_expires_at", expires)
    # A Step Functions retry can provide a new token for this same proposal.
    update_incident(
        item["incident_id"],
        sfn_task_token=token,
        status="PENDING_APPROVAL",
        proposal_version=int(version),
        approval_expires_at=expires,
    )

    policy = item["policy_evaluation"]
    message = {
        "incident_id": item["incident_id"],
        "severity": policy["severity"],
        "risk_score": int(policy["risk_score"]),
        "source_channel": item["source_channel"],
        "dashboard_url": os.environ.get("DASHBOARD_URL", ""),
    }
    client("sns").publish(
        TopicArn=os.environ["SECOPS_TOPIC_ARN"],
        Subject="PhishGuard: approval required",
        Message=json.dumps(message, ensure_ascii=False),
    )
    return {"stored": True}


def lambda_handler(event, context):
    return task_wrapper(handle, event)
