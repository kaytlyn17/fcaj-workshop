"""Score sanitized evidence against the deterministic policy and internal Blocklist."""
import os
import time

from common import client, dumps, read_sanitized, task_wrapper, update_incident
from policy import evaluate, extract_urls

ACTIVE_SOURCES = {"SEED", "APPROVED_CONFIRMED"}
HEADER_ANOMALIES = {"HEADER_REPLY_TO_MISMATCH", "HEADER_ENVELOPE_FROM_MISMATCH"}
WORKFLOW_LIMIT = 128 * 1024


def active_blocklist(urls):
    # A DynamoDB partition key cannot exceed 2048 UTF-8 bytes. Keep looking up
    # the host and registrable domain even when the full URL exceeds that limit.
    values = sorted({url[field] for url in urls
                     for field in ("canonical_value", "host", "registrable_domain")
                     if url[field] and len(url[field].encode("utf-8")) <= 2048})
    matches = {}
    table_name = os.environ["BLOCKLIST_TABLE"]
    for offset in range(0, len(values), 100):
        request = {table_name: {
            "Keys": [{"ioc_value": {"S": value}} for value in values[offset:offset + 100]],
            "ConsistentRead": True,
            "ProjectionExpression": "ioc_value, #source",
            "ExpressionAttributeNames": {"#source": "source"},
        }}
        for attempt in range(4):
            result = client("dynamodb").batch_get_item(RequestItems=request)
            for item in result.get("Responses", {}).get(table_name, []):
                source = item.get("source", {}).get("S")
                if source in ACTIVE_SOURCES:
                    matches[item["ioc_value"]["S"]] = source
            request = result.get("UnprocessedKeys", {})
            if not request:
                break
            if attempt == 3:
                # Let Step Functions retry instead of scoring with partial data.
                raise ValueError("BLOCKLIST_READ_INCOMPLETE")
            time.sleep(0.05 * (2 ** attempt))
    return matches


def score_document(document, *, urls, blocklist, mode):
    headers = sorted(set(document.get("header_findings", [])) & HEADER_ANOMALIES)
    result = evaluate(
        document["text"],
        header_anomaly=bool(headers),
        blocklist=blocklist,
        mode=mode,
        urls=urls,
    )
    result["deterministic_findings"]["header_findings"] = headers
    if document.get("email_auth", {}).get("source") == "EMBEDDED_UNVERIFIED":
        result["security_flags"].append("AUTH_INDETERMINATE")
    return result


def handle(event):
    document = read_sanitized(event)
    urls = extract_urls(document["text"])
    if len(dumps(urls).encode("utf-8")) > WORKFLOW_LIMIT:
        raise ValueError("ANALYSIS_EXCEEDS_SAFE_WORKFLOW_PAYLOAD")
    result = score_document(document, urls=urls, blocklist=active_blocklist(urls),
                            mode=os.environ["CONTAINMENT_MODE"])
    output = {key: event[key] for key in (
        "incident_id", "sanitized_s3_key", "source_channel", "approval_timeout_seconds", "ocr_quality"
    )}
    output.update(result)
    if len(dumps(output).encode("utf-8")) > WORKFLOW_LIMIT:
        raise ValueError("ANALYSIS_EXCEEDS_SAFE_WORKFLOW_PAYLOAD")
    update_incident(event["incident_id"], status="TRIAGED", **result)
    return output


def lambda_handler(event, context):
    return task_wrapper(handle, event)
