"""Read Vietnamese and English screenshots using the ExtractRedact layer."""
from io import BytesIO
import os


OCR_ENGINE = "Tesseract (vie+eng)"
MAX_OCR_PIXELS = 24_000_000


def qr_urls(gray):
    """Return defanged web indicators without following links or retaining QR secrets."""
    from urllib.parse import urlunsplit
    import zxingcpp
    from policy import WEB_URL, extract_urls, split_web_url

    # Bound native decoder work separately from the full-resolution OCR pass.
    with gray.copy() as scan:
        scan.thumbnail((2400, 2400))
        codes = zxingcpp.read_barcodes(scan, formats=zxingcpp.BarcodeFormat.QRCode)
    urls = []
    for code in codes:
        try:
            value = code.bytes.decode("utf-8").strip()
            if len(value) > 2048 or any(c.isspace() or ord(c) < 32 for c in value):
                continue
            if not WEB_URL.fullmatch(value):
                continue
            parsed = split_web_url(value)
            if parsed.scheme.lower() not in {"https", "http"} or not parsed.hostname or parsed.username is not None:
                continue
            clean = urlunsplit((parsed.scheme, parsed.netloc, parsed.path or "/", "", ""))
            matches = extract_urls(clean)
            if len(matches) == 1 and matches[0]["display_value"] not in urls:
                urls.append(matches[0]["display_value"])
        except (UnicodeError, ValueError):
            continue
        if len(urls) == 8:
            break
    return urls


def extract_text(image):
    """Keep the original three-value OCR interface for existing callers."""
    return extract_image(image)[:3]


def extract_image(image):
    """Return OCR text, normalized line boxes, and mean word confidence."""
    # Synthesize also imports the redactor, but only ExtractRedact has this layer.
    from PIL import Image, ImageOps
    from tesserocr import OEM, PSM, PyTessBaseAPI, RIL, iterate_level

    try:
        with Image.open(BytesIO(image), formats=("PNG", "JPEG")) as source:
            # Bound the decoded image to fit ExtractRedact's memory budget.
            if source.width * source.height > MAX_OCR_PIXELS:
                return "", [], 0.0, []
            ImageOps.exif_transpose(source, in_place=True)
            if "A" in source.getbands() or "transparency" in source.info:
                with source.convert("RGBA") as rgba:
                    gray = Image.new("L", rgba.size, 255)
                    gray.paste(rgba.convert("L"), mask=rgba.getchannel("A"))
            else:
                gray = source.convert("L")
            with gray:
                urls = qr_urls(gray)
                width, height = gray.size
                pixels = gray.tobytes()
    except (OSError, Image.DecompressionBombError):
        return "", [], 0.0, []

    with PyTessBaseAPI(
        path=os.environ.get("OCR_TESSDATA_PATH", "/opt/tessdata"),
        lang="vie+eng",
        psm=PSM.AUTO,
        oem=OEM.LSTM_ONLY,
    ) as api:
        api.SetImageBytes(pixels, width, height, 1, width)
        api.Recognize()
        text = api.GetUTF8Text().strip()
        words = api.AllWordConfidences()
        if not text or not words:
            return "", [], 0.0, urls
        positions = []
        iterator = api.GetIterator()
        if iterator:
            for number, line in enumerate(iterate_level(iterator, RIL.TEXTLINE), 1):
                bounds = line.BoundingBox(RIL.TEXTLINE)
                if bounds:
                    left, top, right, bottom = bounds
                    positions.append({
                        "line": number,
                        "page": 1,
                        "confidence": line.Confidence(RIL.TEXTLINE),
                        "bounding_box": {
                            "Left": left / width,
                            "Top": top / height,
                            "Width": (right - left) / width,
                            "Height": (bottom - top) / height,
                        },
                    })
    return text, positions, sum(words) / len(words), urls
