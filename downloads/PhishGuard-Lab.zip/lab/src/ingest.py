"""Intake-only reader and conditional evidence writer; no raw evidence reads."""
import base64
from email import policy as email_policy
from email.parser import BytesParser
from email.utils import getaddresses
import hashlib
import json
import os
import re
import time
from urllib.parse import unquote_plus

from botocore.exceptions import ClientError
from common import (MAX_BYTES, client, get_incident, now, read_s3, table, task_wrapper)
from policy import canonical_host, incident_id
from samples_manifest import SAMPLES


def validate_bytes(raw, kind, expected_type=None):
    if not 0 < len(raw) <= MAX_BYTES:
        raise ValueError("INVALID_SIZE")
    if kind == "IMAGE":
        actual_type = None
        if raw.startswith(b"\x89PNG\r\n\x1a\n"):
            actual_type = "image/png"
        elif raw.startswith(b"\xff\xd8\xff"):
            actual_type = "image/jpeg"
        if not actual_type or (expected_type and actual_type != expected_type):
            raise ValueError("INVALID_IMAGE_MAGIC")
    elif kind == "EML":
        message = BytesParser(policy=email_policy.default).parsebytes(raw)
        if not message.get("From") or not (message.get("Subject") or message.get("MIME-Version")):
            raise ValueError("INVALID_EML_HEADERS")
    elif kind == "TEXT":
        if b"\x00" in raw or not raw.decode("utf-8-sig").strip():
            raise ValueError("INVALID_TEXT")
    else:
        raise ValueError("UNSUPPORTED_EVIDENCE")


def reject_sender():
    print(json.dumps({"event": "UNVERIFIED_SENDER", "rejected": True, "UnverifiedSender": 1,
        "_aws": {"Timestamp": int(time.time() * 1000), "CloudWatchMetrics": [{"Namespace": "PhishGuard",
            "Dimensions": [[]], "Metrics": [{"Name": "UnverifiedSender", "Unit": "Count"}]}]}}))
    return None


def sender_address(headers):
    addresses = getaddresses(headers)
    if len(addresses) != 1:
        return ""
    address = addresses[0][1]
    if not re.fullmatch(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[^\s@]+", address):
        return ""
    local, domain = address.rsplit("@", 1)
    try:
        return f"{local.lower()}@{canonical_host(domain)}"
    except (UnicodeError, ValueError):
        return ""


def cognito_reporter(address):
    match = None
    for page in client("cognito-idp").get_paginator("list_users").paginate(
            UserPoolId=os.environ["USER_POOL_ID"], Filter=f'email = "{address}"'):
        for user in page.get("Users", []):
            attrs = {entry["Name"]: entry["Value"] for entry in user.get("Attributes", [])}
            if attrs.get("email", "").lower() != address:
                continue
            if match is not None:
                return None
            match = (user, attrs)
    if match is None:
        return None
    user, attrs = match
    if user.get("Enabled") and user.get("UserStatus") == "CONFIRMED" and attrs.get("email_verified") == "true":
        return attrs.get("sub")
    return None


def ses_item(record):
    ses = record["ses"]
    receipt = ses["receipt"]
    if receipt.get("dmarcVerdict", {}).get("status") != "PASS":
        return reject_sender()
    message_id = ses["mail"]["messageId"]
    if not re.fullmatch(r"[A-Za-z0-9-]{1,255}", message_id):
        raise ValueError("INVALID_SES_MESSAGE_ID")
    key = "inbound/" + message_id
    for attempt in range(3):
        try:
            raw, _ = read_s3(os.environ["INTAKE_BUCKET"], key)
            break
        except ClientError as exc:
            if exc.response["Error"]["Code"] not in {"NoSuchKey", "404"} or attempt == 2:
                raise
            time.sleep(0.2 * (2 ** attempt))
    message = BytesParser(policy=email_policy.default).parsebytes(raw, headersonly=True)
    email = sender_address(message.get_all("From", []))
    domains = {v.strip().lower() for v in os.environ.get("ALLOWED_SENDER_DOMAINS", "").split(",") if v.strip()}
    event_from = ses["mail"].get("commonHeaders", {}).get("from")
    if not email or email.rsplit("@", 1)[1] not in domains or (event_from is not None and sender_address(event_from) != email):
        return reject_sender()
    reporter = cognito_reporter(email)
    if not reporter:
        return reject_sender()
    validate_bytes(raw, "EML")
    source = "SES#" + message_id
    item = {"incident_id": incident_id(source), "source_intake_key": source,
            "source_channel": "SES_EMAIL", "evidence_type": "EML", "reporter_id": reporter,
            "reporter_identity_status": "VERIFIED_SES_DMARC", "created_at": now(), "status": "UPLOAD_PENDING",
            "intake_s3_key": key, "content_sha256": hashlib.sha256(raw).hexdigest(), "ttl": int(time.time()) + 86400,
            "reporter_auth": {"source": "SES_RECEIPT", "spf": receipt.get("spfVerdict", {}).get("status"),
                "dkim": receipt.get("dkimVerdict", {}).get("status"), "dmarc": "PASS"}}
    try:
        table().put_item(Item=item, ConditionExpression="attribute_not_exists(incident_id)")
    except ClientError as exc:
        if exc.response["Error"]["Code"] != "ConditionalCheckFailedException":
            raise
        existing = get_incident(item["incident_id"])
        if any(existing.get(field) != item[field] for field in ("source_intake_key", "reporter_id", "content_sha256")):
            raise ValueError("SES_RETRY_IDENTITY_OR_HASH_MISMATCH") from None
        item = existing
    return item, raw


def s3_item(record):
    bucket = record["s3"]["bucket"]["name"]
    obj = record["s3"]["object"]
    key = unquote_plus(obj["key"])
    if bucket != os.environ["INTAKE_BUCKET"] or not key.startswith("uploads/"):
        raise ValueError("UNEXPECTED_INTAKE_LOCATION")
    if not re.fullmatch(r"uploads/(?:[0-9a-f-]{36}|INC-[0-9a-f]{12})/raw", key):
        raise ValueError("UNEXPECTED_INTAKE_KEY")
    etag = obj.get("eTag")
    if etag and not etag.startswith('"'):
        etag = '"' + etag + '"'
    version = obj.get("versionId")
    try:
        raw, result = read_s3(bucket, key, None if version == "null" else version, etag)
    except ClientError as exc:
        if etag and exc.response["Error"]["Code"] in {"PreconditionFailed", "412"}:
            return None  # A newer upload has its own S3 event.
        raise
    identifier = result.get("Metadata", {}).get("incident-id")
    if not identifier:
        # Presigned uploads derive incident ID from the backend-issued UUID in their key.
        upload_id = key.split("/")[1]
        identifier = upload_id if upload_id.startswith("INC-") else incident_id("WEB#" + upload_id)
    item = get_incident(identifier)
    if item.get("intake_s3_key") != key or item.get("reporter_identity_status") != "VERIFIED_JWT":
        raise ValueError("UPLOAD_SESSION_MISMATCH")
    if item.get("status") == "UPLOAD_PENDING" and int(item.get("ttl", 0)) < int(time.time()):
        raise ValueError("UPLOAD_SESSION_EXPIRED")
    if (item.get("sample_id") and key == f"uploads/{identifier}/raw"
            and result.get("ContentType") == "application/json"):
        # Older 2B clients stored a small manifest pointer under the incident ID.
        if json.loads(raw) != {"sample_id": item["sample_id"]}:
            raise ValueError("LEGACY_SAMPLE_POINTER_MISMATCH")
        sample = SAMPLES[item["sample_id"]]
        raw, _ = read_s3(bucket, sample["key"])
    elif "expected_size" in item:
        if len(raw) != int(item["expected_size"]) or result.get("ContentType") != item["expected_content_type"]:
            raise ValueError("UPLOAD_SIZE_OR_TYPE_MISMATCH")
    return item, raw


def ingest_one(record):
    pair = ses_item(record) if "ses" in record else s3_item(record)
    if pair is None:
        return
    item, raw = pair
    validate_bytes(raw, item["evidence_type"], item.get("expected_content_type"))
    digest = hashlib.sha256(raw).hexdigest()
    if item.get("content_sha256") and item["content_sha256"] != digest:
        raise ValueError("CONTENT_HASH_MISMATCH")
    identifier = item["incident_id"]
    # Reserve the content hash before S3 so concurrent upload notifications cannot
    # associate a losing payload's hash with the first locked evidence version.
    try:
        item = table().update_item(Key={"incident_id": identifier},
            UpdateExpression="SET content_sha256=:hash",
            ConditionExpression="attribute_exists(incident_id) AND (attribute_not_exists(content_sha256) OR content_sha256=:empty OR content_sha256=:hash)",
            ExpressionAttributeValues={":hash": digest, ":empty": ""}, ReturnValues="ALL_NEW")["Attributes"]
    except ClientError as exc:
        if exc.response["Error"]["Code"] == "ConditionalCheckFailedException":
            raise ValueError("CONCURRENT_CONTENT_HASH_MISMATCH") from None
        raise
    if item.get("sfn_execution_arn"):
        return
    if item["status"] == "UPLOAD_PENDING":
        item = save_evidence(item, raw, digest)
    payload = {"incident_id": identifier, "raw_s3_key": item["raw_s3_key"],
               "raw_s3_version_id": item.get("raw_s3_version_id", ""), "evidence_sha256": digest,
               "source_channel": item["source_channel"], "evidence_type": item["evidence_type"],
               "approval_timeout_seconds": int(os.environ["APPROVAL_TIMEOUT_SECONDS"])}
    workflow = os.environ["WORKFLOW_ARN"]
    try:
        result = client("stepfunctions").start_execution(stateMachineArn=workflow,
            name=identifier, input=json.dumps(payload, sort_keys=True))
        execution_arn = result["executionArn"]
    except ClientError as exc:
        if exc.response["Error"]["Code"] != "ExecutionAlreadyExists":
            raise
        execution_arn = workflow.replace(":stateMachine:", ":execution:", 1) + ":" + identifier
    table().update_item(Key={"incident_id": identifier}, UpdateExpression="SET sfn_execution_arn=:arn",
        ConditionExpression="attribute_exists(incident_id)", ExpressionAttributeValues={":arn": execution_arn})


def save_evidence(item, raw, digest):
    identifier = item["incident_id"]
    key = f"evidence/{identifier}/raw"
    version = ""
    for attempt in range(3):
        try:
            result = client("s3").put_object(Bucket=os.environ["EVIDENCE_BUCKET"], Key=key, Body=raw,
                IfNoneMatch="*", ServerSideEncryption="aws:kms", SSEKMSKeyId=os.environ["DATA_KEY_ARN"],
                ChecksumAlgorithm="SHA256", ChecksumSHA256=base64.b64encode(bytes.fromhex(digest)).decode(),
                Metadata={"sha256": digest}, ContentType="application/octet-stream")
            version = result["VersionId"]
            break
        except ClientError as exc:
            code = exc.response["Error"]["Code"]
            if code in {"PreconditionFailed", "412"}:
                break  # Extract reconciles the version after a successful PUT followed by a crash.
            if code not in {"ConditionalRequestConflict", "409"} or attempt == 2:
                raise
            time.sleep(0.05 * (2 ** attempt))
    try:
        return table().update_item(Key={"incident_id": identifier},
            UpdateExpression="SET #s=:new, raw_s3_key=:key, raw_s3_version_id=:ver, sha256=:hash, ingested_at=:at REMOVE #ttl",
            ConditionExpression="#s=:pending AND content_sha256=:hash",
            ExpressionAttributeNames={"#s": "status", "#ttl": "ttl"},
            ExpressionAttributeValues={":new": "NEW", ":pending": "UPLOAD_PENDING", ":key": key,
                ":ver": version, ":hash": digest, ":at": now()}, ReturnValues="ALL_NEW")["Attributes"]
    except ClientError as exc:
        if exc.response["Error"]["Code"] != "ConditionalCheckFailedException":
            raise
        return get_incident(identifier)


def handle(event):
    if event.get("Event") == "s3:TestEvent":
        return {"processed_records": 0}
    records = event.get("Records", [])
    if not records:
        raise ValueError("AWS_EVENT_RECORDS_REQUIRED")
    for record in records:
        if record.get("eventSource") not in {"aws:s3", "aws:ses"}:
            raise ValueError("UNSUPPORTED_EVENT_SOURCE")
        ingest_one(record)
    return {"processed_records": len(records)}


def lambda_handler(event, context):
    return task_wrapper(handle, event)
