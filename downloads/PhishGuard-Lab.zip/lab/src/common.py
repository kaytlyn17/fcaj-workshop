"""Shared AWS adapters; raw evidence and callback tokens are never logged."""
import base64
from datetime import datetime, timezone
from decimal import Decimal
from functools import lru_cache
import json
import os
import re
import uuid

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

MAX_BYTES = 5 * 1024 * 1024
PUBLIC_FIELDS = (
    "incident_id", "created_at", "updated_at", "source_channel", "evidence_type",
    "reporter_id", "reporter_identity_status", "status", "email_auth", "ocr_quality",
    "deterministic_findings", "security_flags", "policy_evaluation", "proposed_actions",
    "requires_manual_review", "agent_synthesis", "approval_record", "approval_expires_at",
)
PUBLIC_NAMES = {f"#p{i}": field for i, field in enumerate(PUBLIC_FIELDS)}
PUBLIC_PROJECTION = ", ".join(PUBLIC_NAMES)


class PipelineError(Exception):
    pass


class TextractTransient(Exception):
    pass


class BedrockThrottled(Exception):
    pass


class ApiError(Exception):
    def __init__(self, status, code):
        self.status, self.code = status, code


def now():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def dumps(value):
    return json.dumps(value, ensure_ascii=False, default=lambda v: int(v) if v == int(v) else float(v))


def decimals(value):
    if isinstance(value, float):
        return Decimal(str(value))
    if isinstance(value, dict):
        return {k: decimals(v) for k, v in value.items()}
    if isinstance(value, list):
        return [decimals(v) for v in value]
    return value


@lru_cache(maxsize=None)
def client(service):
    return boto3.client(service, config=Config(signature_version="s3v4" if service == "s3" else None,
        connect_timeout=5, read_timeout=60, retries={"mode": "standard", "total_max_attempts": 3}))


def table(env="INCIDENTS_TABLE"):
    return boto3.resource("dynamodb").Table(os.environ[env])


def get_incident(identifier):
    if not re.fullmatch(r"INC-[0-9a-f]{12}", str(identifier)):
        raise ApiError(400, "INVALID_INCIDENT_ID")
    item = table().get_item(Key={"incident_id": identifier}, ConsistentRead=True).get("Item")
    if not item:
        raise ApiError(404, "INCIDENT_NOT_FOUND")
    return item


def update_incident(identifier, **attributes):
    attributes["updated_at"] = now()
    names = {f"#k{i}": key for i, key in enumerate(attributes)}
    values = {f":v{i}": decimals(value) for i, value in enumerate(attributes.values())}
    table().update_item(Key={"incident_id": identifier},
        UpdateExpression="SET " + ", ".join(f"#k{i}=:v{i}" for i in range(len(attributes))),
        ExpressionAttributeNames=names, ExpressionAttributeValues=values,
        ConditionExpression="attribute_exists(incident_id)")


def append_audit(item):
    try:
        table("AUDIT_TABLE").put_item(Item=decimals(item), ReturnValues="NONE",
            ConditionExpression="attribute_not_exists(incident_id) AND attribute_not_exists(timestamp_action)")
        return True
    except ClientError as exc:
        if exc.response["Error"]["Code"] == "ConditionalCheckFailedException":
            return False
        raise


def read_s3(bucket, key, version=None, etag=None):
    args = {"Bucket": bucket, "Key": key}
    if version:
        args["VersionId"] = version
    if etag:
        args["IfMatch"] = etag
    result = client("s3").get_object(**args)
    try:
        data = result["Body"].read(MAX_BYTES + 1)
    finally:
        result["Body"].close()
    if not 0 < len(data) <= MAX_BYTES:
        raise ValueError("INVALID_EVIDENCE_SIZE")
    return data, result


def read_sanitized(event):
    identifier = event["incident_id"]
    key = event["sanitized_s3_key"]
    if not re.fullmatch(r"INC-[0-9a-f]{12}", identifier) or key != f"sanitized/{identifier}/analysis.json":
        raise ValueError("INVALID_SANITIZED_REFERENCE")
    body, _ = read_s3(os.environ["SANITIZED_BUCKET"], key)
    document = json.loads(body)
    if not isinstance(document, dict) or document.get("incident_id") != identifier or not isinstance(document.get("text"), str):
        raise ValueError("INVALID_SANITIZED_DOCUMENT")
    return document


def public_item(item):
    result = {k: item[k] for k in PUBLIC_FIELDS if k in item}
    policy = result.get("policy_evaluation")
    if isinstance(policy, dict) and "assessment" not in policy:
        result["policy_evaluation"] = {**policy, "assessment": "UNKNOWN", "assessment_reason": "LEGACY"}
    if "approval_record" in result:
        result["approval_record"] = {k: v for k, v in result["approval_record"].items()
                                     if k != "callback_sent"}
    return result


def list_items(data_table, query=None, public=False, cursor=None):
    args = {"Limit": 50}
    if cursor:
        try:
            if not isinstance(cursor, str) or len(cursor) > 4096:
                raise ValueError("INVALID_CURSOR")
            decoded = base64.b64decode(cursor.encode("ascii"), altchars=b"-_", validate=True)
            key = json.loads(decoded)
            allowed = {"incident_id", "timestamp_action", "ioc_value", "reporter_id", "status", "created_at"}
            if not isinstance(key, dict) or not key or set(key) - allowed:
                raise ValueError("INVALID_CURSOR")
            if not all(isinstance(value, str) and value for value in key.values()):
                raise ValueError("INVALID_CURSOR")
            args["ExclusiveStartKey"] = key
        except (ValueError, TypeError, UnicodeError):
            raise ApiError(400, "INVALID_CURSOR") from None
    if public:
        args.update(ProjectionExpression=PUBLIC_PROJECTION, ExpressionAttributeNames=PUBLIC_NAMES)
    try:
        if query:
            result = data_table.query(**args, **query)
        else:
            result = data_table.scan(**args)
    except ClientError as exc:
        if cursor and exc.response["Error"]["Code"] == "ValidationException":
            raise ApiError(400, "INVALID_CURSOR") from None
        raise
    items = result.get("Items", [])
    key = result.get("LastEvaluatedKey")
    next_token = base64.urlsafe_b64encode(json.dumps(key).encode()).decode() if key else None
    return {"items": [public_item(item) for item in items] if public else items, "next_token": next_token}


def identity(event):
    claims = event.get("requestContext", {}).get("authorizer", {}).get("jwt", {}).get("claims", {})
    if claims.get("token_use") != "access" or claims.get("client_id") != os.environ["COGNITO_CLIENT_ID"]:
        raise ApiError(401, "ACCESS_TOKEN_REQUIRED")
    groups = claims.get("cognito:groups", [])
    if isinstance(groups, str):
        try:
            parsed = json.loads(groups)
            groups = parsed if isinstance(parsed, list) else []
        except ValueError:
            groups = [v.strip("\"'") for v in re.split(r"[,\s]+", groups.strip("[] ")) if v]
    groups = {v for v in groups if isinstance(v, str)} & {"REPORTER", "SECOPS_ADMIN", "AUDITOR"}
    if not groups or not claims.get("sub"):
        raise ApiError(403, "GROUP_MEMBERSHIP_REQUIRED")
    return claims["sub"], groups


def body_json(event):
    raw = event.get("body") or "{}"
    if event.get("isBase64Encoded"):
        raw = base64.b64decode(raw, validate=True).decode("utf-8")
    try:
        value = json.loads(raw)
    except (ValueError, TypeError) as exc:
        raise ApiError(400, "INVALID_JSON") from exc
    if not isinstance(value, dict):
        raise ApiError(400, "JSON_OBJECT_REQUIRED")
    return value


def response(status, value):
    return {"statusCode": status, "headers": {"content-type": "application/json; charset=utf-8",
            "cache-control": "no-store"}, "body": dumps(value)}


def api_wrapper(function, event):
    try:
        return function(event)
    except ApiError as exc:
        return response(exc.status, {"error": exc.code})
    except (ValueError, UnicodeError):
        return response(400, {"error": "INVALID_INPUT"})
    except Exception as exc:
        print(dumps({"event": "api_failure", "error_type": type(exc).__name__}))
        return response(500, {"error": "INTERNAL_ERROR"})


def task_wrapper(function, event):
    try:
        return function(event)
    except (TextractTransient, BedrockThrottled):
        raise
    except Exception as exc:
        print(dumps({"event": "task_failure", "error_type": type(exc).__name__}))
        raise PipelineError("PIPELINE_TASK_FAILED") from None
