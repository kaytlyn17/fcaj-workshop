"""Deterministic URL parsing, lookalike detection, and phishing scoring rules."""
import hashlib
import re
import unicodedata
from urllib.parse import urlsplit, urlunsplit

import tldextract

PSL = tldextract.TLDExtract(
    suffix_list_urls=(), cache_dir=None, include_psl_private_domains=True
)
OFFICIAL = {
    "techcombank": {"techcombank.com.vn"},
    "vietcombank": {"vietcombank.com.vn"},
    "acb": {"acb.com.vn"},
    "bidv": {"bidv.com.vn"},
}
ALLOWLIST = set().union(*OFFICIAL.values())
WEIGHTS = {
    "KNOWN_BLOCKED_IOC": 50, "BRAND_LOOKALIKE_DOMAIN": 40,
    "FINANCIAL_OR_OTP_REQUEST": 30, "EXEC_IMPERSONATION": 25,
    "URGENCY_PRESSURE": 10, "HEADER_ANOMALY": 10,
    "LINKED_BENEFIT_CLAIM": 40,
}

# Require an explicit web prefix or an explicitly defanged DNS separator.
WEB_URL = re.compile(
    r"""(?<![\w@./\]-])(?:h(?:tt|xx)ps?(?::|\[:\])//|www(?:\\?\.|\[\.\])|"""
    r"""(?:[a-z0-9-]{1,63}\.)*[a-z0-9-]{1,63}\[\.\])[^<>\s"'“”‘’]+""", re.I)
WARNING_QUOTE = re.compile(
    r'((?:lừa đảo|lua dao|giả mạo|gia mao|tin nhắn giả|tin nhan gia|phishing)'
    r'[^.!?\n"“]{0,100}[:\s])(?:"[^"]{1,2000}"|“[^”]{1,2000}”)',
    re.I)
BENEFIT = re.compile(r"\b(?:nhan|linh|huong)\s+(?:(?:khoan|phan|so|goi)\s+)?"
                     r"(?:tien|tro cap|ho tro|phu cap|hoan tien)\b")
LINK_INVITATION = re.compile(
    r"\b(?:bam(?: vao)?|nhan vao|nhap vao|click(?: vao)?|truy cap|mo lien ket)"
    r"(?:\s+[a-z0-9]+){0,5}\s*[:\-]?\s*\x00")
DEADLINE = re.compile(r"\b(?:qua han|het han|han chot|khong duoc chap nhan|"
                      r"trong \d+ (?:gio|phut)|truoc \d{1,2}\s*(?:h|gio))\b")

def normalize(text):
    text = unicodedata.normalize("NFD", text.lower().replace("đ", "d"))
    return " ".join("".join(c for c in text if not unicodedata.combining(c)).split())



def incident_id(source_intake_key):
    return "INC-" + hashlib.sha256(source_intake_key.encode("utf-8")).hexdigest()[:12]


def canonical_host(host):
    host = host.rstrip(".").lower().encode("idna").decode("ascii")
    if len(host) > 253 or any(
        not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label)
        for label in host.split(".")
    ):
        raise ValueError("Invalid DNS hostname")
    return host


def registered(host):
    parts = PSL(canonical_host(host))
    return f"{parts.domain}.{parts.suffix}" if parts.domain and parts.suffix else ""


def lookalike(host):
    host = canonical_host(host)
    if registered(host) in ALLOWLIST:
        return False
    for label in host.split("."):
        tokens = [t.replace("0", "o").replace("1", "l").replace("rn", "m")
                  for t in label.split("-")]
        for brand in OFFICIAL:
            if (len(brand) >= 5 and brand in "".join(tokens)) or (
                len(brand) <= 4 and brand in tokens
            ):
                return True
    return False


def split_web_url(candidate):
    candidate = candidate.rstrip(".,;:!?]}")
    if candidate.endswith(")"):
        extra = max(0, candidate.count(")") - candidate.count("("))
        candidate = candidate[:max(len(candidate.rstrip(")")), len(candidate) - extra)]
    candidate = re.sub(r"^h(?:xx|tt)p(s?)(?::|\[:\])//", r"http\1://", candidate, flags=re.I)
    if not re.match(r"https?://", candidate, re.I):
        candidate = "http://" + candidate
    # Refang the authority before urlsplit interprets square brackets as IPv6.
    scheme, _, location = candidate.partition("://")
    authority, suffix = re.fullmatch(r"([^/?#]*)(.*)", location, re.S).groups()
    authority = authority.replace("[.]", ".").replace(r"\.", ".")
    return urlsplit(f"{scheme}://{authority}{suffix}")


def parse_web_url(candidate):
    try:
        p = split_web_url(candidate)
        host = canonical_host(p.hostname or "")
        port = p.port
        netloc = host if port in (None, 443 if p.scheme == "https" else 80) else f"{host}:{port}"
        value = urlunsplit((p.scheme, netloc, p.path or "/", p.query, ""))
        return {"canonical_value": value, "host": host, "registrable_domain": registered(host),
                "display_value": urlunsplit((p.scheme.replace("http", "hxxp", 1), netloc.replace(".", "[.]"),
                                             p.path or "/", p.query, ""))}
    except (ValueError, UnicodeError):
        return None


def extract_urls(text):
    result = {}
    for match in WEB_URL.finditer(text):
        url = parse_web_url(match.group())
        if url:
            result[url["canonical_value"]] = url
    return list(result.values())


def matching_text(text):
    def link_marker(match):
        url = parse_web_url(match.group())
        if url and "." in url["host"] and url["registrable_domain"] not in ALLOWLIST:
            return " \x00 "
        return " <url> "

    n = normalize(WEB_URL.sub(link_marker, text.replace("\x00", " ")))
    n = re.sub(r"(?<=[a-z])!(?=[a-z])", "i", n)
    return re.sub(r"(?<=[a-z])['_’\-](?=[a-z])", " ", n)


def benefit_claims(text):
    for invite in LINK_INVITATION.finditer(text):
        prefix = text[max(0, invite.start() - 160):invite.start()]
        if re.search(r"(?:khong|dung|tranh)(?: nen)?\s+$", prefix):
            continue
        context = prefix + text[invite.start():invite.end() + 160]
        if any(not re.search(r"\b(?:da|lich|xac)\s+$", context[:claim.start()]) for claim in BENEFIT.finditer(context)):
            yield context


def valid_block_domain(target, urls):
    """Require a canonical registrable domain already present in the evidence."""
    if not isinstance(target, str) or target in ALLOWLIST:
        return False
    try:
        if target != canonical_host(target) or registered(target) != target:
            return False
    except (ValueError, UnicodeError):
        return False
    return any(url.get("registrable_domain") == target for url in urls)


def evaluate(text, *, header_anomaly=False, blocklist=None, mode="DRY_RUN", urls=None):
    if mode not in {"DRY_RUN", "INTERNAL_LIST"}:
        raise ValueError("mode must be DRY_RUN or INTERNAL_LIST")
    blocklist = blocklist or {}
    urls = extract_urls(text) if urls is None else urls
    # Quoted scam examples remain in evidence. Only instructions outside an
    # explicitly introduced warning quotation can supply a containment target.
    instructions = WARNING_QUOTE.sub(r"\1 ", text)
    active_urls = urls if instructions == text else extract_urls(instructions)
    n = matching_text(instructions)
    claims = list(benefit_claims(n))
    transfer = bool(re.search(r"chuyen\s+(?:khoan|tien)", n))
    sensitive = transfer or bool(re.search(
        r"(?:cung cap|gui|nhap|tiet lo|chia se).{0,50}(?:otp|mat khau|ma xac nhan)"
        r"|quet.{0,25}qr.{0,30}nhan tien", n))
    warning = bool(re.search(
        r"(?:khong|dung).{0,25}(?:cung cap|gui|chia se|tiet lo).{0,25}(?:otp|mat khau|ma xac nhan)", n))
    financial = sensitive and not (warning and not active_urls and not transfer)
    executive = bool(re.search(r"\b(?:giam doc|ceo|chu tich)\b", n))
    off_process = bool(re.search(
        r"ngoai quy trinh|bo qua quy trinh|khong can phe duyet|tai khoan (?:moi|la)", n))
    impersonation = executive and off_process and (transfer or "doi tai khoan" in n)
    urgency = bool(re.search(r"\b(?:gap|khan cap|ngay lap tuc)\b|trong \d+ phut", n)
                   or any(DEADLINE.search(context) for context in claims))
    flagged = sorted({u["registrable_domain"] or u["host"] for u in active_urls if lookalike(u["host"])})
    blocked = sorted({u["registrable_domain"] or u["host"] for u in active_urls if any(
        blocklist.get(key) in {"SEED", "APPROVED_CONFIRMED"}
        for key in (u["canonical_value"], u["host"], u["registrable_domain"])
    )})
    external = any(u["registrable_domain"] not in ALLOWLIST for u in active_urls)
    conditions = {
        "KNOWN_BLOCKED_IOC": blocked, "BRAND_LOOKALIKE_DOMAIN": flagged,
        "FINANCIAL_OR_OTP_REQUEST": financial, "EXEC_IMPERSONATION": impersonation,
        "URGENCY_PRESSURE": urgency, "HEADER_ANOMALY": header_anomaly and (financial or external),
        "LINKED_BENEFIT_CLAIM": claims,
    }
    triggered = [rule for rule, active in conditions.items() if active]
    score = min(100, sum(WEIGHTS[r] for r in triggered))
    severity = "CRITICAL" if score >= 75 else "HIGH" if score >= 50 else "MEDIUM" if score >= 25 else "LOW"
    actions = []
    if score >= 50:
        for target in sorted(set(flagged + blocked)):
            if valid_block_domain(target, urls):
                actions.append({"type": "BLOCK_DOMAIN", "target": target})
        if impersonation:
            actions.append({"type": "FINANCE_VERIFICATION_ALERT", "target": "FINANCE"})
    for i, action in enumerate(actions, 1):
        action.update(action_id=f"ACT-{i:03d}", mode=mode, proposal_version=1)
    injection = bool(re.search(
        r"ignore.{0,50}instructions|bo qua.{0,40}(?:luat|chi dan)|dat.{0,15}diem.{0,10}0", normalize(text)))
    return {
        "policy_evaluation": {"risk_score": score, "severity": severity, "triggered_rules": triggered,
                              "assessment": "SUSPICIOUS" if score >= 50 else "UNKNOWN",
                              "assessment_reason": "RULE_THRESHOLD" if score >= 50 else (
                                  "UNVERIFIED_URL" if urls else "INSUFFICIENT_SIGNALS")},
        "deterministic_findings": {"urls": urls, "lookalike_domains": flagged, "blocked_domains": blocked},
        "security_flags": ["PROMPT_INJECTION_DETECTED"] if injection else [],
        "proposed_actions": actions,
        "requires_manual_review": score >= 50 and not actions,
    }
