"""Apply approved internal effects with conditionally appended audit entries."""
import os

from boto3.dynamodb.types import TypeSerializer
from botocore.exceptions import ClientError

from common import client, get_incident, now, task_wrapper
from policy import valid_block_domain

SERIALIZER = TypeSerializer()
MODES = {"DRY_RUN", "INTERNAL_LIST"}
DECISION_FIELDS = ("decision_id", "action_id", "proposal_version", "decision", "actor_id")
APPROVED_STATES = {"SIMULATED", "INTERNAL_LIST_UPDATED"}


def attributes(values):
    return {key: SERIALIZER.serialize(value) for key, value in values.items()}


def result(item, finance=False):
    return {"incident_id": item["incident_id"], "status": item["status"], "finance_verification": finance}


def selected_action(item, record):
    action = next((entry for entry in item.get("proposed_actions", [])
                   if entry.get("action_id") == record["action_id"]), None)
    if action is None or action.get("proposal_version") != record["proposal_version"]:
        return None
    return action


def valid_action(item, action):
    if action is None or action.get("mode") not in MODES:
        return False
    target = action.get("target")
    if action.get("type") == "FINANCE_VERIFICATION_ALERT":
        return target == "FINANCE" and "EXEC_IMPERSONATION" in item["policy_evaluation"]["triggered_rules"]
    if action.get("type") != "BLOCK_DOMAIN" or not isinstance(target, str):
        return False
    findings = item["deterministic_findings"]
    marked = set(findings.get("lookalike_domains", [])) | set(findings.get("blocked_domains", []))
    return target in marked and valid_block_domain(target, findings.get("urls", []))


def approval_record(item, callback, decision):
    record = item.get("approval_record")
    if not isinstance(record, dict) or not isinstance(callback, dict):
        raise ValueError("APPROVAL_RECORD_REQUIRED")
    if any(key not in record or key not in callback or record[key] != callback[key] for key in DECISION_FIELDS):
        raise ValueError("APPROVAL_RECORD_MISMATCH")
    if record["decision"] != decision or item.get("proposal_version", record["proposal_version"]) != record["proposal_version"]:
        raise ValueError("APPROVAL_VERSION_OR_DECISION_MISMATCH")
    if not record.get("decided_at"):
        raise ValueError("APPROVAL_TIMESTAMP_REQUIRED")
    return record


def incident_update(item, status, record, *, close, extra=None):
    names = {"#status": "status"}
    values = {":old": item["status"], ":new": status, ":now": now()}
    condition = "#status=:old"
    if record is not None:
        names["#record"] = "approval_record"
        for index, field in enumerate(DECISION_FIELDS):
            names[f"#r{index}"] = field
            values[f":r{index}"] = record[field]
            condition += f" AND #record.#r{index}=:r{index}"
    update = "SET #status=:new, updated_at=:now"
    for index, (name, value) in enumerate((extra or {}).items()):
        names[f"#e{index}"] = name
        values[f":e{index}"] = value
        update += f", #e{index}=:e{index}"
    if close:
        update += " REMOVE sfn_task_token"
    return {"Update": {
        "TableName": os.environ["INCIDENTS_TABLE"],
        "Key": attributes({"incident_id": item["incident_id"]}),
        "UpdateExpression": update,
        "ConditionExpression": condition,
        "ExpressionAttributeNames": names,
        "ExpressionAttributeValues": attributes(values),
    }}


def audit_write(item, status, action, mode, record):
    approval = record or {}
    # Persisted timestamps keep retries on the same audit key.
    stamp = approval.get("decided_at") or item.get("approval_expires_at") or item["created_at"]
    entry = {
        "incident_id": item["incident_id"],
        "timestamp_action": f"{stamp}#{action}",
        "actor_id": approval.get("actor_id", "SYSTEM"),
        "actor_role": "SECOPS_ADMIN" if record else "SYSTEM",
        "action": action,
        "previous_status": item["status"],
        "new_status": status,
        "decision_id": approval.get("decision_id", ""),
        "decision_note": approval.get("note", ""),
        "containment_mode": mode,
    }
    return {"Put": {
        "TableName": os.environ["AUDIT_TABLE"],
        "Item": attributes(entry),
        "ConditionExpression": "attribute_not_exists(incident_id) AND attribute_not_exists(timestamp_action)",
        "ReturnValuesOnConditionCheckFailure": "NONE",
    }}


def blocklist_write(item, action, record):
    mode, target = action["mode"], action["target"]
    entry = {
        "ioc_value": target,
        "display_value": target.replace(".", "[.]"),
        "ioc_type": "DOMAIN",
        "source": "APPROVED_DRY_RUN" if mode == "DRY_RUN" else "APPROVED_CONFIRMED",
        "incident_id": item["incident_id"],
        "approved_by": record["actor_id"],
        "mode": mode,
        "created_at": record["decided_at"],
    }
    condition = "attribute_not_exists(ioc_value) OR attribute_not_exists(#source) OR #source<>:seed"
    values = {":seed": "SEED"}
    if mode == "DRY_RUN":
        condition = ("attribute_not_exists(ioc_value) OR attribute_not_exists(#source) "
                     "OR (#source<>:seed AND #source<>:confirmed)")
        values[":confirmed"] = "APPROVED_CONFIRMED"
    return {"Put": {
        "TableName": os.environ["BLOCKLIST_TABLE"],
        "Item": attributes(entry),
        "ConditionExpression": condition,
        "ExpressionAttributeNames": {"#source": "source"},
        "ExpressionAttributeValues": attributes(values),
        "ReturnValuesOnConditionCheckFailure": "NONE",
    }}


def commit(item, status, audit_action, mode, record=None, block=None):
    update = incident_update(item, status, record, close=True, extra={"selected_mode": mode})
    update["Update"]["UpdateExpression"] += ", finance_notification_pending"
    audit = audit_write(item, status, audit_action, mode, record)
    client_ddb = client("dynamodb")
    writes = [update, audit]
    if block is not None:
        try:
            client_ddb.transact_write_items(TransactItems=[*writes, block])
            return
        except ClientError as exc:
            reasons = exc.response.get("CancellationReasons", [])
            # Treat the blocklist condition as a no-op only when it is the
            # sole failed write. Seed entries and confirmed dry-run targets
            # already have equal or stronger protection.
            if (exc.response["Error"]["Code"] != "TransactionCanceledException"
                    or [reason.get("Code") for reason in reasons]
                       != ["None", "None", "ConditionalCheckFailed"]):
                raise
    client_ddb.transact_write_items(TransactItems=writes)


def begin_action(item, record, action, *, finance_pending):
    if item["status"] == "ACTION_REQUESTED":
        return item
    extra = {"selected_mode": action["mode"]}
    if finance_pending:
        extra["finance_notification_pending"] = True
    update = incident_update(item, "ACTION_REQUESTED", record, close=True, extra=extra)["Update"]
    client("dynamodb").update_item(**update)
    return {**item, **extra, "status": "ACTION_REQUESTED"}


def handle(event):
    item = get_incident(event["incident_id"])
    operation = event["operation"]
    if operation == "TIMEOUT":
        if item["status"] == "ESCALATED_TIMEOUT":
            return result(item)
        if item["status"] != "PENDING_APPROVAL":
            raise ValueError("TIMEOUT_STATE_CONFLICT")
        mode = item.get("selected_mode") or next(
            (action["mode"] for action in item.get("proposed_actions", []) if action.get("mode") in MODES), "DRY_RUN"
        )
        commit(item, "ESCALATED_TIMEOUT", "ESCALATED_TIMEOUT", mode)
        return result({**item, "status": "ESCALATED_TIMEOUT"})

    if operation not in {"APPROVE", "REJECT", "FINALIZE_FINANCE", "FAIL_FINANCE"}:
        raise ValueError("UNSUPPORTED_CONTAINMENT_OPERATION")
    record = approval_record(item, event.get("approval_decision"), "REJECT" if operation == "REJECT" else "APPROVE")
    action = selected_action(item, record)
    mode = action["mode"] if action and action.get("mode") in MODES else "DRY_RUN"
    finance = action is not None and action.get("type") == "FINANCE_VERIFICATION_ALERT"

    if operation == "REJECT":
        if item["status"] == "REJECTED":
            return result(item)
        if item["status"] != "PENDING_APPROVAL":
            raise ValueError("REJECT_STATE_CONFLICT")
        commit(item, "REJECTED", "REJECT", mode, record)
        return result({**item, "status": "REJECTED"})

    if item["status"] in APPROVED_STATES | {"CONTAINMENT_FAILED"}:
        publish_for_previous_definition = (
            operation == "APPROVE" and finance and item["status"] in APPROVED_STATES
            and event.get("defer_finance_completion") is not True
        )
        return result(item, finance=publish_for_previous_definition)
    if item["status"] not in {"PENDING_APPROVAL", "ACTION_REQUESTED"}:
        raise ValueError("APPROVE_STATE_CONFLICT")

    if operation in {"FINALIZE_FINANCE", "FAIL_FINANCE"}:
        if not (item["status"] == "ACTION_REQUESTED" and item.get("finance_notification_pending")
                and finance and valid_action(item, action)):
            raise ValueError("FINANCE_NOTIFICATION_STATE_CONFLICT")
        status = "SIMULATED" if operation == "FINALIZE_FINANCE" else "CONTAINMENT_FAILED"
        audit_action = "APPROVE" if operation == "FINALIZE_FINANCE" else "FINANCE_NOTIFICATION_FAILED"
        commit(item, status, audit_action, mode, record)
        return result({**item, "status": status})

    if not valid_action(item, action):
        commit(item, "CONTAINMENT_FAILED", "CONTAINMENT_VALIDATION_FAILED", "DRY_RUN", record)
        return result({**item, "status": "CONTAINMENT_FAILED"})

    deferred_finance = finance and event.get("defer_finance_completion") is True
    item = begin_action(item, record, action, finance_pending=deferred_finance)
    if deferred_finance:
        return result(item, finance=True)

    # Executions launched under the 2B definition publish the finance
    # notification after this task and do not have a separate finalizer.
    status = "SIMULATED" if mode == "DRY_RUN" or finance else "INTERNAL_LIST_UPDATED"
    block = blocklist_write(item, action, record) if action["type"] == "BLOCK_DOMAIN" else None
    commit(item, status, "APPROVE", mode, record, block)
    return result({**item, "status": status}, finance=finance)


def lambda_handler(event, context):
    return task_wrapper(handle, event)
